param([string]$ToolRoot,[string]$Python='python')
$ErrorActionPreference='Stop'
$package=Split-Path $PSScriptRoot
& "$package\Build.ps1" -ToolRoot $ToolRoot
if(-not $ToolRoot) {
 foreach($base in @('C:\Users\admin\Documents\Codex\tools\VSBuildTools2022\VC\Tools\MSVC',"${env:ProgramFiles}\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC","${env:ProgramFiles}\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC")) {
  if(Test-Path -LiteralPath $base){$ToolRoot=(Get-ChildItem -LiteralPath $base -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName;break}
 }
}
$bin=Join-Path $ToolRoot 'bin\Hostx64\x64'
$build=Join-Path $package 'build'
foreach($suite in @('store','graphics','input')) {
 & "$bin\cl.exe" /nologo /c /W4 /WX /GS- /Zl /O1 /Oi /I"$ToolRoot\include" /Fo"$build\$suite-tests.obj" "$PSScriptRoot\$suite-tests.c"
 if($LASTEXITCODE){throw "Compile failed: $suite"}
 & "$bin\link.exe" /nologo /dll /noentry /nodefaultlib /out:"$build\$suite-tests.dll" /export:sha256 /export:derive /export:crc32 "$build\$suite-tests.obj" "$build\crypto.obj" "$build\store.obj" "$build\files.obj" "$build\script.obj" "$build\vmport.obj"
 if($LASTEXITCODE){throw "Link failed: $suite"}
}
# The interpreter suite uses its own mock store to exercise failed writes.
& "$bin\cl.exe" /nologo /c /W4 /WX /GS- /Zl /O1 /Oi /I"$ToolRoot\include" /Fo"$build\script-tests.obj" "$PSScriptRoot\script-tests.c"
if($LASTEXITCODE){throw 'Compile failed: script'}
& "$bin\link.exe" /nologo /dll /noentry /nodefaultlib /out:"$build\script-tests.dll" "$build\script-tests.obj" "$build\crypto.obj" "$build\files.obj" "$build\script.obj"
if($LASTEXITCODE){throw 'Link failed: script'}
& $Python "$PSScriptRoot\verify-native.py"
if($LASTEXITCODE){throw 'Tests failed'}
