#include "../src/desktop.h"

Profile profile;
static int fail_save;
int store_save(void){return !fail_save;}

static int contains(const char *s,const char *q){u32 i,j;for(i=0;s[i];++i){for(j=0;q[j]&&s[i+j]==q[j];++j){}if(!q[j])return 1;}return 0;}
static int run(int node,const char *text){int i;if(!fs_write(node,text))return 0;script_start(node);for(i=0;i<2000&&script_running();++i)script_tick();return !script_running();}

__declspec(dllexport) int ScriptChecks(void){int checks=0,docs,other,script,file,i;u64 id;static char text[TEXT_CAP],script_text[TEXT_CAP];
#define CHECK(x) do{++checks;if(!(x))return -checks;}while(0)
 memzero(&profile,sizeof(profile));defaults();
 docs=fs_create(-1,"Documents",NODE_FOLDER);other=fs_create(-1,"Other",NODE_FOLDER);script=fs_create(docs,"test.leo",NODE_FILE);
 CHECK(docs>=0&&other>=0&&script>=0);
 CHECK(run(script,"pwd\nhelp\nmkdir Notes\nwrite sample.txt | hello\nappendline sample.txt | world\nread sample.txt\n"));
 CHECK(equal(script_status(),"Finished"));CHECK(contains(script_output(),"/Documents"));CHECK(contains(script_output(),"appendline"));
 file=fs_find(docs,"sample.txt");CHECK(file>=0&&equal(profile.files[file].text,"helloworld\n"));
 id=profile.files[file].id;
 CHECK(run(script,"rename sample.txt | renamed.txt\nmove renamed.txt | /Other\n"));
 CHECK(equal(script_status(),"Finished"));CHECK(fs_find(other,"renamed.txt")==file&&profile.files[file].id==id);
 CHECK(run(script,"ifexists /Other/renamed.txt | echo found\nifmissing /Other/renamed.txt | echo wrong\nifmissing /Other/missing | ifexists /Other | echo nested\n"));
 CHECK(equal(script_status(),"Finished")&&contains(script_output(),"found\n")&&contains(script_output(),"nested\n")&&!contains(script_output(),"wrong\n"));
 CHECK(run(script,"ifexists | echo bad"));CHECK(!equal(script_status(),"Finished"));
 CHECK(run(script,"rename /Documents | broken"));CHECK(!equal(script_status(),"Finished"));CHECK(fs_find(-1,"Documents")==docs);
 CHECK(run(script,"move /Documents | /Other"));CHECK(!equal(script_status(),"Finished"));CHECK(profile.files[docs].parent==-1);
 fail_save=1;CHECK(run(script,"rename /Other/renamed.txt | failed.txt"));CHECK(!equal(script_status(),"Finished"));CHECK(fs_find(other,"renamed.txt")==file&&fs_find(other,"failed.txt")<0);fail_save=0;
 CHECK(run(script,"wait"));CHECK(!equal(script_status(),"Finished")&&contains(script_output(),"wait NUMBER"));
 CHECK(run(script,"repeat 3 echo test"));CHECK(equal(script_status(),"Finished"));CHECK(contains(script_output(),"test\ntest\ntest\n"));
 for(i=0;i<1400;++i)((volatile char *)text)[i]='X';text[1400]=0;CHECK(fs_write(file,text));
 CHECK(run(script,"read /Other/renamed.txt"));CHECK(contains(script_output(),text));
 for(i=0;i<120;++i)((volatile char *)script_text)[i+4]='x';memcopy(script_text,"let ",4);script_text[124]='\n';memcopy(script_text+125,"echo $$$$$",11);
 CHECK(run(script,script_text));CHECK(!equal(script_status(),"Finished")&&contains(script_output(),"Expanded line is too long"));
 CHECK(run(script,"write ../../escape.txt | no"));CHECK(!equal(script_status(),"Finished")&&fs_find(-1,"escape.txt")<0);
 CHECK(run(script,"mkdir New\nmove /Other/renamed.txt | New\npwd\n"));CHECK(equal(script_status(),"Finished"));CHECK(fs_resolve(docs,"New/renamed.txt")==file);
 CHECK(fs_write(script,"wait 300\necho never"));script_start(script);script_tick();script_stop();CHECK(!script_running());
 profile.scripts_enabled=0;script_start(script);CHECK(!script_running());profile.scripts_enabled=1;
 CHECK(run(script,"repeat 101 echo nope"));CHECK(!equal(script_status(),"Finished"));
 CHECK(run(script,"repeat 2 repeat 2 repeat 2 echo test"));CHECK(script_steps()<=513);
 return checks;
}
