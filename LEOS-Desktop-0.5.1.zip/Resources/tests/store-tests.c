#include "../src/desktop.h"
static u8 disks[4][sizeof(Profile)+1];static u64 sizes[4],positions[4];static int exists[4],write_failure,flush_failure,delete_failure;
static File root,dir,handles[4];static FS fs;static Loaded loaded;
static int index_of(File *f){int i;for(i=0;i<4;++i)if(f==&handles[i])return i;return 0;}
static Status close_file(File *f){(void)f;return 0;}
static Status delete_file(File *f){int i=index_of(f);if(delete_failure)return ERR(7);exists[i]=0;sizes[i]=0;positions[i]=0;return 0;}
static Status position(File *f,u64 p){positions[index_of(f)]=p;return 0;}
static Status read_file(File *f,u64 *n,void *data){int i=index_of(f);u64 count=*n;if(positions[i]>sizes[i])return ERR(7);if(count>sizes[i]-positions[i])count=sizes[i]-positions[i];memcopy(data,disks[i]+positions[i],count);positions[i]+=count;*n=count;return 0;}
static Status write_file(File *f,u64 *n,void *data){int i=index_of(f);if(write_failure)return ERR(9);if(*n>sizeof(Profile)-positions[i])return ERR(9);memcopy(disks[i]+positions[i],data,*n);positions[i]+=*n;if(positions[i]>sizes[i])sizes[i]=positions[i];return 0;}
static Status flush_file(File *f){(void)f;return flush_failure?ERR(7):0;}
static Status open_file(File *self,File **out,const u16 *path,u64 mode,u64 attr){int i;(void)attr;if(self==&root){*out=&dir;return 0;}i=(path[0]=='P'?2:0)+(path[8]=='A'?0:1);if(!exists[i]&&!(mode&0x8000000000000000ull))return ERR(14);exists[i]=1;positions[i]=0;*out=&handles[i];return 0;}
static Status open_volume(FS *s,File **out){(void)s;*out=&root;return 0;}
static Status protocol(void *handle,Guid *guid,void **out){(void)handle;if(guid->a==0x5b1b31a1)*out=&loaded;else *out=&fs;return 0;}
static void reset(void){memzero(disks,sizeof(disks));memzero(sizes,sizeof(sizes));memzero(exists,sizeof(exists));memzero(&profile,sizeof(profile));write_failure=flush_failure=delete_failure=0;}
#pragma pack(push,1)
typedef struct {char name[24];u32 length;char text[2048];} LegacyDocument;
typedef struct {char magic[8];u32 version,size;u64 generation;char username[32];u8 salt[16],verifier[32];u32 rounds,accent,count;LegacyDocument files[8];u32 checksum;} Legacy;
#pragma pack(pop)
static Legacy old;
static int has(const char *s,const char *q){u32 i,j;for(i=0;s[i];++i){for(j=0;q[j]&&s[i+j]==q[j];++j){}if(!q[j])return 1;}return 0;}
__declspec(dllexport) int RunStoreTests(void){static System st;static Boot boot;int checks=0,i,docs,sub,f,other,script;u64 id;u32 old_hash;char path[256];
#define CHECK(x) do{++checks;if(!(x))return -checks;}while(0)
 reset();st.boot=&boot;boot.f[16]=(void *)protocol;fs.open_volume=open_volume;loaded.device=&fs;root.open=dir.open=open_file;root.close=dir.close=close_file;
 for(i=0;i<4;++i){handles[i].delete_file=(void *)delete_file;handles[i].read=read_file;handles[i].write=write_file;handles[i].close=close_file;handles[i].set_position=position;handles[i].flush=flush_file;}
 CHECK(store_open(&st,&st));CHECK(store_load()==0);defaults();copytext(profile.username,32,"tester");profile.rounds=PASSWORD_ROUNDS;
 CHECK(store_save());CHECK(profile.generation==1);docs=fs_create(-1,"Documents",NODE_FOLDER);CHECK(docs>=0);sub=fs_create(docs,"Projects",NODE_FOLDER);CHECK(sub>=0);f=fs_create(sub,"note.txt",NODE_FILE);CHECK(f>=0);CHECK(fs_write(f,"persistent"));id=profile.files[f].id;CHECK(store_save());CHECK(profile.generation==2);memzero(&profile,sizeof(profile));CHECK(store_load()==1);CHECK(profile.files[f].id==id&&equal(profile.files[f].text,"persistent"));
 disks[1][200]^=1;CHECK(store_load()==1);CHECK(profile.generation==1&&profile.count==0);write_failure=1;CHECK(!store_save());CHECK(profile.generation==1);write_failure=0;CHECK(store_save());CHECK(profile.generation==2);flush_failure=1;CHECK(!store_save());CHECK(profile.generation==2);flush_failure=0;
 CHECK(!exists[0]);sizes[0]=3;exists[0]=1;disks[1][300]^=1;CHECK(store_load()==-1);
 reset();CHECK(store_load()==0);memzero(&old,sizeof(old));memcopy(old.magic,"LEOSGUI2",8);old.version=2;old.size=sizeof(old);old.generation=9;old.rounds=PASSWORD_ROUNDS;old.count=3;copytext(old.username,32,"legacy");copytext(old.files[0].name,24,"old.txt");copytext(old.files[0].text,2048,"Old notes survive");old.files[0].length=length(old.files[0].text);copytext(old.files[1].name,24,"OLD.TXT");copytext(old.files[1].text,2048,"Other notes");old.files[1].length=length(old.files[1].text);copytext(old.files[2].name,24,"last. ");copytext(old.files[2].text,2048,"Third notes");old.files[2].length=length(old.files[2].text);old.checksum=crc32(&old,sizeof(old)-4);exists[2]=1;sizes[2]=sizeof(old);memcopy(disks[2],&old,sizeof(old));old_hash=crc32(disks[2],sizeof(old));CHECK(store_load()==1);CHECK(equal(profile.username,"legacy"));docs=fs_find(-1,"Documents");CHECK(docs>=0);f=fs_find(docs,"old.txt");CHECK(f>=0&&equal(profile.files[f].text,"Old notes survive"));other=fs_find(docs,"OLD.TXT~2");CHECK(other>=0&&equal(profile.files[other].text,"Other notes"));other=fs_find(docs,"last");CHECK(other>=0&&equal(profile.files[other].text,"Third notes"));CHECK(crc32(disks[2],sizeof(old))==old_hash);CHECK(exists[0]);CHECK(store_load()==1);
 CHECK(fs_create(-2,"bad",NODE_FILE)<0);CHECK(fs_create(docs,"OLD.txt",NODE_FILE)<0);CHECK(fs_create(docs,"../bad",NODE_FOLDER)<0);sub=fs_create(docs,"Projects",NODE_FOLDER);CHECK(sub>=0);other=fs_create(-1,"Other",NODE_FOLDER);CHECK(other>=0);id=profile.files[f].id;CHECK(fs_move(f,sub));CHECK(fs_rename(f,"renamed.txt"));CHECK(profile.files[f].id==id);CHECK(!fs_move(docs,sub));CHECK(!fs_move(f,-2));CHECK(fs_resolve(-1,"/Documents/Projects/renamed.txt")==f);CHECK(fs_resolve(sub,"../../Other")==other);fs_path(f,path,256);CHECK(equal(path,"/Documents/Projects/renamed.txt"));
 profile.files[sub].flags|=FLAG_QUARANTINE;CHECK(fs_blocked(f));CHECK(!fs_write(f,"bad"));CHECK(fs_create(sub,"blocked",NODE_FILE)<0);CHECK(fs_resolve(-1,path)==-2);profile.files[sub].flags=0;profile.files[f].flags|=FLAG_TRUSTED;CHECK(fs_write(f,"edited"));CHECK(!(profile.files[f].flags&FLAG_TRUSTED));CHECK(fs_trash(sub));CHECK(fs_blocked(f));CHECK(fs_restore(sub));CHECK(!fs_blocked(f));CHECK(fs_trash(sub));CHECK(fs_purge(sub));CHECK(!profile.files[f].kind);CHECK(!fs_purge(docs));
 fs_begin();f=fs_create(docs,"rollback.txt",NODE_FILE);CHECK(f>=0);write_failure=1;CHECK(!fs_commit());write_failure=0;CHECK(fs_find(docs,"rollback.txt")<0);
 script=fs_create(docs,"test.leo",NODE_FILE);CHECK(script>=0);CHECK(fs_write(script,"let world\necho Hello $\nmkdir Test\ncd Test\nwrite result.txt | first\nappend result.txt | second\nread result.txt\nrepeat 3 echo repeat\n"));script_start(script);for(i=0;i<1000&&script_running();++i)script_tick();CHECK(!script_running());CHECK(equal(script_status(),"Finished"));CHECK(has(script_output(),"Hello world"));f=fs_resolve(docs,"Test/result.txt");CHECK(f>=0&&equal(profile.files[f].text,"firstsecond"));CHECK(script_identity()==profile.files[script].id);
 profile.scripts_enabled=0;script_start(script);CHECK(!script_running());profile.scripts_enabled=1;profile.files[script].flags|=FLAG_QUARANTINE;script_start(script);CHECK(!script_running());profile.files[script].flags=0;
 CHECK(fs_write(script,"repeat 2 repeat 2 repeat 2 echo hi"));script_start(script);for(i=0;i<700&&script_running();++i)script_tick();CHECK(!script_running()&&script_steps()<=513); /* nested repeat is bounded */
 CHECK(fs_write(script,"repeat 101 echo bad"));script_start(script);script_tick();CHECK(!script_running()&&has(script_output(),"limited"));CHECK(fs_write(script,"wait 300\necho later"));script_start(script);script_tick();script_stop();CHECK(!script_running());
 CHECK(fs_write(script,"write ../../escape.txt | confined"));script_start(script);script_tick();CHECK(!script_running());CHECK(fs_find(-1,"escape.txt")<0);CHECK(fs_write(script,"format C:"));script_start(script);script_tick();CHECK(!script_running()&&has(script_output(),"Unknown command"));
 CHECK(store_save());CHECK(store_load()==1);CHECK(fs_resolve(docs,"Test/result.txt")>=0);
 /* An oversized inactive bank is replaced cleanly and the remaining record survives a failed flush. */
 i=(profile.generation%2)?1:0;exists[i]=1;sizes[i]=sizeof(Profile)+1;disks[i][sizeof(Profile)]=0x42;
 CHECK(store_save());CHECK(sizes[i]==sizeof(Profile));CHECK(store_load()==1);
 i=(profile.generation%2)?1:0;delete_failure=1;CHECK(!store_save());delete_failure=0;CHECK(store_load()==1);
 i=(profile.generation%2)?1:0;flush_failure=1;CHECK(!store_save());flush_failure=0;CHECK(!exists[i]);CHECK(store_load()==1);
 CHECK(fs_resolve(-2,"..") == -2);CHECK(fs_resolve(DOCUMENTS,"..") == -2);CHECK(fs_resolve(f,".") == -2);CHECK(fs_resolve(-1,0)==-2);
 store_close();CHECK(!store_save());return checks;
}
