$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\..\LEOS-Desktop.ps1"

# Only the real protection function is exercised. Every external state read is
# mocked, so these tests never inspect or change the host's boot settings.
$script:Checks = 0
$script:BootReads = 0
$script:BitLockerReads = 0
$script:SecureResult = $false
$script:SecureFailure = ''
$script:Machine = [pscustomobject]@{ Manufacturer = 'QEMU'; Model = 'Standard PC (Q35 + ICH9, 2009)' }
$script:BootState = [pscustomobject]@{ Enabled = 0; Capable = 0 }
$script:BootFailure = ''
$script:Volume = [pscustomobject]@{ ProtectionStatus = 'Off' }
$script:VolumeFailure = ''

function Confirm-SecureBootUEFI {
    param($ErrorAction)
    if ($script:SecureFailure) { throw $script:SecureFailure }
    if ($null -ne $script:SecureResult) { return $script:SecureResult }
}
function Get-FirmwareBootState {
    $script:BootReads++
    if ($script:BootFailure) { throw $script:BootFailure }
    if ($null -ne $script:BootState) { return $script:BootState }
}
function Get-CimInstance {
    param($ClassName, $OperationTimeoutSec, $ErrorAction)
    if ($ClassName -ne 'Win32_ComputerSystem') { throw "Unexpected CIM class: $ClassName" }
    return $script:Machine
}
function Get-BitLockerVolume {
    param($MountPoint, $ErrorAction)
    $script:BitLockerReads++
    if ($script:VolumeFailure) { throw $script:VolumeFailure }
    if ($null -ne $script:Volume) { return $script:Volume }
}
function Reset-Case {
    $script:BootReads = 0; $script:BitLockerReads = 0
    $script:SecureResult = $false; $script:SecureFailure = ''
    $script:Machine = [pscustomobject]@{ Manufacturer = 'QEMU'; Model = 'Standard PC (Q35 + ICH9, 2009)' }
    $script:BootState = [pscustomobject]@{ Enabled = 0; Capable = 0 }; $script:BootFailure = ''
    $script:Volume = [pscustomobject]@{ ProtectionStatus = 'Off' }; $script:VolumeFailure = ''
}
function Check-Case([string]$Name, [bool]$Expected) {
    $passed = $false; $message = ''
    try { Assert-InstallProtection | Out-Null; $passed = $true }
    catch { $message = $_.Exception.Message }
    if ($passed -ne $Expected) { throw "FAIL: $Name (expected success=$Expected; actual=$passed; error=$message)" }
    $script:Checks++
    Write-Output "PASS: $Name"
}
function Use-Undefined {
    $script:SecureFailure = 'Variable is currently undefined: 0xC0000100'
}

Reset-Case
Check-Case 'explicit false with BitLocker off succeeds' $true
if ($script:BootReads -ne 0) { throw 'FAIL: explicit false should not need fallback' }
Reset-Case; $script:SecureResult = $true
Check-Case 'explicit true rejects' $false
Reset-Case; $script:SecureResult = $null
Check-Case 'missing result rejects' $false
Reset-Case; $script:SecureResult = 'False'
Check-Case 'string False rejects' $false
Reset-Case; $script:SecureResult = 0
Check-Case 'numeric zero rejects' $false
Reset-Case; $script:SecureFailure = 'Access denied'
Check-Case 'access denied rejects' $false
Reset-Case; $script:SecureFailure = 'Cmdlet not supported on this platform'
Check-Case 'unsupported cmdlet error rejects' $false
Reset-Case; Use-Undefined
Check-Case 'QEMU undefined variable and disabled non-capable state succeeds' $true
if ($script:BootReads -ne 1) { throw 'FAIL: expected one independent boot-state query' }
Reset-Case; Use-Undefined; $script:Machine = [pscustomobject]@{ Manufacturer='VMware'; Model='Virtual Platform' }
Check-Case 'VMware undefined variable and disabled non-capable state succeeds' $true
Reset-Case; Use-Undefined; $script:Machine = [pscustomobject]@{ Manufacturer='innotek'; Model='VirtualBox' }
Check-Case 'VirtualBox undefined variable and disabled non-capable state succeeds' $true
Reset-Case; Use-Undefined; $script:Machine = [pscustomobject]@{ Manufacturer='Other'; Model='Desktop' }
Check-Case 'non-VM machine rejects undefined variable' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{ Enabled=1; Capable=0 }
Check-Case 'enabled non-capable rejects' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{ Enabled=0; Capable=1 }
Check-Case 'disabled capable rejects' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{ Enabled=1; Capable=1 }
Check-Case 'enabled capable rejects' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{ Enabled=2; Capable=0 }
Check-Case 'invalid enabled value rejects' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{ Enabled=0; Capable=2 }
Check-Case 'invalid capable value rejects' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{ Enabled=0 }
Check-Case 'missing capability rejects' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{ Capable=0 }
Check-Case 'missing enabled field rejects' $false
Reset-Case; Use-Undefined; $script:BootState = $null
Check-Case 'missing independent boot state rejects' $false
Reset-Case; Use-Undefined; $script:BootState = $false
Check-Case 'non-object independent boot state rejects' $false
Reset-Case; Use-Undefined; $script:BootState = [pscustomobject]@{Enabled='0'; Capable='0'}
Check-Case 'string-valued independent boot state rejects' $false
Reset-Case; Use-Undefined; $script:BootFailure = 'NT query failed'
Check-Case 'independent query failure rejects' $false
Reset-Case; $script:Volume = [pscustomobject]@{ProtectionStatus='On'}
Check-Case 'BitLocker on rejects explicit false' $false
Reset-Case; Use-Undefined; $script:Volume = [pscustomobject]@{ProtectionStatus='On'}
Check-Case 'BitLocker on rejects unsupported fallback' $false
Reset-Case; Use-Undefined; $script:Volume = $null
Check-Case 'missing BitLocker result rejects' $false
Reset-Case; Use-Undefined; $script:Volume = [pscustomobject]@{ProtectionStatus='Unknown'}
Check-Case 'unknown BitLocker protection rejects' $false
Reset-Case; Use-Undefined; $script:VolumeFailure = 'Access denied'
Check-Case 'BitLocker query error rejects' $false

Write-Output "$script:Checks protection checks passed; all operating-system queries were mocked."
