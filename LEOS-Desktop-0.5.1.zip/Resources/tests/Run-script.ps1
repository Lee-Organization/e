param([string]$ToolRoot,[string]$Python='python')
$ErrorActionPreference='Stop'
$package=Split-Path $PSScriptRoot
if(-not $ToolRoot) {
 foreach($base in @('C:\Users\admin\Documents\Codex\tools\VSBuildTools2022\VC\Tools\MSVC',"${env:ProgramFiles}\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC","${env:ProgramFiles}\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC")) {
  if(Test-Path -LiteralPath $base){$ToolRoot=(Get-ChildItem -LiteralPath $base -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName;break}
 }
}
if(-not $ToolRoot){throw 'Microsoft C++ build tools were not found. Pass -ToolRoot to choose them.'}
$bin=Join-Path $ToolRoot 'bin\Hostx64\x64'
$build=Join-Path $package 'build\script-checks'
New-Item -ItemType Directory -Force -Path $build | Out-Null
foreach($name in @('crypto','files','script')) {
 & "$bin\cl.exe" /nologo /c /W4 /WX /GS- /Zl /O1 /Oi "/I$ToolRoot\include" "/Fo$build\$name.obj" "$package\src\$name.c"
 if($LASTEXITCODE){throw "Compile failed: $name"}
}
& "$bin\cl.exe" /nologo /c /W4 /WX /GS- /Zl /O1 /Oi "/I$ToolRoot\include" "/Fo$build\script-tests.obj" "$PSScriptRoot\script-tests.c"
if($LASTEXITCODE){throw 'Compile failed: script tests'}
& "$bin\link.exe" /nologo /dll /noentry /nodefaultlib "/out:$build\script-tests.dll" "$build\script-tests.obj" "$build\crypto.obj" "$build\files.obj" "$build\script.obj"
if($LASTEXITCODE){throw 'Link failed: script tests'}
& $Python -c 'import ctypes,sys; n=ctypes.CDLL(sys.argv[1]).ScriptChecks(); print("Script checks:",n); sys.exit(0 if n>0 else 1)' "$build\script-tests.dll"
if($LASTEXITCODE){throw 'Script checks failed'}
