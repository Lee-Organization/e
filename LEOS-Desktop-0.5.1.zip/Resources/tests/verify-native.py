import ctypes,hashlib,zlib,json
from pathlib import Path
w=Path(__file__).resolve().parents[1]/'build'
a=ctypes.CDLL(str(w/'store-tests.dll')); n=a.RunStoreTests();assert n>0,n
b=ctypes.CDLL(str(w/'graphics-tests.dll')); g=b.GraphicsChecks();assert g>0,g
c=ctypes.CDLL(str(w/'input-tests.dll')); i=c.InputChecks();assert i==0,i
d=ctypes.CDLL(str(w/'script-tests.dll')); script=d.ScriptChecks();assert script>0,script
vectors=0
a.sha256.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_void_p];a.crc32.argtypes=[ctypes.c_void_p,ctypes.c_uint32];a.crc32.restype=ctypes.c_uint32
a.derive.argtypes=[ctypes.c_char_p,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
for data in [b'',b'abc',b'a'*1000,bytes(range(256))]:
 d=ctypes.create_string_buffer(32);a.sha256(data,len(data),d);assert d.raw==hashlib.sha256(data).digest();assert a.crc32(data,len(data))==zlib.crc32(data);vectors+=2
for rounds in [1,2,4096,20000]:
 d=ctypes.create_string_buffer(32);a.derive(b'password',b'salt',4,rounds,d);assert d.raw==hashlib.pbkdf2_hmac('sha256',b'password',b'salt',rounds);vectors+=1
result={'storage_files_scripts_checks':n,'graphics_editor_window_checks':g,'input_fallback_and_event_checks':3,'dedicated_script_checks':script,'crypto_vectors':vectors}
print(result)
(w/'native-tests.json').write_text(json.dumps(result,indent=2))
