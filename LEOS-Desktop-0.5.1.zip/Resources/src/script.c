#include "desktop.h"
static char output[8192],code[TEXT_CAP],linebuf[512],expanded[512],variable[128],state[48];
static u64 identity;static int running,node=-1,cwd;static u32 position,steps,delay,repeat_left;static char repeated[512];
static void emit(const char *s){u32 n=length(output),m=length(s);if(m>sizeof(output)-2)m=sizeof(output)-2;while(n+m+2>sizeof(output)){u32 cut=0;while(cut<n&&output[cut]!='\n')++cut;if(cut<n)++cut;if(!cut){output[0]=0;n=0;break;}memcopy(output,output+cut,n-cut+1);n-=cut;}memcopy(output+n,s,m);output[n+m]='\n';output[n+m+1]=0;}
static char *spaces(char *s){while(*s==' ')++s;return s;}
static int split(char *s,const char *cmd,char **arg){u32 n=length(cmd),i;for(i=0;i<n;++i)if(s[i]!=cmd[i])return 0;if(s[n]&&s[n]!=' ')return 0;*arg=spaces(s+n);return 1;}
static void fail(const char *s){emit(s);copytext(state,sizeof(state),"Stopped with an error");running=0;}
void script_clear(void){output[0]=0;}
void script_stop(void){if(running){running=0;copytext(state,sizeof(state),"Stopped");emit("Stopped by you.");}}
u64 script_identity(void){return identity;}
int script_running(void){return running;}int script_node(void){return node;}const char *script_output(void){return output;}const char *script_status(void){return state;}u32 script_steps(void){return steps;}
void script_start(int index){
 if(running){emit("Stop the running script first.");return;}
 if(!profile.scripts_enabled){emit("Scripts are disabled in Settings.");return;}
 if(index<0||index>=(int)profile.count||profile.files[index].kind!=NODE_FILE||fs_blocked(index)){emit("This script cannot run.");return;}
 node=index;identity=profile.files[index].id;cwd=profile.files[index].parent;copytext(code,sizeof(code),profile.files[index].text);position=steps=delay=repeat_left=0;variable[0]=0;output[0]=0;running=1;copytext(state,sizeof(state),"Running");emit(profile.files[index].name);
}
static void command(char *s){char *arg,*bar;int f,parent;u32 i,n,conditions=0;
 while(split(s,"ifexists",&arg)||split(s,"ifmissing",&arg)){
  int missing=s[2]=='m';if(++conditions>16){fail("Too many nested conditions.");return;}
  bar=arg;while(*bar&&*bar!='|')++bar;if(!*bar){fail("Use: ifexists PATH | COMMAND");return;}*bar++=0;n=length(arg);while(n&&arg[n-1]==' ')arg[--n]=0;bar=spaces(bar);
  if(!*arg||!*bar){fail("Use: ifexists PATH | COMMAND");return;}
  f=fs_resolve(cwd,arg);if((f==-2)!=missing)return;s=bar;
 }
 if(!*s||*s=='#')return;
 if(split(s,"echo",&arg)){emit(arg);return;}
 if(split(s,"let",&arg)){copytext(variable,sizeof(variable),arg);return;}
 if(split(s,"clear",&arg)){script_clear();return;}
 if(split(s,"help",&arg)){emit("echo, let, clear, stop, wait, repeat, ifexists, ifmissing");emit("pwd, cd, list, read, mkdir, write, append, appendline, rename, move, trash");return;}
 if(split(s,"pwd",&arg)){char path[DOCUMENTS*NAME_CAP];fs_path(cwd,path,sizeof(path));emit(path);return;}
 if(split(s,"stop",&arg)){running=0;copytext(state,sizeof(state),"Finished");return;}
 if(split(s,"wait",&arg)){if(*arg<'0'||*arg>'9'){fail("Use: wait NUMBER");return;}n=0;while(*arg>='0'&&*arg<='9'){n=n*10+(u32)(*arg++-'0');if(n>300){fail("Wait is limited to 300 ticks.");return;}}if(*arg){fail("Use: wait NUMBER");return;}delay=n;return;}
 if(split(s,"repeat",&arg)){n=0;while(*arg>='0'&&*arg<='9'){n=n*10+(u32)(*arg++-'0');if(n>100){fail("Repeat is limited to 100.");return;}}arg=spaces(arg);if(!n||!*arg){fail("Use: repeat COUNT COMMAND");return;}copytext(repeated,sizeof(repeated),arg);repeat_left=n;return;}
 if(split(s,"cd",&arg)){f=fs_resolve(cwd,arg);if(f==-2||(f>=0&&profile.files[f].kind!=NODE_FOLDER)){fail("Folder not found.");return;}cwd=f;return;}
 if(split(s,"list",&arg)){for(i=0;i<profile.count;++i)if(profile.files[i].kind&&profile.files[i].parent==cwd&&!fs_blocked((int)i))emit(profile.files[i].name);return;}
 if(split(s,"read",&arg)){f=fs_resolve(cwd,arg);if(f<0||profile.files[f].kind!=NODE_FILE){fail("File not found.");return;}emit(profile.files[f].text);return;}
 if(split(s,"mkdir",&arg)){fs_begin();f=fs_create(cwd,arg,NODE_FOLDER);if(f<0){fs_cancel();{fail("Couldn't create that folder.");return;}}if(!fs_commit()){fail("Couldn't save changes.");return;}return;}
 if(split(s,"trash",&arg)){f=fs_resolve(cwd,arg);if(f<0||fs_descendant(node,f)){fail("Cannot trash this item while running.");return;}fs_begin();if(!fs_trash(f)||!fs_commit()){fail("Couldn't move item to Trash.");return;}return;}
 if(split(s,"rename",&arg)||split(s,"move",&arg)){
  int move=s[0]=='m';bar=arg;while(*bar&&*bar!='|')++bar;if(!*bar){fail("Use: rename PATH | NAME, or move PATH | FOLDER");return;}*bar++=0;n=length(arg);while(n&&arg[n-1]==' ')arg[--n]=0;bar=spaces(bar);f=fs_resolve(cwd,arg);
  if(f<0||fs_descendant(node,f)){fail("Cannot change that item while running.");return;}
  fs_begin();if(move){parent=fs_resolve(cwd,bar);if(parent==-2||!fs_move(f,parent)){fs_cancel();fail("Couldn't move that item.");return;}}
  else if(!fs_rename(f,bar)){fs_cancel();fail("Couldn't rename that item.");return;}
  if(!fs_commit()){fail("Couldn't save changes.");return;}return;
 }
 if(split(s,"write",&arg)||split(s,"append",&arg)||split(s,"appendline",&arg)){
  int append=s[0]=='a',line=append&&s[6]=='l';static char value[TEXT_CAP];bar=arg;while(*bar&&*bar!='|')++bar;if(!*bar){fail("Use: write NAME | TEXT");return;}*bar++=0;n=length(arg);while(n&&arg[n-1]==' ')arg[--n]=0;bar=spaces(bar);
  f=fs_resolve(cwd,arg);fs_begin();if(f==-2){parent=cwd;f=fs_create(parent,arg,NODE_FILE);}if(f<0||f==node||profile.files[f].kind!=NODE_FILE){fs_cancel();{fail("Couldn't open that file for writing.");return;}}
  value[0]=0;if(append)copytext(value,sizeof(value),profile.files[f].text);n=length(value);if(n+length(bar)+(u32)line>=TEXT_CAP){fs_cancel();{fail("File is full.");return;}}copytext(value+n,TEXT_CAP-n,bar);if(line){n=length(value);value[n++]='\n';value[n]=0;}if(!fs_write(f,value)||!fs_commit()){fs_cancel();{fail("Couldn't save changes.");return;}}return;
 }
 fail("Unknown command. Open Help for script commands.");
}
void script_tick(void){u32 n=0,i,j;if(!running)return;if(!profile.scripts_enabled||profile.files[node].id!=identity||!profile.files[node].kind||fs_blocked(node)||fs_blocked(cwd)){script_stop();return;}if(delay){--delay;return;}if(++steps>512){fail("Stopped: 512 command limit.");return;}
 if(repeat_left){copytext(expanded,sizeof(expanded),repeated);--repeat_left;command(spaces(expanded));return;}
 else{if(!code[position]){running=0;copytext(state,sizeof(state),"Finished");emit("Done.");return;}while(code[position]&&code[position]!='\n'){if(n+1<sizeof(linebuf))linebuf[n++]=code[position];else {fail("Line is too long.");return;}++position;}if(code[position]=='\n')++position;linebuf[n]=0;}
 for(i=0,j=0;linebuf[i];++i){if(linebuf[i]=='$'){u32 k;for(k=0;variable[k];++k){if(j+1>=sizeof(expanded)){fail("Expanded line is too long.");return;}expanded[j++]=variable[k];}}else{if(j+1>=sizeof(expanded)){fail("Expanded line is too long.");return;}expanded[j++]=linebuf[i];}}expanded[j]=0;command(spaces(expanded));
}
