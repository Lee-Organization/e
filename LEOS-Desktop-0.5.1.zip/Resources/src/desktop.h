#ifndef LEOS_DESKTOP_H
#define LEOS_DESKTOP_H
#include "efi.h"
#define DOCUMENTS 64
#define TEXT_CAP 4096
#define NAME_CAP 48
#define PASSWORD_ROUNDS 20000
#define NODE_FOLDER 1
#define NODE_FILE 2
#define FLAG_TRASH 1
#define FLAG_QUARANTINE 2
#define FLAG_TRUSTED 4
#pragma pack(push,1)
typedef struct { u64 id; int parent; u32 kind,flags,length; char name[NAME_CAP]; char text[TEXT_CAP]; } Document;
typedef struct {
 char magic[8]; u32 version,size; u64 generation;
 char username[32]; u8 salt[16],verifier[32]; u32 rounds,accent,count;
 u64 identity,next_id;u32 theme,wallpaper,pointer_speed,cursor_size,clock12,lock_minutes,scripts_enabled;
 Document files[DOCUMENTS]; u32 checksum;
} Profile;
#pragma pack(pop)
extern Profile profile;
void memzero(void *,u64);void memcopy(void *,const void *,u64);u32 length(const char *);void copytext(char *,u32,const char *);int equal(const char *,const char *);
void sha256(const void *,u32,u8 out[32]);void derive(const char *,const u8 *,u32,u32,u8 out[32]);int constant_equal(const u8 *,const u8 *,u32);u32 crc32(const void *,u32);
int valid_profile(const Profile *);int store_open(System *,void *);int store_save(void);int store_load(void);void store_close(void);
void defaults(void);int name_valid(const char *);int fs_find(int,const char *);int fs_create(int,const char *,u32);int fs_write(int,const char *);int fs_rename(int,const char *);int fs_move(int,int);int fs_trash(int);int fs_restore(int);int fs_purge(int);int fs_blocked(int);int fs_descendant(int,int);int fs_resolve(int,const char *);void fs_path(int,char *,u32);int fs_commit(void);void fs_begin(void);void fs_cancel(void);
u64 script_identity(void);void script_start(int);void script_tick(void);void script_stop(void);void script_clear(void);int script_running(void);int script_node(void);const char *script_output(void);const char *script_status(void);u32 script_steps(void);
#endif
