#include "desktop.h"
#include "font.h"
#define VW 1280
#define VH 800
static System *system_table;
static void *image_handle;
static Gop *graphics;
static Pixel *frame,*background,*presentation;
static u32 display_width=VW,display_height=VH,view_x,view_y,view_width=VW,view_height=VH;
static u64 last_activity_seconds,last_clock_minute;
static Pointer *pointer;
static Absolute *absolute;
static int mx=640,my=400,screen,focus,start_open,app,selected=-1,editing=-1;
static int ox,oy,dragging=-1,drag_dx,drag_dy;
static u32 idle_ticks;
static int disk_ok,load_result,mouse_down,dirty=1;
static char name[32],password[64],confirm[64],filename[NAME_CAP],document[TEXT_CAP],notice[96];

static u32 colors[6]={0x167d8d,0x7353ba,0x008578,0xb75735,0x3769b1,0xad417b};
static u32 accent=0;
static int document_dirty;
static int clip_left,clip_top,clip_right=VW,clip_bottom=VH,editor_scroll,cursor_visible=1;
static int ps2_active,vm_mouse;
void VmPort(u32 *regs);
static InputEx *extended_input;
static Input *keyboard_fallback[16];
static u32 keyboard_count;
static void *input_timer;
static Guid keyboard_guid={0x387477c1,0x69c7,0x11d2,{0x8e,0x39,0,0xa0,0xc9,0x69,0x72,0x3b}};
static Guid extended_guid={0xdd9e7534,0x7762,0x4698,{0x8c,0x14,0xf5,0x85,0x17,0xa6,0x25,0xaa}};
static Guid graphics_guid={0x9042a9de,0x23dc,0x4a38,{0x96,0xfb,0x7a,0xde,0xd0,0x80,0x51,0x6a}};
static Guid pointer_guid={0x31878c87,0x0b75,0x11d5,{0x9a,0x4f,0,0x90,0x27,0x3f,0xc1,0x4d}};
static Guid absolute_guid={0x8d59d32b,0xc655,0x4ae9,{0x9b,0x15,0xf2,0x59,4,0x99,0x2a,0x43}};
static void connect_input(System *st) {
 void **handles=0;u64 count=0,i;
 /* Some firmware connects keyboard/video for boot but leaves pointing devices
    unconnected. Bind its existing drivers before choosing pointer protocols. */
 if(!BS(st,36,LocateHandleBuffer)(0,0,0,&count,&handles)&&count<4096){
  for(i=0;i<count;++i)BS(st,30,ConnectController)(handles[i],0,0,1);
  BS(st,6,FreePool)(handles);
 }
}
static void *physical_pointer(System *st,Guid *guid) {
 void **handles=0,*found=0,*p=0;u64 count=0,i;
 if(!BS(st,36,LocateHandleBuffer)(2,guid,0,&count,&handles)){
  for(i=0;i<count;++i)if(handles[i]!=st->in_handle&&!BS(st,16,HandleProtocol)(handles[i],guid,&p)){found=p;break;}
  BS(st,6,FreePool)(handles);
 }
 return found;
}
/* Development traces go to COM1 only, never into the visible interface. */
unsigned char __inbyte(unsigned short);
void __outbyte(unsigned short,unsigned char);
#pragma intrinsic(__inbyte,__outbyte)
static void trace(const char *s) { while(*s){u32 n=10000;while(!(__inbyte(0x3fd)&32)&&--n){}__outbyte(0x3f8,(u8)*s++);} }
static Pixel pixel(u32 rgb) { Pixel p;p.r=(u8)(rgb>>16);p.g=(u8)(rgb>>8);p.b=(u8)rgb;p.a=0;return p; }
static void dot(int x,int y,u32 rgb) { x+=ox;y+=oy;if(x>=0&&x<VW&&y>=0&&y<VH)frame[y*VW+x]=pixel(rgb); }
static void rect(int x,int y,int w,int h,u32 rgb) {
 int xx,yy,x1,y1;Pixel p=pixel(rgb);x+=ox;y+=oy;x1=x+w;y1=y+h;
 if(x<0)x=0;if(y<0)y=0;if(x1>VW)x1=VW;if(y1>VH)y1=VH;
 for(yy=y;yy<y1;++yy)for(xx=x;xx<x1;++xx)frame[yy*VW+xx]=p;
}
static void border(int x,int y,int w,int h,u32 rgb) { rect(x,y,w,1,rgb);rect(x,y+h-1,w,1,rgb);rect(x,y,1,h,rgb);rect(x+w-1,y,1,h,rgb); }
static int inside(int x,int y,int w,int h) { return mx>=x+ox&&mx<x+ox+w&&my>=y+oy&&my<y+oy+h; }
static void circle(int x,int y,int r,u32 rgb) { int xx,yy;for(yy=-r;yy<=r;++yy)for(xx=-r;xx<=r;++xx)if(xx*xx+yy*yy<=r*r)dot(x+xx,y+yy,rgb); }
static void line(int x,int y,int xx,int yy,u32 color) {
 int dx=xx-x,dy=yy-y,steps,i;if(dx<0)dx=-dx;if(dy<0)dy=-dy;steps=dx>dy?dx:dy;if(!steps){dot(x,y,color);return;}
 for(i=0;i<=steps;++i)dot(x+(xx-x)*i/steps,y+(yy-y)*i/steps,color);
}
static int text_width(const char *s,int font) {
 int width=0;while(*s){u8 c=(u8)*s++;if(c>=32&&c<127)width+=glyph[font][c-32].advance;}return width;
}
static void text(int x,int y,const char *s,int font,u32 rgb) {
 int xx,yy;Pixel fg=pixel(rgb);while(*s){u8 c=(u8)*s++;const Glyph *g;if(c<32||c>=127)c='?';g=&glyph[font][c-32];
  for(yy=0;yy<g->h;++yy)for(xx=0;xx<g->w;++xx){int px=x+xx+ox,py=y+yy+oy;u32 a=font_data[g->offset+yy*g->w+xx];Pixel *p;
   if(!a||px<0||px>=VW||py<0||py>=VH||px<clip_left||px>=clip_right||py<clip_top||py>=clip_bottom)continue;p=&frame[py*VW+px];
   p->r=(u8)((fg.r*a+p->r*(255-a))/255);p->g=(u8)((fg.g*a+p->g*(255-a))/255);p->b=(u8)((fg.b*a+p->b*(255-a))/255);
  }x+=g->advance;
 }
}
static void center(int x,int y,const char *s,int font,u32 color) { text(x-text_width(s,font)/2,y,s,font,color); }

/* Map a physical display to the logical desktop without stretching it. */
static void display_geometry(u32 width,u32 height) {
 display_width=width;display_height=height;
 if((u64)width*VH<=(u64)height*VW){view_width=width;view_height=(u32)((u64)width*VH/VW);}
 else{view_height=height;view_width=(u32)((u64)height*VW/VH);}
 view_x=(width-view_width)/2;view_y=(height-view_height)/2;
}
/* Map an arbitrary 64-bit firmware axis range without overflowing. */
static u32 axis_fraction(u64 value,u64 min,u64 max) {
 u64 span,rem;u32 result=0,i;if(max<=min||value<=min)return 0;if(value>=max)return 65535;
 span=max-min;rem=value-min;for(i=0;i<16;++i){result<<=1;if(rem>=span-rem){rem-=span-rem;++result;}else rem+=rem;}
 return result;
}
static int axis_desktop(u32 fraction,u32 physical,u32 offset,u32 extent,int logical) {
 u64 position=((u64)fraction*(physical-1)+32767)/65535;
 if(position<=offset)return 0;if(position>=offset+extent-1)return logical-1;
 return (int)((position-offset)*(u32)(logical-1)/(extent-1));
}
static void present(void) {
 u32 x,y;if(!presentation){graphics->blt(graphics,frame,2,0,0,0,0,VW,VH,VW*sizeof(Pixel));return;}
 for(y=0;y<view_height;++y){u32 sy=(u32)((u64)y*VH/view_height);for(x=0;x<view_width;++x){u32 sx=(u32)((u64)x*VW/view_width);presentation[y*view_width+x]=frame[sy*VW+sx];}}
 graphics->blt(graphics,presentation,2,0,0,view_x,view_y,view_width,view_height,(u64)view_width*sizeof(Pixel));
}
static u64 seconds_from_time(const Time *t) {
 static const u16 month_days[12]={0,31,59,90,120,151,181,212,243,273,304,334};
 u64 year,days;int leap;if(t->year<1900||t->month<1||t->month>12||t->day<1||t->day>31||t->hour>23||t->minute>59||t->second>59)return 0;
 year=(u64)t->year-1;leap=(t->year%4==0&&(t->year%100!=0||t->year%400==0));
 days=year*365+year/4-year/100+year/400+month_days[t->month-1]+(leap&&t->month>2)+(u64)t->day-1;
 return ((days*24+t->hour)*60+t->minute)*60+t->second;
}
static int idle_expired(u64 now,u64 last,u32 minutes) {return minutes&&last&&now>=last&&now-last>=(u64)minutes*60;}
static void lock_screen(void);
static void update_clock(void) {
 Time t;u64 now,minute;if(((GetTime)system_table->runtime->f[0])(&t,0)||(now=seconds_from_time(&t))==0){last_activity_seconds=0;return;}
 minute=now/60;if(last_clock_minute!=minute){last_clock_minute=minute;if(screen==3)dirty=1;}
 if(screen!=3||!idle_ticks||!last_activity_seconds||now<last_activity_seconds){last_activity_seconds=now;idle_ticks=1;return;}
 if(idle_expired(now,last_activity_seconds,profile.lock_minutes))lock_screen();
}

#include "ui.h"
/* Keep the same firmware console that worked in Boot Manager. Use alternate
   keyboard handles only when that console has no key, to avoid duplicates. */
static void keyboard_init(System *st) {
 void **handles=0;u64 count=0,i;void *p=0;
 if(st->input->reset)((ResetPointer)st->input->reset)(st->input,0);
 if(!BS(st,16,HandleProtocol)(st->in_handle,&extended_guid,&p))extended_input=(InputEx *)p;
 if(!BS(st,36,LocateHandleBuffer)(2,&keyboard_guid,0,&count,&handles)){
  for(i=0;i<count&&keyboard_count<16;++i){p=0;if(handles[i]!=st->in_handle&&!BS(st,16,HandleProtocol)(handles[i],&keyboard_guid,&p)&&p)keyboard_fallback[keyboard_count++]=(Input *)p;}
  BS(st,6,FreePool)(handles);
 }
 /* A periodic event lets firmware dispatch USB/PS2 input producers. Stall-only
    busy polling worked in our firmware build but is not a portable event loop. */
 if(!BS(st,7,CreateEvent)(0x80000000,0,0,0,&input_timer)){
  if(BS(st,8,SetTimer)(input_timer,1,160000)){input_timer=0;}
 }
}
static Status read_keyboard(System *st,Key *k) {
 Status r;u32 i;KeyData data;r=st->input->read(st->input,k);if(!r)return 0;
 if(extended_input&&!extended_input->read(extended_input,&data)){*k=data.key;return 0;}
 for(i=0;i<keyboard_count;++i)if(!keyboard_fallback[i]->read(keyboard_fallback[i],k))return 0;
 return r;
}
static void input_wait(System *st) {
 void *events[4];u64 count=0,index=0;
 if(!input_timer){BS(st,28,Stall)(16000);return;}
 events[count++]=input_timer;
 if(st->input->wait)events[count++]=st->input->wait;
 if(pointer&&pointer->wait)events[count++]=pointer->wait;
 if(absolute&&absolute->wait)events[count++]=absolute->wait;
 if(BS(st,9,WaitForEvent)(count,events,&index))BS(st,28,Stall)(16000);
}
/* Optional absolute pointer for QEMU VNC installations without a firmware
   tablet driver. Protocol constants documented by QEMU hw/i386/vmmouse.c;
   the implementation here is original. Keep PS/2 available as a fallback. */
static void vm_command(u32 cmd,u32 arg,u32 *r) {r[0]=0x564d5868;r[1]=arg;r[2]=cmd;r[3]=0;VmPort(r);}
static int vm_mouse_init(void) {
 u32 r[4];vm_command(10,0,r);if(r[1]!=0x564d5868||r[0]==0xffffffff)return 0;
 vm_command(41,0x45414552,r);vm_command(40,0,r);if((r[0]>>16)||(r[0]&65535)!=1)return 0;
 vm_command(39,1,r);if(r[0]!=0x3442554a)return 0;
 vm_command(41,0x53424152,r);return 1;
}
static void vm_mouse_poll(void) {
 u32 r[4],i;
 for(i=0;i<32;++i){int left;vm_command(40,0,r);if(r[0]>>16){vm_mouse=0;return;}if((r[0]&65535)<4)return;
  vm_command(39,4,r);if(r[0]&0x10000)continue;
  left=(r[0]&32)!=0;mouse_event(axis_desktop(r[1]&65535,display_width,view_x,view_width,VW),axis_desktop(r[2]&65535,display_height,view_y,view_height,VH),left);
 }
}
static int ps2_wait(void) {
 u32 i;for(i=0;i<2000;++i){if(!(__inbyte(0x64)&2))return 1;BS(system_table,28,Stall)(50);}return 0;
}
static int ps2_send(u8 value) {
 u32 i;if(!ps2_wait())return 0;__outbyte(0x64,0xd4);if(!ps2_wait())return 0;__outbyte(0x60,value);
 for(i=0;i<2000;++i){u8 status=__inbyte(0x64);if((status&0x21)==0x21)return __inbyte(0x60)==0xfa;BS(system_table,28,Stall)(50);}return 0;
}
static int ps2_init(void) {
 if(!ps2_wait())return 0;__outbyte(0x64,0xa8);
 return ps2_send(0xf6)&&ps2_send(0xf4);
}
static void ps2_poll(void) {
 static u8 packet[3];static u32 used;u32 i;
 for(i=0;i<48;++i){u8 status=__inbyte(0x64),byte;int dx,dy,left;
  if((status&0x21)!=0x21)return;byte=__inbyte(0x60);
  if(!used&&!(byte&8))continue;packet[used++]=byte;if(used<3)continue;used=0;
  if(packet[0]&0xc0||vm_mouse)continue;
  dx=(int)packet[1]-((packet[0]&16)?256:0);dy=(int)packet[2]-((packet[0]&32)?256:0);
  left=packet[0]&1;mouse_event(mx+dx*(profile.pointer_speed?profile.pointer_speed:2),my-dy*(profile.pointer_speed?profile.pointer_speed:2),left);
 }
}
Status EfiMain(void *image,System *st) {
 Status result;u32 mode;u64 size;GopInfo *info;Key k;
 if(!st||!st->boot||!st->input||!st->runtime)return ERR(2);system_table=st;image_handle=image;
 if(BS(st,37,LocateProtocol)(&graphics_guid,0,(void **)&graphics)||!graphics||!graphics->mode)return ERR(3);
 for(mode=0;mode<graphics->mode->max_mode;++mode){info=0;size=0;if(!graphics->query(graphics,mode,&size,&info)&&info){int match=info->width==VW&&info->height==VH;BS(st,6,FreePool)(info);if(match){if(graphics->mode->mode!=mode)graphics->set(graphics,mode);break;}}}
 if(!graphics->mode->info||graphics->mode->info->width<2||graphics->mode->info->height<2||graphics->mode->info->width>16384||graphics->mode->info->height>16384)return ERR(3);
 display_geometry(graphics->mode->info->width,graphics->mode->info->height);if(view_width<2||view_height<2)return ERR(3);
 if(BS(st,5,AllocatePool)(2,VW*VH*sizeof(Pixel),(void **)&frame)||BS(st,5,AllocatePool)(2,VW*VH*sizeof(Pixel),(void **)&background))return ERR(9);
 if(display_width!=VW||display_height!=VH){Pixel black=pixel(0);if(BS(st,5,AllocatePool)(2,(u64)view_width*view_height*sizeof(Pixel),(void **)&presentation))return ERR(9);graphics->blt(graphics,&black,0,0,0,0,0,display_width,display_height,0);}
 BS(st,29,Watchdog)(0,0,0,0);
 connect_input(st);
 pointer=(Pointer *)physical_pointer(st,&pointer_guid);absolute=(Absolute *)physical_pointer(st,&absolute_guid);
 if(pointer&&pointer->reset)((ResetPointer)pointer->reset)(pointer,0);
 if(absolute&&absolute->reset)((ResetPointer)absolute->reset)(absolute,0);
 if(st->output){typedef Status (*Cursor)(void *,u8);void **out=(void **)st->output;if(out[8])((Cursor)out[8])(st->output,0);}
 __outbyte(0x3f9,0);__outbyte(0x3fb,0x80);__outbyte(0x3f8,1);__outbyte(0x3f9,0);__outbyte(0x3fb,3);__outbyte(0x3fa,0xc7);__outbyte(0x3fc,0xb);
 trace(pointer?"INPUT:RELATIVE\n":"INPUT:NO-RELATIVE\n");trace(absolute?"INPUT:ABSOLUTE\n":"INPUT:NO-ABSOLUTE\n");
 keyboard_init(st);
 if(!pointer&&!absolute){ps2_active=ps2_init();trace(ps2_active?"INPUT:PS2-FALLBACK\n":"INPUT:NO-PS2\n");}
 /* Reset keyboard before enabling the auxiliary PS/2 channel: firmware
    keyboard resets may reconfigure the shared controller. */
 vm_mouse=vm_mouse_init();trace(vm_mouse?"INPUT:VM-ABSOLUTE\n":"INPUT:NO-VM-ABSOLUTE\n");
 if(!absolute){void *p=0;if(!BS(st,16,HandleProtocol)(st->in_handle,&absolute_guid,&p))absolute=(Absolute *)p;}
 if(!pointer){void *p=0;if(!BS(st,16,HandleProtocol)(st->in_handle,&pointer_guid,&p))pointer=(Pointer *)p;}
 trace(input_timer?"INPUT:EVENT-LOOP\n":"INPUT:POLL-LOOP\n");
 disk_ok=store_open(st,image);load_result=disk_ok?store_load():0;
 if(load_result<0)disk_ok=0;
 if(load_result==1){accent=profile.accent;screen=2;trace("UI:LOGIN\n");}else{defaults();screen=0;trace("UI:SETUP\n");}
 windows_init();
 wallpaper();render();
 for(;;){
  if(ps2_active)ps2_poll();
  if(vm_mouse)vm_mouse_poll();
  /* Console splitters and EVT_NOTIFY_WAIT producers must be checked so that
     their wait notifications poll the underlying devices before GetState. */
  if(st->input->wait)BS(st,12,CheckEvent)(st->input->wait);
  if(pointer&&pointer->wait)BS(st,12,CheckEvent)(pointer->wait);
  if(absolute&&absolute->wait)BS(st,12,CheckEvent)(absolute->wait);
  result=read_keyboard(st,&k);if(!result)key(k);
  if(pointer&&!vm_mouse){PointerState p;if(!pointer->get(pointer,&p))mouse_event(mx+p.x*(int)profile.pointer_speed,my+p.y*(int)profile.pointer_speed,p.left);}
  if(absolute&&absolute->mode&&!vm_mouse){AbsoluteState p;AbsoluteMode *m=absolute->mode;if(!absolute->get(absolute,&p)&&m->max_x>m->min_x&&m->max_y>m->min_y){mouse_event(axis_desktop(axis_fraction(p.x,m->min_x,m->max_x),display_width,view_x,view_width,VW),axis_desktop(axis_fraction(p.y,m->min_y,m->max_y),display_height,view_y,view_height,VH),(p.buttons&1)!=0);}}
  if(mx<0)mx=0;if(mx>VW-2)mx=VW-2;if(my<0)my=0;if(my>VH-2)my=VH-2;
  if(screen==3&&script_running()){script_tick();dirty=1;}
  update_clock();
  if(dirty)render();input_wait(st);
 }
}
