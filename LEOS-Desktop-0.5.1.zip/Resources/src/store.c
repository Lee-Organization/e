#include "desktop.h"
Profile profile;
static Profile scratch,verify;
static File *directory;
static int current=-1;
static const u16 *slots[2]={L"Desktop-A.dat",L"Desktop-B.dat"};
static int bounded(const char *p,u32 cap) { u32 i;for(i=0;i<cap;++i)if(!p[i])return 1;return 0; }
static int same_name(const char *a,const char *b) {
 int x,y;while(*a&&*b){x=(u8)*a++;y=(u8)*b++;if(x>='A'&&x<='Z')x+=32;if(y>='A'&&y<='Z')y+=32;if(x!=y)return 0;}return !*a&&!*b;
}
int valid_profile(const Profile *p) {
 u32 i,j;int parent,depth;
 if(!constant_equal((const u8 *)p->magic,(const u8 *)"LEOSGUI3",8)||p->version!=3||p->size!=sizeof(Profile)||!p->generation)return 0;
 if(p->count>DOCUMENTS||p->rounds!=PASSWORD_ROUNDS||p->accent>5||!p->username[0]||!bounded(p->username,32)||!p->next_id)return 0;
 if(p->theme>1||p->wallpaper>2||p->pointer_speed<1||p->pointer_speed>3||p->cursor_size<1||p->cursor_size>2||p->clock12>1||p->lock_minutes>60||p->scripts_enabled>1)return 0;
 for(i=0;i<p->count;++i){const Document *f=&p->files[i];if(!f->kind)continue;
  if((f->kind!=NODE_FOLDER&&f->kind!=NODE_FILE)||!f->id||f->id>=p->next_id||!f->name[0]||!bounded(f->name,NAME_CAP)||!name_valid(f->name)||f->length>=TEXT_CAP||f->flags>7)return 0;
  if(f->text[f->length]||length(f->text)!=f->length||(f->kind==NODE_FOLDER&&f->length))return 0;
  parent=f->parent;depth=0;while(parent>=0){if(parent>=(int)p->count||parent==(int)i||p->files[parent].kind!=NODE_FOLDER||++depth>DOCUMENTS)return 0;parent=p->files[parent].parent;}if(parent!=-1)return 0;
  for(j=0;j<i;++j)if(p->files[j].kind&&(f->id==p->files[j].id||(!(f->flags&FLAG_TRASH)&&!(p->files[j].flags&FLAG_TRASH)&&f->parent==p->files[j].parent&&same_name(f->name,p->files[j].name))))return 0;
 }
 return p->checksum==crc32(p,(u32)sizeof(Profile)-4);
}
int store_open(System *st,void *image) {
 Guid loaded={0x5b1b31a1,0x9562,0x11d2,{0x8e,0x3f,0,0xa0,0xc9,0x69,0x72,0x3b}};
 Guid filesystem={0x964e5b22,0x6459,0x11d2,{0x8e,0x39,0,0xa0,0xc9,0x69,0x72,0x3b}};
 Loaded *li=0;FS *fs=0;File *root=0;Status s;
 HandleProtocol handle=BS(st,16,HandleProtocol);
 if(handle(image,&loaded,(void **)&li)||!li)return 0;
 if(handle(li->device,&filesystem,(void **)&fs)||!fs)return 0;
 if(fs->open_volume(fs,&root)||!root)return 0;
 s=root->open(root,&directory,L"\\EFI\\LEOS-Data",3,0);
 if(s==ERR(14))s=root->open(root,&directory,L"\\EFI\\LEOS-Data",0x8000000000000003ull,16);
 root->close(root);
 return s==0&&directory!=0;
}
/* Read exactly one fixed-size journal record, reject extra/truncated data. */
static int read_slot(int index,Profile *p) {
 File *f=0;u64 n=sizeof(Profile),extra=1;u8 tail;Status s;
 s=directory->open(directory,&f,slots[index],1,0);
 if(s==ERR(14))return 0;
 if(s||!f)return -1;
 s=f->read(f,&n,p);
 if(!s&&n==sizeof(Profile)){s=f->read(f,&extra,&tail);if(extra)s=ERR(4);}else s=ERR(4);
 if(f->close(f))s=ERR(7);
 return !s&&valid_profile(p)?1:-1;
}
#pragma pack(push,1)
typedef struct {char name[24];u32 length;char text[2048];} OldDocument;
typedef struct {char magic[8];u32 version,size;u64 generation;char username[32];u8 salt[16],verifier[32];u32 rounds,accent,count;OldDocument files[8];u32 checksum;} OldProfile;
#pragma pack(pop)
static OldProfile legacy[2];
/* Legacy allowed trailing dots/spaces and case-only duplicate names. Keep each
   document under a valid, unique name rather than blocking account migration. */
static int migrate_name(int folder,const char *old,char out[NAME_CAP]) {
 char base[NAME_CAP];u32 i,n=0,suffix=2;
 while(old[n]&&n+1<NAME_CAP){char c=old[n];base[n]=(c<32||c=='/'||c=='\\'||c==':'||c=='*'||c=='?'||c=='"'||c=='<'||c=='>'||c=='|')?'_':c;++n;}
 while(n&&(base[n-1]==' '||base[n-1]=='.'))--n;
 if(!n){copytext(base,NAME_CAP,"Document");n=length(base);}else base[n]=0;
 if(base[0]=='.')base[0]='_';
 copytext(out,NAME_CAP,base);
 while(fs_find(folder,out)>=0){char digits[12];u32 count=0,k;unsigned int value=suffix++;do{digits[count++]=(char)('0'+value%10);value/=10;}while(value&&count<sizeof(digits));
  for(i=0;i<n&&i+count+2<NAME_CAP;++i)out[i]=base[i];out[i++]='~';for(k=count;k>0;--k)out[i++]=digits[k-1];out[i]=0;
 }
 return name_valid(out);
}
static int old_slot(int index){File *f=0;u64 n=sizeof(OldProfile),extra=1;u8 tail;Status s;u32 i;OldProfile *p=&legacy[index];
 s=directory->open(directory,&f,index?L"Profile-B.dat":L"Profile-A.dat",1,0);if(s==ERR(14))return 0;if(s||!f)return -1;
 s=f->read(f,&n,p);if(!s){s=f->read(f,&extra,&tail);if(extra)s=ERR(4);}if(f->close(f))s=ERR(7);if(s||n!=sizeof(OldProfile)||!constant_equal((u8 *)p->magic,(const u8 *)"LEOSGUI2",8)||p->size!=sizeof(OldProfile)||p->version!=2||p->count>8||p->rounds!=PASSWORD_ROUNDS||p->accent>2||!p->generation||!p->username[0]||!bounded(p->username,32))return -1;
 for(i=0;i<p->count;++i)if(!bounded(p->files[i].name,24)||p->files[i].length>=2048||p->files[i].text[p->files[i].length]||length(p->files[i].text)!=p->files[i].length)return -1;
 return p->checksum==crc32(p,sizeof(OldProfile)-4)?1:-1;
}
int store_load(void) {
 int a,b;if(!directory)return -1;
 a=read_slot(0,&profile);b=read_slot(1,&scratch);
 if(a==1&&(b!=1||profile.generation>=scratch.generation)){current=0;return 1;}
 if(b==1){memcopy(&profile,&scratch,sizeof(Profile));current=1;return 1;}
 memzero(&profile,sizeof(Profile));current=-1;if(a||b)return -1;
 a=old_slot(0);b=old_slot(1);
 if(a==1||b==1){OldProfile *old;u32 i;int folder;
  old=a==1&&(b!=1||legacy[0].generation>=legacy[1].generation)?&legacy[0]:&legacy[1];
  defaults();copytext(profile.username,32,old->username);memcopy(profile.salt,old->salt,16);memcopy(profile.verifier,old->verifier,32);profile.rounds=old->rounds;profile.accent=old->accent;memcopy(&profile.identity,profile.salt,8);
  folder=fs_create(-1,"Documents",NODE_FOLDER);if(folder<0)return -1;for(i=0;i<old->count;++i){char name[NAME_CAP];int f;if(!migrate_name(folder,old->files[i].name,name))return -1;f=fs_create(folder,name,NODE_FILE);if(f<0||!fs_write(f,old->files[i].text))return -1;}
  fs_create(-1,"Scripts",NODE_FOLDER);
  /* Old banks remain untouched even if migration cannot be committed. */
  return store_save()?1:-1;
 }
 return !a&&!b?0:-1;
}
/* EFI_FILE_PROTOCOL.Delete closes the handle even when deletion fails.  Only
   delete the inactive bank; the last committed record remains untouched. */
static int discard_slot(int index) {
 File *f=0;Status s=directory->open(directory,&f,slots[index],3,0);
 if(s==ERR(14))return 1;
 if(s||!f)return 0;
 if(!f->delete_file){f->close(f);return 0;}
 return ((Status (*)(File *))f->delete_file)(f)==0;
}
int store_save(void) {
 File *f=0;int target=current==0?1:0;u64 n=sizeof(Profile);Status s;
 if(!directory||profile.generation==~0ull)return 0;
 memcopy(&scratch,&profile,sizeof(Profile));
 memcopy(scratch.magic,"LEOSGUI3",8);scratch.version=3;scratch.size=sizeof(Profile);++scratch.generation;
 scratch.checksum=crc32(&scratch,(u32)sizeof(Profile)-4);
 if(!valid_profile(&scratch)||!discard_slot(target))return 0;
 s=directory->open(directory,&f,slots[target],0x8000000000000003ull,0);
 if(s||!f)return 0;
 s=f->set_position(f,0);if(!s)s=f->write(f,&n,&scratch);
 if(!s&&n!=sizeof(Profile))s=ERR(7);
 if(!s)s=f->flush(f);
 if(f->close(f))s=ERR(7);
 if(s||read_slot(target,&verify)!=1||!constant_equal((u8 *)&verify,(u8 *)&scratch,(u32)sizeof(Profile))){discard_slot(target);return 0;}
 memcopy(&profile,&scratch,sizeof(Profile));current=target;return 1;
}
void store_close(void) { if(directory)directory->close(directory);directory=0;memzero(&scratch,sizeof(scratch));memzero(&verify,sizeof(verify));memzero(legacy,sizeof(legacy)); }
