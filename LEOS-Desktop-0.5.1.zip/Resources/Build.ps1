param([string]$ToolRoot)
$ErrorActionPreference='Stop'
if (-not $ToolRoot) {
    $candidates=@(
        'C:\Users\admin\Documents\Codex\tools\VSBuildTools2022\VC\Tools\MSVC',
        "${env:ProgramFiles}\Microsoft Visual Studio\2022\BuildTools\VC\Tools\MSVC",
        "${env:ProgramFiles}\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC"
    )
    foreach($candidate in $candidates) {
        if(Test-Path -LiteralPath $candidate) {
            $ToolRoot=(Get-ChildItem -LiteralPath $candidate -Directory | Sort-Object Name -Descending | Select-Object -First 1).FullName
            break
        }
    }
}
if(-not $ToolRoot) { throw 'Supply -ToolRoot with an MSVC tools version directory.' }
$bin=Join-Path $ToolRoot 'bin\Hostx64\x64'
$temp=Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Force -Path $temp | Out-Null
foreach($file in @('crypto','store','files','script','gui','chooser')) {
    & "$bin\cl.exe" /nologo /c /W4 /WX /GS- /Zl /O1 /Oi /I"$ToolRoot\include" /Fo"$temp\$file.obj" "$PSScriptRoot\src\$file.c"
    if($LASTEXITCODE) { throw "Compile failed: $file" }
}
& "$bin\ml64.exe" /nologo /c /Fo"$temp\vmport.obj" "$PSScriptRoot\src\vmport.asm"
if($LASTEXITCODE) { throw 'VM mouse bridge compile failed' }
& "$bin\link.exe" /nologo /nodefaultlib /subsystem:efi_application /entry:EfiMain /machine:x64 /fixed:no /out:"$PSScriptRoot\LEOSCore.efi" "$temp\crypto.obj" "$temp\store.obj" "$temp\files.obj" "$temp\script.obj" "$temp\gui.obj" "$temp\vmport.obj"
if($LASTEXITCODE) { throw 'Link failed' }
& "$bin\link.exe" /nologo /nodefaultlib /subsystem:efi_application /entry:EfiMain /machine:x64 /fixed:no /out:"$PSScriptRoot\LEOS-Chooser.efi" "$temp\chooser.obj"
if($LASTEXITCODE) { throw 'Chooser link failed' }
Get-FileHash -Algorithm SHA256 -LiteralPath "$PSScriptRoot\LEOSCore.efi"
