@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Resources\LEOS-Desktop.ps1" -Action Remove
