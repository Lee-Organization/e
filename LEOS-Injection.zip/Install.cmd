@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LEOS-Injection.ps1" -Action Install
