#requires -Version 5.1
param([ValidateSet('Install','Remove')][string]$Action = 'Install')
$ErrorActionPreference = 'Stop'
$script:PayloadHash = '8F8AD4FE2E98BB1E82C67515FFFC374A5AD5E5D58F55B20A5A3E3E5F51A2CF11'
$script:Payload = 'TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAAA4fug4AtAnNIbgBTM0hVGhpcyBwcm9ncmFtIGNhbm5vdCBiZSBydW4gaW4gRE9TIG1vZGUuDQ0KJAAAAAAAAADROzPflVpdjJVaXYyVWl2MCNNZjZRaXYwI01+NlFpdjFJpY2iVWl2MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUEUAAGSGBQAvLe5qAAAAAAAAAADwACIgCwIOLAACAAAACAAAAAAAAAAQAAAAEAAAAAAAgAEAAAAAEAAAAAIAAAAAAAAAAAAAAQAAAAAAAAAAYAAAAAQAAIcjAAAKAAAAAAAQAAAAAAAAEAAAAAAAAAAAEAAAAAAAABAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAMAAAAAAAAAAAAAAAAUAAADAAAAJggAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALnRleHQAAADrAQAAABAAAAACAAAABAAAAAAAAAAAAAAAAAAAIAAAYC5yZGF0YQAAdAEAAAAgAAAAAgAAAAYAAAAAAAAAAAAAAAAAAEAAAEAuZGF0YQAAABgAAAAAMAAAAAIAAAAIAAAAAAAAAAAAAAAAAABAAADALnBkYXRhAAAMAAAAAEAAAAACAAAACgAAAAAAAAAAAAAAAAAAQAAAQC5yZWxvYwAADAAAAABQAAAAAgAAAAwAAAAAAAAAAAAAAAAAAEAAAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEiJXCQIVVZXQVZBV0iL7EiD7GBFM//HRUAA//8ATIl98EiL+kSJfThIhdIPhJwBAABIi1pgSIXbD4SPAQAASItCMEiFwA+EfgEAAEw5eAgPhHQBAABMObv4AAAAD4RnAQAASItKQEiFyXQSSItBCEiFwHQJSI0VhQ8AAP/QTDm7QAEAAA+EAgEAAEiLg0ABAABMjUXwSIsNdB8AADPS/9BIhcAPheMAAABIi03wSIXJD4TWAAAATItREE2F0g+EyQAAAEiLQRhIhcAPhLwAAABIi1AISIXSD4SvAAAASIN4ECQPgqQAAACDegQED4KaAAAAg3oIBA+CkAAAALgAgAAAOUIED4eCAAAAOUIId32LcghFM8lEi3IERTPATIl8JEhIjVU4SIl0JEBMiXQkOEyJfCQwTIl8JChMiXwkIEH/0kiFwHVGSItN8IvWTIl8JEhBi8ZI0epFM8lIiVQkQEUzwEyLURBIjVVASNHoSIlEJDhIwe4CScHuAkiJdCQwTIl0JChMiXwkIEH/0kGL90iLTzBIjVVISItBCP/QSLkGAAAAAAAAgEg7wXUrSIuD+AAAALmghgEA/9BIhcB1GP/Ggf6WAAAAcsYzwOsKSLgCAAAAAAAAgEiLnCSQAAAASIPEYEFfQV5fXl3DAAAAAAAAAAAAAAAAAAAAAAAAAAAATABFAE8AUwAgAFUAUwBCACAAVABFAFMAVAA6ACAAcAByAGUAcwBzACAAYQAgAGsAZQB5ACAAdABvACAAZQB4AGkAdAA7ACAAYQB1AHQAbwBtAGEAdABpAGMAIAByAGUAdAB1AHIAbgAgAGkAbgAgAGEAYgBvAHUAdAAgADEANQAgAHMAZQBjAG8AbgBkAHMALgANAAoAAAAAAAAALy3uagAAAAANAAAAiAAAANggAADYBgAAGAAAAAOAA4DMIAAABAAAANAgAAAIAAAAlRAAAAAQAADrAQAAAAAAAAAQAADrAQAALnRleHQkbW4AAAAAACAAALQAAAAucmRhdGEAALQgAAAkAAAALnJkYXRhJHZvbHRtZAAAANggAACIAAAALnJkYXRhJHp6emRiZwAAAGAhAAAUAAAALnhkYXRhAAAAMAAAGAAAAC5kYXRhAAAAAEAAAAwAAAAucGRhdGEAAAETCAATNBIAE7IM8ArgCHAHYAZQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADeqUKQ3CM4Spb7et7QgFFqADAAgAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAADrEQAAYCEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAAwAAAAQoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA='
$script:RelativePath = '\EFI\LEOS-Test\LEOS-Chooser.efi'
$script:ChooserHash = 'E1FA2BC8D380C780E9046DBA3DD82C0D14DD0EAA25A507764345100D534BFB61'
$script:ChooserPayload = 'TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAAA4fug4AtAnNIbgBTM0hVGhpcyBwcm9ncmFtIGNhbm5vdCBiZSBydW4gaW4gRE9TIG1vZGUuDQ0KJAAAAAAAAADROzPflVpdjJVaXYyVWl2MCNNZjZRaXYwI01+NlFpdjFJpY2iVWl2MAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUEUAAGSGBQCNbu5qAAAAAAAAAADwACIgCwIOLAAGAAAACgAAAAAAAAAQAAAAEAAAAAAAgAEAAAAAEAAAAAIAAAAAAAAAAAAAAQAAAAAAAAAAYAAAAAQAAGqkAAAKAAAAAAAQAAAAAAAAEAAAAAAAAAAAEAAAAAAAABAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAkAAAAAAAAAAAAAAAAUAAADAAAAGAiAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAALnRleHQAAADcBAAAABAAAAAGAAAABAAAAAAAAAAAAAAAAAAAIAAAYC5yZGF0YQAAaAMAAAAgAAAABAAAAAoAAAAAAAAAAAAAAAAAAEAAAEAuZGF0YQAAADAAAAAAMAAAAAIAAAAOAAAAAAAAAAAAAAAAAABAAADALnBkYXRhAAAkAAAAAEAAAAACAAAAEAAAAAAAAAAAAAAAAAAAQAAAQC5yZWxvYwAADAAAAABQAAAAAgAAABIAAAAAAAAAAAAAAAAAAEAAAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEiJXCQISIlsJBhIiXQkIFdBVEFWSIPsIIPN/0iL8kyL8UiF0g+EqgEAAEiLemBIhf8PhJ0BAABIi0IwSIXAD4SQAQAASIN4CAAPhIUBAABIi0JASIXAD4R4AQAASIN4CAAPhG0BAABIg7+YAAAAAA+EUwEAAEiDv8gAAAAAD4RFAQAASIO/0AAAAAAPhDcBAABIg7/gAAAAAA+EKQEAAEiDv/gAAAAAD4QbAQAASIuHAAEAAEiFwA+ECwEAAEUzyUUzwDPSM8n/0EiFwA+FDAEAAAvVSIvO6HgDAABEjWUCSItOMEiNVCRIi91Ii0EI/9BIuQYAAAAAAACASDvBdRhIi4f4AAAAuSBOAAD/0EiFwHTN6cYAAABIhcAPhb0AAAAPt0wkSmaD+TF1BDPt6yRmg/kydQVBi+zrGQ+3RCRIZkErxGZBO8R2WGaD+Q11kIXteIxIjQUVEAAAhe1MjQVUEAAASIvWTA9EwEmLzuiFAAAAg83/SIvOC9VIi9jo0QIAAEiF2w+EVP///0iLTkBIjRVpEAAASItBCP/Q6T7///8zyYvFZkQ5ZCRIQYvsD5TBK+uFwA9I6UiLzovV6JECAADpGP///0i4AwAAAAAAAIDrCki4AgAAAAAAAIBIi1wkQEiLbCRQSIt0JFhIg8QgQV5BXF/DzEiJXCQIVVZXQVZBV0iNrCTA/P//SIHsQAQAAEiLcmBFM/9IixX/HQAASYvYTIm9iAMAAEyNhYgDAABMiXwkMEyL8UyJvXgDAABIi4aYAAAA/9BIhcAPhd8BAABIi42IAwAASIXJD4TPAQAATDl5GA+ExQEAAEiLSRhMjUQkMEiLhpgAAABIixWkHQAA/9BIhcAPhaMBAABMi0QkME2FwA+ElQEAAEGLz0WLz0iF2w+EegEAAEIPtlQBA0IPtkQBAkjB4ghIC9BIg/oEckdBugAEAABMK9FJO9J3OUKAPAF/dEFMjVQkQE2L2EwD0UiNRCRATCvYSIv6Q4oEE0GIAkn/wkiD7wF18EgDykiB+fwDAAB2oEi4BAAAAAAAAIDpIQEAAEKAfAEB/w+FCwEAAEiD+gQPhQEBAABmRDk7dBNJgfnwAAAAc8xJ/8FmRjk8S3XtSo0UTQYAAABIjUIESTvCd7FIi8Jmx0QMQAQESMHoCEyNRCRFiEQMQ0iLwUgrw4hUDEJMA8BJ/8GKA0GIRBj/ikMBQYgEGEiNWwJJg+kBdehIjQQKSYvWSI2NeAMAAMdEBEB//wQASIuGyAAAAEyNRCRASIlMJCgzyUyJfCQg/9BIhcB1bUiLhgABAABFM8lFM8Az0rksAQAA/9BIi4bQAAAARTPASIuNeAMAADPS/9BMi5YAAQAARTPJRTPAM9IzyUiL2EH/0kiLluAAAABIi414AwAA/9JIi8PrFki4AgAAAAAAAIDrCki4AwAAAAAAAIBIi5wkcAQAAEiBxEAEAABBX0FeX15dw8xIiVwkCFdIg+wgSIvZi/pIi0lASItBMEiFwHQC/9BIi0tASI0VgwsAAEiLQQj/0EiLS0BIjQWiCwAAhf9IjRW5CwAASA9E0EiLQQj/0EiLS0BIjQXECwAAg/8BSI0V4gsAAEgPRNBIi0EI/9BIi0tASI0V9QsAAEiLQQhIi1wkMEiDxCBfSP/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0ACgAgAEwARQBPAFMAIABCAE8ATwBUACAATQBFAE4AVQANAAoADQAKAAAAAAAAACAAPgAgADEALgAgAFcAaQBuAGQAbwB3AHMADQAKAAAAIAAgACAAMQAuACAAVwBpAG4AZABvAHcAcwANAAoAAAAgAD4AIAAyAC4AIABMAEUATwBTACAAdABlAHMAdAANAAoAAAAAAAAAIAAgACAAMgAuACAATABFAE8AUwAgAHQAZQBzAHQADQAKAAAAAAAAAA0ACgAgAFAAcgBlAHMAcwAgADEAIABvAHIAIAAyACwAIABvAHIAIAB1AHMAZQAgAGEAcgByAG8AdwBzACAAdABoAGUAbgAgAEUAbgB0AGUAcgAuAA0ACgAgAE4AbwAgAGQAZQBmAGEAdQBsAHQAIABPAFMALgAgAFcAYQBpAHQAaQBuAGcAIABmAG8AcgAgAHkAbwB1AHIAIABjAGgAbwBpAGMAZQAuAA0ACgAAAAAAXABFAEYASQBcAE0AaQBjAHIAbwBzAG8AZgB0AFwAQgBvAG8AdABcAGIAbwBvAHQAbQBnAGYAdwAuAGUAZgBpAAAAAAAAAAAAXABFAEYASQBcAEwARQBPAFMALQBUAGUAcwB0AFwATABlAE8AUwBVAHMAYgBUAGUAcwB0AC4AZQBmAGkAAAAAAAAAAAAAAAAADQAKACAAQwBvAHUAbABkACAAbgBvAHQAIABzAHQAYQByAHQAIAB0AGgAYQB0ACAAbwBwAHQAaQBvAG4ALgAgAEMAaABvAG8AcwBlACAAYQBnAGEAaQBuAC4ADQAKAAAAAAAAAI1u7moAAAAADQAAAIgAAACkIgAApAwAABgAAAADgAOAlCIAAAgAAACcIgAACAAAABoSAAB9EgAAABAAANwEAAAAAAAAABAAANwEAAAudGV4dCRtbgAAAAAAIAAAfAIAAC5yZGF0YQAAfCIAACgAAAAucmRhdGEkdm9sdG1kAAAApCIAAIgAAAAucmRhdGEkenp6ZGJnAAAALCMAADwAAAAueGRhdGEAAAAwAAAwAAAALmRhdGEAAAAAQAAAJAAAAC5wZGF0YQAAAQoEAAo0BgAKMgZwARsJABs0jgAbAYgADPAK4AhwB2AGUAAAARgKABhkCwAYVAoAGDQIABgyFOASwBBwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAChMRtbYpXSEY4/AKDJaXI7kW5XCT9t0hGOOQCgyWlyOwAwAIABAAAAEDAAgAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAD3EQAAUCMAAPgRAABTFAAAOCMAAFQUAADcFAAALCMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADAAAAwAAAAgoCigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA='
$script:StateDir = Join-Path $env:ProgramData 'LEOS-Injection'
$script:StateFile = Join-Path $script:StateDir 'installation.json'

function Invoke-BCD([string[]]$BCDArgs) {
    $output = & "$env:SystemRoot\System32\bcdedit.exe" @BCDArgs 2>&1
    if ($LASTEXITCODE -ne 0) { throw "BCDEdit failed ($($BCDArgs -join ' ')): $($output -join ' ')" }
    return $output
}
function New-BcdBinding([string]$InstancePath) {
    # Embedded WMI output values are ManagementBaseObject data, not callable instances.
    # Rebind using the documented keys, then invoke through ManagementObject.
    $bound = [wmi]('\\.\root\WMI:' + $InstancePath)
    $bound.psbase.Scope.Options.EnablePrivileges = $true
    return $bound
}
function Invoke-BcdMethod($Object, [string]$Name, [hashtable]$Arguments) {
    $parameters = $Object.psbase.GetMethodParameters($Name)
    foreach ($key in $Arguments.Keys) { $parameters[$key] = $Arguments[$key] }
    return $Object.psbase.InvokeMethod($Name, $parameters, $null)
}
function Get-BCDStore {
    $provider = [wmiclass]'\\.\root\WMI:BcdStore'
    $provider.psbase.Scope.Options.EnablePrivileges = $true
    $result = Invoke-BcdMethod $provider 'OpenStore' @{File=''}
    if (-not $result.ReturnValue) { throw 'Cannot open the system BCD store.' }
    return (New-BcdBinding 'BcdStore.FilePath=""')
}
function New-FirmwareEntry([string]$Id) {
    $store = Get-BCDStore
    $result = Invoke-BcdMethod $store 'CreateObject' @{Id=$Id;Type=[uint32]0x101fffff}
    if (-not $result.ReturnValue) { throw 'Firmware application creation failed.' }
}
function Get-OwnedEntry([string]$Id) {
    if ($Id -notmatch '^\{[0-9a-fA-F]{8}(-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}\}$') { throw 'Invalid recorded entry ID.' }
    $store = Get-BCDStore
    $result = Invoke-BcdMethod $store 'OpenObject' @{Id=$Id}
    if (-not $result.ReturnValue) { return $null }
    $entry = $result.Object
    $callable = New-BcdBinding ('BcdObject.Id="' + $Id + '",StoreFilePath=""')
    $path = Invoke-BcdMethod $callable 'GetElement' @{Type=[uint32]0x12000002}
    $description = Invoke-BcdMethod $callable 'GetElement' @{Type=[uint32]0x12000004}
    if ($entry.Type -ne [uint32]0x101fffff -or -not $path.ReturnValue -or
        $path.Element.String -ne $script:RelativePath -or -not $description.ReturnValue -or
        $description.Element.String -ne 'LEOS boot menu') { throw 'Entry identity differs from LEOS; refusing to modify it.' }
    return $entry
}
function Assert-TestVM {
    if ([IntPtr]::Size -ne 8 -or $env:PROCESSOR_ARCHITECTURE -ne 'AMD64') { throw 'Use 64-bit Windows PowerShell on an x64 VM.' }
    Write-Host '[Check] VM and UEFI...'
    $machine = Get-CimInstance Win32_ComputerSystem -OperationTimeoutSec 20
    if (($machine.Manufacturer + ' ' + $machine.Model) -notmatch 'QEMU|VMware|VirtualBox|innotek|Virtual Machine|KVM|Xen|Parallels|HVM|Bochs') {
        throw 'This installer is VM-only. Physical-PC installation has not been validated.'
    }
    Invoke-BCD @('/enum','{fwbootmgr}') | Out-Null
}
function Assert-InstallProtection {
    Write-Host '[Check] Secure Boot and BitLocker...'
    if (Confirm-SecureBootUEFI) { throw 'Secure Boot is enabled. This unsigned test cannot be installed. No settings were changed.' }
    $vol = Get-BitLockerVolume -MountPoint $env:SystemDrive -ErrorAction Stop
    if ($null -eq $vol -or [string]$vol.ProtectionStatus -ne 'Off') {
        throw 'BitLocker protection is on or unknown. No settings were changed.'
    }
}
function Mount-TestESP {
    Write-Host '[Mount] EFI system partition...'
    foreach ($letter in 'SRQPONMLKJIHGFED'.ToCharArray()) {
        $drive = [string]$letter + ':'
        if (Get-PSDrive -Name ([string]$letter) -ErrorAction SilentlyContinue) { continue }
        $output = & "$env:SystemRoot\System32\mountvol.exe" $drive /S 2>&1
        if ($LASTEXITCODE -ne 0) { throw "EFI mount failed: $output" }
        if (-not (Test-Path -LiteralPath ($drive + '\EFI\Microsoft\Boot\bootmgfw.efi'))) {
            & "$env:SystemRoot\System32\mountvol.exe" $drive /D | Out-Null
            throw 'Mounted volume is not the expected Windows EFI partition.'
        }
        return $drive
    }
    throw 'No free drive letter.'
}
function Dismount-TestESP([string]$Drive) {
    $output = & "$env:SystemRoot\System32\mountvol.exe" $Drive /D 2>&1
    if ($LASTEXITCODE -ne 0) { Write-Warning "Could not remove temporary mount $Drive : $output" }
}
function Save-State($State) {
    $temp = $script:StateFile + '.tmp'
    $State | ConvertTo-Json | Set-Content -LiteralPath $temp -Encoding UTF8
    Move-Item -LiteralPath $temp -Destination $script:StateFile -Force
}
function Read-State {
    if (-not (Test-Path -LiteralPath $script:StateFile)) { return $null }
    $state = Get-Content -LiteralPath $script:StateFile -Raw | ConvertFrom-Json
    if ($state.Version -ne 2 -or $state.ChooserHash -ne $script:ChooserHash -or $state.Hash -ne $script:PayloadHash) { throw 'Unknown installation journal; refusing to continue.' }
    return $state
}
function Get-PayloadItems {
    @(
        [pscustomobject]@{Path='\EFI\LEOS-Test\LeOSUsbTest.efi';Hash=$script:PayloadHash;Data=$script:Payload;Owner='OwnFile'},
        [pscustomobject]@{Path=$script:RelativePath;Hash=$script:ChooserHash;Data=$script:ChooserPayload;Owner='OwnChooser'}
    )
}
function Assert-PayloadFiles([string]$Drive) {
    foreach ($item in Get-PayloadItems) {
        if ((Get-FileHash -LiteralPath ($Drive + $item.Path) -Algorithm SHA256).Hash -ne $item.Hash) { throw 'Installed EFI differs. No boot changes made.' }
    }
}
function Remove-OwnedFiles([string]$Drive, $State) {
    # Validate every owned file before deleting either one.
    foreach ($item in Get-PayloadItems) {
        $target = $Drive + $item.Path
        if ($State.($item.Owner) -and (Test-Path -LiteralPath $target)) {
            if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $item.Hash) { throw 'Installed EFI was modified; refusing to delete it.' }
        }
    }
    foreach ($item in Get-PayloadItems) {
        $target = $Drive + $item.Path
        if ($State.($item.Owner) -and (Test-Path -LiteralPath $target)) { Remove-Item -LiteralPath $target }
    }
}
function Install-Leos {
    Assert-TestVM
    Assert-InstallProtection
    $old = Read-State
    if ($old) {
        if ($old.Phase -eq 'Installed') {
            if ($null -eq (Get-OwnedEntry $old.Id)) { throw 'Recorded entry is missing. Use Remove, then install again.' }
            $drive = Mount-TestESP
            try {
                Assert-PayloadFiles $drive
            } finally { Dismount-TestESP $drive }
            Write-Host 'LEOS TEST is already installed. No duplicate added.'
            return
        }
        throw 'An incomplete install is recorded. Run Remove before trying again.'
    }
    foreach ($item in Get-PayloadItems) {
        $bytes = [Convert]::FromBase64String($item.Data)
        $sha = [Security.Cryptography.SHA256]::Create()
        try { $hash = ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','') } finally { $sha.Dispose() }
        if ($hash -ne $item.Hash) { throw 'Embedded EFI checksum mismatch.' }
    }
    Write-Host '[Backup] Saving boot configuration...'
    New-Item -ItemType Directory -Path $script:StateDir -Force | Out-Null
    $stamp = (Get-Date).ToString('yyyyMMdd-HHmmss-fff')
    Invoke-BCD @('/export',(Join-Path $script:StateDir ('BCD-' + $stamp + '.bak'))) | Out-Null
    Invoke-BCD @('/enum','firmware','/v') | Set-Content -LiteralPath (Join-Path $script:StateDir ('firmware-' + $stamp + '.txt'))
    $drive = Mount-TestESP
    $target = $drive + $script:RelativePath
    $state = [pscustomobject]@{Version=2;ChooserHash=$script:ChooserHash;OwnChooser=$false;Id=('{'+[guid]::NewGuid().ToString()+'}');Hash=$script:PayloadHash;OwnFile=$false;Phase='Preparing'}
    $createdEntry = $false
    try {
        foreach ($item in Get-PayloadItems) {
            $target = $drive + $item.Path
            if (Test-Path -LiteralPath $target) {
                if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash -ne $item.Hash) { throw 'A different EFI file already occupies a destination.' }
            } else { $state.($item.Owner) = $true }
        }
        Save-State $state
        Write-Host '[Copy] Installing verified EFI files...'
        foreach ($item in Get-PayloadItems) {
            $target = $drive + $item.Path
            New-Item -ItemType Directory -Path (Split-Path $target) -Force | Out-Null
            if ($state.($item.Owner)) {
                $bytes = [Convert]::FromBase64String($item.Data)
                $stream = [IO.File]::Open($target,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
                try { $stream.Write($bytes,0,$bytes.Length) } finally { $stream.Dispose() }
            }
        }
        Assert-PayloadFiles $drive
        $state.Phase = 'CreatingEntry'; Save-State $state
        Write-Host '[Register] Creating firmware entry...'
        New-FirmwareEntry $state.Id
        $createdEntry = $true
        Invoke-BCD @('/set',$state.Id,'description','LEOS boot menu') | Out-Null
        Invoke-BCD @('/set',$state.Id,'device',('partition='+$drive)) | Out-Null
        Invoke-BCD @('/set',$state.Id,'path',$script:RelativePath) | Out-Null
        Write-Host '[Register] Setting the startup menu first...'
        Invoke-BCD @('/set','{fwbootmgr}','displayorder',$state.Id,'/addfirst') | Out-Null
        if ($null -eq (Get-OwnedEntry $state.Id)) { throw 'Firmware entry verification failed.' }
        $state.Phase = 'Installed'; Save-State $state
        Write-Host 'LEOS boot menu installed first in firmware boot order.'
        Write-Host 'Restart normally. The menu waits for Windows or LEOS; neither OS is selected by default.'
    } catch {
        $original = $_
        Write-Host '[Rollback] Cleaning up this attempt...'
        $rollbackOK = $true
        if ($createdEntry) {
            try { Invoke-BCD @('/delete',$state.Id,'/cleanup') | Out-Null }
            catch { $rollbackOK=$false; Write-Warning 'Entry rollback failed; journal retained.' }
        }
        if ($rollbackOK -and (Test-Path -LiteralPath $script:StateFile)) {
            try { Remove-OwnedFiles $drive $state; Remove-Item -LiteralPath $script:StateFile }
            catch { Write-Warning 'File cleanup incomplete; journal retained for Remove.' }
        }
        throw $original
    } finally { Dismount-TestESP $drive }
}
function Remove-Leos {
    Assert-TestVM
    $state = Read-State
    if (-not $state) { Write-Host 'No installation is recorded. Nothing removed.'; return }
    # An incomplete journal is not enough authority to delete an unidentified entry.
    $entry = Get-OwnedEntry $state.Id
    if ($entry) { Invoke-BCD @('/delete',$state.Id,'/cleanup') | Out-Null }
    $drive = Mount-TestESP
    try { Remove-OwnedFiles $drive $state }
    finally { Dismount-TestESP $drive }
    Remove-Item -LiteralPath $script:StateFile
    Write-Host 'LEOS boot menu and installer-owned EFI files removed. Existing boot entries and backups kept.'
}
function Main {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        $exe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
        Start-Process -FilePath $exe -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Action '+$Action)
        return
    }
    Write-Host ('LEOS Injection - ' + $Action + ' (VM test build 2.1)')
    try {
        switch ($Action) { Install { Install-Leos } Remove { Remove-Leos } }
    } catch { Write-Host ('LEOS: '+$_.Exception.Message) -ForegroundColor Red }
    Read-Host 'Press Enter to close' | Out-Null
}
if ($MyInvocation.InvocationName -ne '.') { Main }

