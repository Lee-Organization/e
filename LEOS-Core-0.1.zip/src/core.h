#ifndef LEOS_CORE_H
#define LEOS_CORE_H
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
enum { TAG_CORE, TAG_SYSTEM, TAG_USER, TAG_BLOCKED };
enum { CLASS_KEYBOARD=1, CLASS_MOUSE=2, CLASS_STORAGE=4, CLASS_HIGH_RISK=8 };
enum { DEVICE_UNTRUSTED, DEVICE_QUARANTINE, DEVICE_ALLOWED };
enum { CORE_OK, CORE_DENIED, CORE_FULL, CORE_INVALID };
typedef struct { u64 username; char display[32]; u32 tag; } Process;
typedef struct { u64 identity; u32 device_class, state; } Device;
typedef struct { char name[24]; u8 content[256]; u32 size; } RamFile;
typedef struct {
    Process processes[16]; u32 process_count;
    Device devices[16]; u32 device_count;
    RamFile files[8]; u32 file_count;
    u64 next_username;
    u32 allowed_classes;
    /* Only Core initialization may seed Core identities. No runtime promotion. */
    u64 core_whitelist[2];
} Core;
void core_init(Core *c);
int core_register(Core *c, const char *display, u32 tag, u64 *username);
int core_rename(Core *c, u64 username, const char *display);
int core_is_core(const Core *c, u64 username);
int core_set_tag(Core *c, u64 actor, u64 target, u32 tag);
int core_add_device(Core *c, u64 identity, u32 device_class);
int core_driver_allowed(const Core *c, u64 actor, u64 device);
int core_file_write(Core *c, const char *name, const char *text);
const RamFile *core_file_read(const Core *c, const char *name);
int core_equal(const char *a, const char *b);
u32 core_selftest(void);
#endif
