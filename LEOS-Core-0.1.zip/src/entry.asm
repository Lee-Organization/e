; Windows x64 ABI: RCX = BootInfo, RDX = new stack top.
; No firmware calls after this handoff. Interrupts stay disabled during bring-up.
EXTERN CoreMain:PROC
.code
CoreEnter PROC
    cli
    mov rsp, rdx
    and rsp, -16
    sub rsp, 32
    xor rbp, rbp
    call CoreMain
halt_loop:
    cli
    hlt
    jmp halt_loop
CoreEnter ENDP
END
