#include "uefi.h"
#include "machine.h"
void CoreEnter(BootInfo *,void *);
static Guid graphics={0x9042a9de,0x23dc,0x4a38,{0x96,0xfb,0x7a,0xde,0xd0,0x80,0x51,0x6a}};
static BootInfo info;
static __declspec(align(16)) u8 kernel_stack[65536];
static void serial(const char *s) {
    while(*s) { u32 tries=100000; while(!(__inbyte(0x3fd)&32) && --tries) {} __outbyte(0x3f8,(u8)*s++); }
}
Status EfiMain(void *image,SystemTable *st) {
    BootServices *bs; Gop *g=0; GopInfo *m;
    u64 capacity=0,key=0,descriptor_size=0,size; u32 version=0,attempt;
    Status result; void *map=0;
    if(!st || !st->boot) return EFI_ERROR(2);
    bs=st->boot;
    if(!bs->locate_protocol || !bs->get_memory_map || !bs->allocate_pool || !bs->exit_boot_services || !bs->watchdog) return EFI_ERROR(3);
    if(bs->locate_protocol(&graphics,0,(void **)&g) || !g || !g->mode || !g->mode->info) return EFI_ERROR(3);
    m=g->mode->info;
    if(g->mode->info_size<sizeof(*m) || m->format>1 || m->width<320 || m->height<200 || m->width>8192 || m->height>8192 || m->stride<m->width || m->stride>16384 || !g->mode->base) return EFI_ERROR(3);
    if((u64)m->stride*m->height*4>g->mode->size) return EFI_ERROR(4);
    info.framebuffer=g->mode->base; info.size=g->mode->size;
    info.width=m->width; info.height=m->height; info.stride=m->stride; info.format=m->format;
    if(st->output && st->output->print) st->output->print(st->output,L"LEOS Core 0.1: starting standalone VM kernel.\r\n");
    result=bs->get_memory_map(&capacity,0,&key,&descriptor_size,&version);
    if(result!=EFI_ERROR(5) || !descriptor_size || capacity>16*1024*1024) return EFI_ERROR(4);
    capacity+=descriptor_size*64;
    result=bs->allocate_pool(2,capacity,&map); /* EfiLoaderData */
    if(result) return result;
    if(bs->watchdog(0,0,0,0)) return EFI_ERROR(3);
    /* COM1 is a QEMU bring-up console. No external devices are enumerated. */
    __outbyte(0x3f9,0); __outbyte(0x3fb,0x80); __outbyte(0x3f8,1);
    __outbyte(0x3f9,0); __outbyte(0x3fb,3); __outbyte(0x3fa,0xc7); __outbyte(0x3fc,0x0b);
    serial("LEOS: prepared firmware handoff\r\n");
    for(attempt=0;attempt<4;++attempt) {
        size=capacity;
        result=bs->get_memory_map(&size,map,&key,&descriptor_size,&version);
        if(result) break;
        /* No allocations, logging or other firmware calls between these calls. */
        result=bs->exit_boot_services(image,key);
        if(!result) {
            info.memory_map=map; info.map_size=size; info.descriptor_size=descriptor_size;
            CoreEnter(&info,kernel_stack+sizeof(kernel_stack));
            for(;;) { _disable(); __halt(); }
        }
        if(result!=EFI_ERROR(2)) break;
    }
    /* The first ExitBootServices may have partially shut firmware down.
       Do not call output/return into firmware after an attempted handoff. */
    serial("LEOS: firmware handoff failed; VM halted\r\n");
    for(;;) { _disable(); __halt(); }
}
