/* LEOS x64 UEFI boot chooser. No disk writes. No timeout or default OS.
 * Uses this image's device path to load either EFI payload on the same ESP.
 */
typedef unsigned char U8;
typedef unsigned short U16;
typedef unsigned int U32;
typedef unsigned __int64 U64;
typedef U64 STATUS;
typedef U64 UINTN;
#define SUCCESS ((STATUS)0)
#define NOT_READY (((STATUS)1<<63)|6)
#define INVALID_PARAMETER (((STATUS)1<<63)|2)
#define UNSUPPORTED (((STATUS)1<<63)|3)
#define BAD_BUFFER_SIZE (((STATUS)1<<63)|4)
typedef struct { U64 Signature; U32 Revision, HeaderSize, CRC32, Reserved; } HEADER;
typedef struct { U32 A; U16 B,C; U8 D[8]; } GUID;
typedef struct { U16 ScanCode, UnicodeChar; } KEY;
typedef struct INPUT INPUT;
struct INPUT { void *Reset; STATUS (*ReadKey)(INPUT *,KEY *); void *WaitForKey; };
typedef struct OUTPUT OUTPUT;
struct OUTPUT {
    void *Reset; STATUS (*Print)(OUTPUT *,const U16 *);
    void *TestString,*QueryMode,*SetMode,*SetAttribute;
    STATUS (*Clear)(OUTPUT *);
};
typedef struct {
    HEADER Hdr;
    void *BeforeHandle[16];
    STATUS (*HandleProtocol)(void *,GUID *,void **);
    void *BeforeLoad[5];
    STATUS (*LoadImage)(U8,void *,void *,void *,UINTN,void **);
    STATUS (*StartImage)(void *,UINTN *,U16 **);
    void *Exit;
    STATUS (*UnloadImage)(void *);
    void *ExitBootServices,*GetNextMonotonicCount;
    STATUS (*Stall)(UINTN);
    STATUS (*SetWatchdogTimer)(UINTN,U64,UINTN,U16 *);
} BOOT;
typedef struct {
    HEADER Hdr; U16 *FirmwareVendor; U32 FirmwareRevision;
    void *ConsoleInHandle; INPUT *ConIn;
    void *ConsoleOutHandle; OUTPUT *ConOut;
    void *StandardErrorHandle; OUTPUT *StdErr;
    void *RuntimeServices; BOOT *BootServices;
} SYSTEM;
typedef struct {
    U32 Revision; void *ParentHandle; SYSTEM *SystemTable;
    void *DeviceHandle; void *FilePath;
} LOADED_IMAGE;
typedef char check_header[(sizeof(HEADER)==24)?1:-1];
typedef char check_boot[(sizeof(BOOT)==264)?1:-1];
typedef char check_system[(sizeof(SYSTEM)==104)?1:-1];
static GUID loadedGuid={0x5b1b31a1,0x9562,0x11d2,{0x8e,0x3f,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static GUID pathGuid={0x09576e91,0x6d3f,0x11d2,{0x8e,0x39,0x00,0xa0,0xc9,0x69,0x72,0x3b}};
static GUID * volatile loadedPointer=&loadedGuid;
static GUID * volatile pathPointer=&pathGuid;
static STATUS MakePath(const U8 *base,const U16 *file,U8 *out,UINTN capacity) {
    UINTN pos=0,len=0,i,node;
    if(!base || !file || capacity<8) return INVALID_PARAMETER;
    for(;;) {
        if(pos>capacity-4) return BAD_BUFFER_SIZE;
        node=(UINTN)base[pos+2]|((UINTN)base[pos+3]<<8);
        if(node<4 || node>capacity-pos) return BAD_BUFFER_SIZE;
        if(base[pos]==127) {
            if(base[pos+1]!=255 || node!=4) return UNSUPPORTED;
            break;
        }
        for(i=0;i<node;++i) out[pos+i]=base[pos+i];
        pos+=node;
    }
    while(file[len]) { if(len>=240) return BAD_BUFFER_SIZE; ++len; }
    node=4+(len+1)*2;
    if(node+4>capacity-pos) return BAD_BUFFER_SIZE;
    out[pos]=4; out[pos+1]=4; out[pos+2]=(U8)node; out[pos+3]=(U8)(node>>8);
    for(i=0;i<=len;++i) { out[pos+4+i*2]=(U8)file[i]; out[pos+5+i*2]=(U8)(file[i]>>8); }
    pos+=node; out[pos]=127; out[pos+1]=255; out[pos+2]=4; out[pos+3]=0;
    return SUCCESS;
}
static void Menu(SYSTEM *st,int selected) {
    if(st->ConOut->Clear) st->ConOut->Clear(st->ConOut);
    st->ConOut->Print(st->ConOut,L"\r\n Boot Manager\r\n\r\n");
    st->ConOut->Print(st->ConOut,selected==0?L" > 1. Windows\r\n":L"   1. Windows\r\n");
    st->ConOut->Print(st->ConOut,selected==1?L" > 2. LEOS\r\n":L"   2. LEOS\r\n");

}
static STATUS Launch(void *image,SYSTEM *st,const U16 *file) {
    U8 path[1024];
    LOADED_IMAGE *loaded=0;
    U8 *devicePath=0;
    void *child=0;
    STATUS status;
    BOOT *bs=st->BootServices;
    status=bs->HandleProtocol(image,loadedPointer,(void **)&loaded);
    if(status!=SUCCESS || !loaded || !loaded->DeviceHandle) return UNSUPPORTED;
    status=bs->HandleProtocol(loaded->DeviceHandle,pathPointer,(void **)&devicePath);
    if(status!=SUCCESS || !devicePath) return UNSUPPORTED;
    status=MakePath(devicePath,file,path,sizeof(path));
    if(status!=SUCCESS) return status;
    status=bs->LoadImage(0,image,path,0,0,&child);
    if(status!=SUCCESS) return status;
    bs->SetWatchdogTimer(300,0,0,0);
    status=bs->StartImage(child,0,0);
    bs->SetWatchdogTimer(0,0,0,0);
    bs->UnloadImage(child);
    return status;
}
STATUS EfiMain(void *image,SYSTEM *st) {
    BOOT *bs;
    KEY key;
    STATUS status;
    int selected=-1,launch;
    if(!st || !st->BootServices || !st->ConIn || !st->ConIn->ReadKey || !st->ConOut || !st->ConOut->Print) return INVALID_PARAMETER;
    bs=st->BootServices;
    if(!bs->HandleProtocol || !bs->LoadImage || !bs->StartImage || !bs->UnloadImage || !bs->Stall || !bs->SetWatchdogTimer) return UNSUPPORTED;
    /* Disable the firmware application watchdog so the menu can wait indefinitely. */
    status=bs->SetWatchdogTimer(0,0,0,0);
    if(status!=SUCCESS) return status;
    Menu(st,selected);
    for(;;) {
        status=st->ConIn->ReadKey(st->ConIn,&key);
        if(status==NOT_READY) { status=bs->Stall(20000); if(status!=SUCCESS) return status; continue; }
        if(status!=SUCCESS) return status;
        launch=0;
        if(key.UnicodeChar=='1') { selected=0; launch=1; }
        else if(key.UnicodeChar=='2') { selected=1; launch=1; }
        else if(key.ScanCode==1 || key.ScanCode==2) { selected=selected<0?(key.ScanCode==1?1:0):1-selected; Menu(st,selected); }
        else if(key.UnicodeChar==13 && selected>=0) launch=1;
        if(!launch) continue;
        status=Launch(image,st,selected==0?L"\\EFI\\Microsoft\\Boot\\bootmgfw.efi":L"\\EFI\\LEOS-Core\\LEOSCore.efi");
        selected=-1;
        Menu(st,selected);
        if(status!=SUCCESS) st->ConOut->Print(st->ConOut,L"\r\n Could not start that option. Choose again.\r\n");
    }
}

