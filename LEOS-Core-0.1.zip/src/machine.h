#ifndef LEOS_MACHINE_H
#define LEOS_MACHINE_H
unsigned char __inbyte(unsigned short);
void __outbyte(unsigned short,unsigned char);
void _disable(void);
void __halt(void);
void _mm_pause(void);
#pragma intrinsic(__inbyte,__outbyte,_disable,__halt,_mm_pause)
#endif
