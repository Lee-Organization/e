#include "uefi.h"
#include "machine.h"
/* Original 5x7 development font. Uppercase display; command data retains case. */
static const char symbols[]="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 .,:;!?-_/\\><=+()[]#'\"|";
static const u8 glyphs[][7]={
 {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},
 {30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
 {14,17,16,23,17,17,14},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},
 {7,2,2,2,2,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
 {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},
 {30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
 {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},
 {17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
 {17,17,10,4,4,4,4},{31,1,2,4,8,16,31},
 {14,17,19,21,25,17,14},{4,12,4,4,4,4,14},{14,17,1,2,4,8,31},
 {30,1,1,14,1,1,30},{2,6,10,18,31,2,2},{31,16,16,30,1,1,30},
 {14,16,16,30,17,17,14},{31,1,2,4,8,8,8},{14,17,17,14,17,17,14},
 {14,17,17,15,1,1,14},
 {0,0,0,0,0,0,0},{0,0,0,0,0,12,12},{0,0,0,0,4,4,8},
 {0,4,4,0,4,4,0},{0,4,4,0,4,4,8},{4,4,4,4,4,0,4},
 {14,17,1,2,4,0,4},{0,0,0,31,0,0,0},{0,0,0,0,0,0,31},
 {1,2,2,4,8,8,16},{16,8,8,4,2,2,1},{16,8,4,2,4,8,16},
 {1,2,4,8,4,2,1},{0,0,31,0,31,0,0},{0,4,4,31,4,4,0},
 {2,4,8,8,8,4,2},{8,4,2,2,2,4,8},{14,8,8,8,8,8,14},
 {14,2,2,2,2,2,14},{10,10,31,10,31,10,10},{4,4,8,0,0,0,0},
 {10,10,0,0,0,0,0},{4,4,4,4,4,4,4}
};
static BootInfo boot;
static Core core;
static u32 col,row,scale,cols,rows;
static u32 color(u32 rgb) {
    if(boot.format==1) return rgb;
    return ((rgb&255)<<16)|(rgb&0xff00)|((rgb>>16)&255);
}
static void serial_char(char ch) {
    u32 n=100000; while(!(__inbyte(0x3fd)&32)&&--n) {} __outbyte(0x3f8,(u8)ch);
}
static void clear_screen(void) {
    volatile u32 *p=(volatile u32 *)boot.framebuffer; u32 x,y;
    for(y=0;y<boot.height;++y) for(x=0;x<boot.width;++x) p[(u64)y*boot.stride+x]=color(0x0b1420);
    row=col=0;
}
static void newline(void) {
    volatile u32 *p=(volatile u32 *)boot.framebuffer; u32 x,y,h=9*scale;
    col=0;
    if(++row<rows) return;
    for(y=0;y<boot.height-h;++y) for(x=0;x<boot.width;++x) p[(u64)y*boot.stride+x]=p[(u64)(y+h)*boot.stride+x];
    for(;y<boot.height;++y) for(x=0;x<boot.width;++x) p[(u64)y*boot.stride+x]=color(0x0b1420);
    row=rows-1;
}
static void display_char(char ch) {
    volatile u32 *p=(volatile u32 *)boot.framebuffer;
    u32 i=0,x,y,dx,dy,bits;
    if(ch=='\r') { col=0; return; }
    if(ch=='\n') { newline(); return; }
    if(ch=='\b') { if(col) --col; else if(row) { --row; col=cols-1; } ch=' '; }
    if(ch>='a'&&ch<='z') ch-=32;
    while(symbols[i] && symbols[i]!=ch) ++i;
    if(!symbols[i]) i=42; /* '?' */
    for(y=0;y<9;++y) { bits=y<7?glyphs[i][y]:0;
        for(x=0;x<6;++x) for(dy=0;dy<scale;++dy) for(dx=0;dx<scale;++dx)
            p[(u64)(row*9*scale+y*scale+dy)*boot.stride+col*6*scale+x*scale+dx]=color(x<5&&(bits&(16>>x))?0xd5eaf7:0x0b1420);
    }
    if(++col>=cols) newline();
}
static void put(char ch) { serial_char(ch); display_char(ch); }
static void print(const char *s) { while(*s) put(*s++); }
static void number(u64 value) {
    char s[24]; u32 i=0; do { s[i++]=(char)('0'+value%10); value/=10; } while(value);
    while(i) put(s[--i]);
}
static const char *tag(u32 t) {
    return t==TAG_CORE?"Core":t==TAG_SYSTEM?"System":t==TAG_USER?"User":"Blocked";
}
static int input(void) {
    static int shift,extended;
    static const char normal[]="\0" "\033" "1234567890-=\b\tqwertyuiop[]\r\0asdfghjkl;'`\0\\zxcvbnm,./\0*\0 ";
    u8 scan;
    if(__inbyte(0x3fd)&1) return __inbyte(0x3f8);
    if(!(__inbyte(0x64)&1)) return -1;
    scan=__inbyte(0x60);
    if(scan==0xe0||scan==0xe1) { extended=1; return -1; }
    if(extended) { extended=0; return -1; }
    if(scan==42||scan==54) { shift=1; return -1; }
    if(scan==170||scan==182) { shift=0; return -1; }
    if(scan>=58) return -1;
    { char ch=normal[scan];
      if(shift && ch>='a'&&ch<='z') ch-=32;
      return ch?ch:-1;
    }
}
static void status(void) {
    print("LEOS Core 0.1 - standalone x64 bring-up\n");
    print("UEFI boot services: EXITED; own stack and console\n");
    print("Core/System/User policy records: active\n");
    print("Process scheduler, page isolation, USB, IOMMU: NOT IMPLEMENTED\n");
    print("Signed images, Defender, secure input: NOT IMPLEMENTED\n");
    print("Files and usernames: RAM only; lost on reboot\n");
}
static void demo(void) {
    u64 id=0;
    print("Policy selftest failures: "); number(core_selftest()); print("\n");
    if(core_register(&core,"Core",TAG_USER,&id)==CORE_OK) {
        print("Registered display name Core, username "); number(id);
        print("; trusted as Core: "); number((u64)core_is_core(&core,id)); print("\n");
        print("System request to give it Core tag: ");
        print(core_set_tag(&core,2,id,TAG_CORE)==CORE_DENIED?"DENIED\n":"ERROR\n");
    } else print("Process table full; demo uses no replacement records.\n");
    print("Unknown USB, quarantine storage and high-risk bus: DENIED\n");
    print("Policy tests only; real hardware isolation is not enabled.\n");
}
static void command(char *s) {
    char *arg=s,*rest; u32 i;
    while(*arg && *arg!=' ') ++arg;
    if(*arg) *arg++=0;
    while(*arg==' ') ++arg;
    for(i=0;s[i];++i) if(s[i]>='A'&&s[i]<='Z') s[i]+=32;
    if(core_equal(s,"help")) print("help status memory ps devices demo selftest clear\nls write NAME TEXT read NAME reboot\n");
    else if(core_equal(s,"status")) status();
    else if(core_equal(s,"memory")) {
        u64 total=0,offset;
        for(offset=0;offset+boot.descriptor_size<=boot.map_size;offset+=boot.descriptor_size) {
            MemoryDescriptor *d=(MemoryDescriptor *)((u8 *)boot.memory_map+offset);
            if(d->type==7) total+=d->pages;
        }
        print("Conventional RAM at handoff: "); number(total*4); print(" KiB\n");
        print("Firmware mappings retained. No general allocator or page isolation yet.\n");
    } else if(core_equal(s,"ps")) {
        print("USERNAME  DISPLAY  TAG (identity records; not scheduled tasks)\n");
        for(i=0;i<core.process_count;++i) { number(core.processes[i].username); print("  "); print(core.processes[i].display); print("  "); print(tag(core.processes[i].tag)); print("\n"); }
    } else if(core_equal(s,"devices")) print("No external buses enumerated. QEMU PS/2 + COM1 bring-up input only.\nUnknown-device policy defaults to DENY; real drivers are unfinished.\n");
    else if(core_equal(s,"demo")) demo();
    else if(core_equal(s,"selftest")) { print("Policy selftest failures: "); number(core_selftest()); print("\n"); }
    else if(core_equal(s,"clear")) clear_screen();
    else if(core_equal(s,"ls")) { for(i=0;i<core.file_count;++i) { print(core.files[i].name); print("  "); number(core.files[i].size); print(" bytes\n"); } }
    else if(core_equal(s,"write")) {
        rest=arg; while(*rest&&*rest!=' ') ++rest; if(*rest) *rest++=0;
        print(core_file_write(&core,arg,rest)==CORE_OK?"Saved in RAM.\n":"Invalid name, file too large, or RAM file table full.\n");
    } else if(core_equal(s,"read")) {
        const RamFile *f=core_file_read(&core,arg);
        if(f) { print((const char *)f->content); print("\n"); } else print("RAM file not found.\n");
    } else if(core_equal(s,"reboot")) {
        print("Restarting QEMU PC...\n");
        __outbyte(0x64,0xfe);
        for(;;) __halt();
    } else if(*s) print("Unknown command. Type help.\n");
}
void CoreMain(BootInfo *b) {
    char line[192]; u32 length=0; int ch,last_cr=0;
    boot=*b; scale=boot.width>=960 && boot.height>=600?2:1;
    cols=boot.width/(6*scale); rows=boot.height/(9*scale);
    clear_screen(); core_init(&core);
    print("LEOS CORE 0.1\n\n");
    status(); print("\nType help for commands.\nLEOS> ");
    for(;;) {
        ch=input(); if(ch<0) { _mm_pause(); continue; }
        if(ch=='\n'&&last_cr) { last_cr=0; continue; }
        last_cr=ch=='\r';
        if(ch=='\r'||ch=='\n') {
            put('\n'); line[length]=0; command(line); length=0; print("LEOS> ");
        } else if(ch=='\b'||ch==127) {
            if(length) { --length; serial_char('\b'); serial_char(' '); serial_char('\b');
                /* display_char backspace erases then advances; move back again. */
                { u32 previous_col=col?col-1:cols-1,previous_row=col?row:(row?row-1:0);
                  display_char('\b'); col=previous_col; row=previous_row;
                }
            }
        } else if(ch>=32&&ch<=126&&length+1<sizeof(line)) { line[length++]=(char)ch; put((char)ch); }
    }
}
