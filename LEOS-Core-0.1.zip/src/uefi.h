#ifndef LEOS_UEFI_H
#define LEOS_UEFI_H
#include "core.h"
typedef u64 Status;
#define EFI_ERROR(n) (0x8000000000000000ull | (n))
typedef struct { u64 signature; u32 revision,size,crc,reserved; } Header;
typedef struct { u32 a; u16 b,c; u8 d[8]; } Guid;
typedef struct { u32 version,width,height,format,masks[4],stride; } GopInfo;
typedef struct { u32 max_mode,mode; GopInfo *info; u64 info_size,base,size; } GopMode;
typedef struct { void *query,*set,*blt; GopMode *mode; } Gop;
typedef struct { void *reset; Status (*print)(void *,const u16 *); } TextOut;
typedef struct {
    Header header;
    void *raise_tpl,*restore_tpl,*allocate_pages,*free_pages;
    Status (*get_memory_map)(u64 *,void *,u64 *,u64 *,u32 *);
    Status (*allocate_pool)(u32,u64,void **);
    Status (*free_pool)(void *);
    void *events[9];
    Status (*handle_protocol)(void *,Guid *,void **);
    void *protocols[5];
    void *load_image,*start_image,*exit,*unload_image;
    Status (*exit_boot_services)(void *,u64);
    void *monotonic,*stall;
    Status (*watchdog)(u64,u64,u64,u16 *);
    void *controllers[2],*open_protocol,*close_protocol,*open_info;
    void *protocols_per_handle,*locate_handle_buffer;
    Status (*locate_protocol)(Guid *,void *,void **);
} BootServices;
typedef struct {
    Header header; u16 *vendor; u32 revision;
    void *in_handle,*input,*out_handle; TextOut *output;
    void *err_handle,*error,*runtime; BootServices *boot;
} SystemTable;
typedef struct { u32 type,pad; u64 physical,virtual_address,pages,attributes; } MemoryDescriptor;
typedef struct {
    u64 framebuffer,size; u32 width,height,stride,format;
    void *memory_map; u64 map_size,descriptor_size;
} BootInfo;
typedef char check_boot_size[(sizeof(BootServices)==328)?1:-1];
typedef char check_system_size[(sizeof(SystemTable)==104)?1:-1];
typedef char check_descriptor_size[(sizeof(MemoryDescriptor)==40)?1:-1];
#endif
