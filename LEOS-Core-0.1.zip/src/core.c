#include "core.h"
static void zero(void *p, u32 n) { volatile u8 *b=(volatile u8 *)p; while(n--) *b++=0; }
static int copy(char *dst,u32 capacity,const char *src) {
    u32 i=0;
    if(!src || !capacity) return 0;
    while(src[i]) { if(i+1>=capacity) return 0; ++i; }
    for(i=0;src[i];++i) dst[i]=src[i]; dst[i]=0; return 1;
}
int core_equal(const char *a,const char *b) {
    while(*a && *a==*b) { ++a; ++b; } return *a==*b;
}
static Process *find(Core *c,u64 id) {
    u32 i; for(i=0;i<c->process_count;++i) if(c->processes[i].username==id) return &c->processes[i];
    return 0;
}
void core_init(Core *c) {
    zero(c,(u32)sizeof(*c));
    c->process_count=2; c->next_username=3;
    c->processes[0].username=1; c->processes[0].tag=TAG_CORE;
    copy(c->processes[0].display,32,"Core"); c->core_whitelist[0]=1;
    c->processes[1].username=2; c->processes[1].tag=TAG_SYSTEM;
    copy(c->processes[1].display,32,"System");
    /* Policy records only: not signed and not bound to hardware yet. */
    c->allowed_classes=CLASS_KEYBOARD|CLASS_MOUSE|CLASS_STORAGE;
}
int core_register(Core *c,const char *display,u32 tag,u64 *id) {
    Process *p;
    if(!id || !display || (tag!=TAG_SYSTEM && tag!=TAG_USER && tag!=TAG_BLOCKED)) return CORE_DENIED;
    if(c->process_count>=16 || !c->next_username) return CORE_FULL;
    p=&c->processes[c->process_count];
    if(!copy(p->display,32,display)) return CORE_INVALID;
    p->username=c->next_username++; p->tag=tag; *id=p->username; ++c->process_count;
    return CORE_OK;
}
int core_rename(Core *c,u64 id,const char *display) {
    Process *p=find(c,id); char temp[32]; u32 i;
    zero(temp,32);
    if(!p || !copy(temp,32,display)) return CORE_INVALID;
    for(i=0;i<32;++i) p->display[i]=temp[i];
    return CORE_OK;
}
int core_is_core(const Core *c,u64 id) {
    u32 i,j; for(i=0;i<c->process_count;++i) if(c->processes[i].username==id && c->processes[i].tag==TAG_CORE)
        for(j=0;j<2;++j) if(c->core_whitelist[j] && c->core_whitelist[j]==id) return 1;
    return 0;
}
int core_set_tag(Core *c,u64 actor,u64 target,u32 tag) {
    Process *a=find(c,actor),*t=find(c,target);
    if(!a || !t || tag>TAG_BLOCKED) return CORE_INVALID;
    if(tag==TAG_CORE || t->tag==TAG_CORE) return CORE_DENIED;
    if(!core_is_core(c,actor) && a->tag!=TAG_SYSTEM) return CORE_DENIED;
    t->tag=tag; return CORE_OK;
}
int core_add_device(Core *c,u64 id,u32 cls) {
    Device *d; u32 i;
    if(!id || (cls!=CLASS_KEYBOARD && cls!=CLASS_MOUSE && cls!=CLASS_STORAGE && cls!=CLASS_HIGH_RISK)) return CORE_INVALID;
    for(i=0;i<c->device_count;++i) if(c->devices[i].identity==id) return CORE_DENIED;
    if(c->device_count>=16) return CORE_FULL;
    d=&c->devices[c->device_count++]; d->identity=id; d->device_class=cls;
    d->state=DEVICE_UNTRUSTED; return CORE_OK;
}
int core_driver_allowed(const Core *c,u64 actor,u64 id) {
    u32 i; int system=0;
    for(i=0;i<c->process_count;++i)
        if(c->processes[i].username==actor && c->processes[i].tag==TAG_SYSTEM) system=1;
    if(!system && !core_is_core(c,actor)) return 0;
    for(i=0;i<c->device_count;++i) if(c->devices[i].identity==id) {
        const Device *d=&c->devices[i];
        if(d->device_class==CLASS_HIGH_RISK) return 0; /* IOMMU support not implemented. */
        if(!(c->allowed_classes & d->device_class)) return 0;
        return d->state==DEVICE_ALLOWED;
    }
    return 0;
}
static int filename(const char *s) {
    u32 i=0; if(!s || !*s) return 0;
    while(s[i]) { char ch=s[i];
        if(!((ch>='a'&&ch<='z')||(ch>='A'&&ch<='Z')||(ch>='0'&&ch<='9')||ch=='_'||ch=='-')) return 0;
        if(++i>=24) return 0;
    } return 1;
}
int core_file_write(Core *c,const char *name,const char *text) {
    u32 i,n=0,index=c->file_count;
    if(!filename(name)||!text) return CORE_INVALID;
    while(text[n]) if(++n>=256) return CORE_FULL;
    for(i=0;i<c->file_count;++i) if(core_equal(c->files[i].name,name)) { index=i; break; }
    if(index>=8) return CORE_FULL;
    copy(c->files[index].name,24,name);
    for(i=0;i<=n;++i) c->files[index].content[i]=(u8)text[i];
    c->files[index].size=n; if(index==c->file_count) ++c->file_count;
    return CORE_OK;
}
const RamFile *core_file_read(const Core *c,const char *name) {
    u32 i; if(!filename(name)) return 0;
    for(i=0;i<c->file_count;++i) if(core_equal(c->files[i].name,name)) return &c->files[i];
    return 0;
}
u32 core_selftest(void) {
    /* Static storage keeps kernel stack small; tests never mutate live state. */
    static Core c; u64 id=0; u32 failures=0;
    core_init(&c);
    failures+=!core_is_core(&c,1);
    failures+=core_register(&c,"Core",TAG_USER,&id)!=CORE_OK;
    failures+=core_is_core(&c,id)!=0;
    failures+=core_set_tag(&c,2,id,TAG_CORE)!=CORE_DENIED;
    failures+=core_set_tag(&c,id,2,TAG_SYSTEM)!=CORE_DENIED;
    failures+=core_rename(&c,id,"Renamed")!=CORE_OK;
    failures+=c.processes[2].username!=id;
    failures+=core_register(&c,"Fake Core",TAG_CORE,&id)!=CORE_DENIED;
    failures+=core_add_device(&c,100,CLASS_STORAGE)!=CORE_OK;
    failures+=core_driver_allowed(&c,2,100)!=0;
    c.devices[0].state=DEVICE_QUARANTINE;
    failures+=core_driver_allowed(&c,2,100)!=0;
    c.devices[0].state=DEVICE_ALLOWED;
    failures+=core_driver_allowed(&c,2,100)!=1;
    failures+=core_add_device(&c,101,CLASS_HIGH_RISK)!=CORE_OK;
    c.devices[1].state=DEVICE_ALLOWED;
    failures+=core_driver_allowed(&c,2,101)!=0;
    failures+=core_file_write(&c,"hello","LEOS")!=CORE_OK;
    failures+=core_file_read(&c,"hello")==0;
    failures+=core_file_write(&c,"../bad","no")!=CORE_INVALID;
    return failures;
}
