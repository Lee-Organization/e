param([string]$QemuRoot='C:\Program Files\qemu')
$ErrorActionPreference='Stop'
try {
    $exe=Join-Path $QemuRoot 'qemu-system-x86_64.exe'
    $firmware=Join-Path $QemuRoot 'share\edk2-x86_64-code.fd'
    $template=Join-Path $QemuRoot 'share\edk2-i386-vars.fd'
    foreach($path in @($exe,$firmware,$template)) { if(-not(Test-Path -LiteralPath $path)) { throw "QEMU file missing: $path" } }
    $scratch=Join-Path $PSScriptRoot 'vm-test'
    New-Item -ItemType Directory -Force -Path $scratch | Out-Null
    $vars=Join-Path $scratch ('vars-'+[guid]::NewGuid().ToString('N')+'.fd')
    Copy-Item -LiteralPath $template -Destination $vars
    & $exe -name 'LEOS Core 0.1' -machine q35 -accel tcg -m 256 `
        -drive "if=pflash,format=raw,readonly=on,file=$firmware" `
        -drive "if=pflash,format=raw,file=$vars" `
        -drive "format=raw,snapshot=on,file=$PSScriptRoot\LEOS-Core.img" `
        -serial "file:$scratch\serial.txt"
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; Read-Host 'Press Enter to close' | Out-Null }
