@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LEOS-Core.ps1" -Action Install
