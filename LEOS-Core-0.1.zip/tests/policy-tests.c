#include "../src/core.h"
static Core c;
#define CHECK(x) do { ++checks; if(!(x)) return -checks; } while(0)
__declspec(dllexport) int RunPolicyTests(void) {
    u64 a=0,b=0; int checks=0; u32 i,t,state,cls;
    char long_name[40],long_file[260];
    CHECK(core_selftest()==0);
    core_init(&c);
    CHECK(core_register(&c,"Same",TAG_USER,&a)==CORE_OK);
    CHECK(core_register(&c,"Same",TAG_USER,&b)==CORE_OK);
    CHECK(a!=b);
    CHECK(core_rename(&c,a,"Core")==CORE_OK);
    CHECK(c.processes[2].username==a);
    CHECK(!core_is_core(&c,a));
    for(t=0;t<4;++t) {
        CHECK(core_set_tag(&c,a,b,t)==CORE_DENIED);
        CHECK(core_set_tag(&c,2,b,t)==(t==TAG_CORE?CORE_DENIED:CORE_OK));
        CHECK(core_set_tag(&c,1,1,t)==CORE_DENIED);
    }
    CHECK(core_register(&c,"X",99,&a)==CORE_DENIED);
    CHECK(core_set_tag(&c,999,2,TAG_USER)==CORE_INVALID);
    for(i=0;i<39;++i) long_name[i]='A'; long_name[39]=0;
    CHECK(core_rename(&c,b,long_name)==CORE_INVALID);
    for(i=0;i<260;++i) long_file[i]='A'; long_file[259]=0;
    CHECK(core_file_write(&c,"huge",long_file)==CORE_FULL);
    CHECK(core_file_write(&c,"ok","first")==CORE_OK);
    CHECK(core_file_write(&c,"ok","second")==CORE_OK);
    CHECK(c.file_count==1 && core_file_read(&c,"ok")->size==6);
    CHECK(core_file_write(&c,"..","no")==CORE_INVALID);
    CHECK(core_file_write(&c,"C:\\test","no")==CORE_INVALID);
    CHECK(core_file_write(&c,"","no")==CORE_INVALID);
    core_init(&c);
    for(i=0;i<14;++i) CHECK(core_register(&c,"User",TAG_USER,&a)==CORE_OK);
    CHECK(core_register(&c,"Overflow",TAG_USER,&a)==CORE_FULL);
    for(cls=1;cls<=8;cls*=2) {
        core_init(&c); CHECK(core_add_device(&c,10,cls)==CORE_OK);
        CHECK(core_add_device(&c,10,cls)==CORE_DENIED);
        for(state=0;state<=2;++state) {
            c.devices[0].state=state;
            CHECK(core_driver_allowed(&c,2,10)==(state==DEVICE_ALLOWED && cls!=CLASS_HIGH_RISK));
            CHECK(core_driver_allowed(&c,99,10)==0);
        }
        CHECK(core_driver_allowed(&c,2,999)==0);
    }
    core_init(&c);
    for(i=0;i<16;++i) CHECK(core_add_device(&c,i+1,CLASS_STORAGE)==CORE_OK);
    CHECK(core_add_device(&c,99,CLASS_STORAGE)==CORE_FULL);
    CHECK(core_add_device(&c,0,CLASS_STORAGE)==CORE_INVALID);
    CHECK(core_add_device(&c,99,3)==CORE_INVALID);
    return checks;
}
