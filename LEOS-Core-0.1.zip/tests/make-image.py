"""Build an isolated FAT12 boot image from the two locally compiled EFI files."""
from pathlib import Path
import struct

def build(root):
    chooser=(root/'LEOS-Chooser.efi').read_bytes()
    kernel=(root/'LEOSCore.efi').read_bytes()
    image=bytearray(1474560)
    image[:3]=b'\xeb\x3c\x90'; image[3:11]=b'LEOSCORE'
    struct.pack_into('<HBHBHHBHHHII',image,11,512,1,1,2,224,2880,0xf0,9,18,2,0,0)
    image[36:39]=b'\0\0\x29'; struct.pack_into('<I',image,39,0x4c454f53)
    image[43:54]=b'LEOS CORE  '; image[54:62]=b'FAT12   '; image[510:512]=b'\x55\xaa'
    fat=bytearray(4608); fat[:3]=b'\xf0\xff\xff'
    def setfat(n,v):
        p=n+n//2
        if n&1: fat[p]=(fat[p]&15)|((v&15)<<4); fat[p+1]=v>>4
        else: fat[p]=v&255; fat[p+1]=(fat[p+1]&240)|(v>>8)
    def entry(name,attr,cluster,size=0):
        assert len(name)==11
        b=bytearray(32); b[:11]=name; b[11]=attr
        struct.pack_into('<H',b,24,0x5d66); struct.pack_into('<HI',b,26,cluster,size)
        return b
    def off(c): return (33+c-2)*512
    def directory(c,parent,content):
        data=entry(b'.          ',16,c)+entry(b'..         ',16,parent)+content
        assert len(data)<512
        image[off(c):off(c)+len(data)]=data; setfat(c,0xfff)
    def lfn(name,alias):
        checksum=0
        for b in alias: checksum=(((checksum&1)<<7)+(checksum>>1)+b)&255
        chars=[ord(c) for c in name]+[0]; chars += [0xffff]*(13-len(chars))
        b=bytearray(32); b[0]=0x41; b[11]=15; b[13]=checksum
        for pos,ch in zip([1,3,5,7,9,14,16,18,20,22,24,28,30],chars): struct.pack_into('<H',b,pos,ch)
        return b
    def file(data,start):
        count=(len(data)+511)//512
        assert start+count<2849
        for c in range(start,start+count): setfat(c,c+1 if c<start+count-1 else 0xfff)
        image[off(start):off(start)+len(data)]=data
        return start+count
    kernel_cluster=file(chooser,5); file(kernel,kernel_cluster)
    image[19*512:19*512+32]=entry(b'EFI        ',16,2)
    alias=b'LEOSCO~1   '
    directory(2,0,entry(b'BOOT       ',16,3)+lfn('LEOS-Core',alias)+entry(alias,16,4))
    directory(3,2,entry(b'BOOTX64 EFI',32,5,len(chooser)))
    directory(4,2,entry(b'LEOSCOREEFI',32,kernel_cluster,len(kernel)))
    image[512:512+4608]=fat; image[5120:5120+4608]=fat
    (root/'LEOS-Core.img').write_bytes(image)
    return image

if __name__=='__main__':
    build(Path(__file__).resolve().parents[1])
