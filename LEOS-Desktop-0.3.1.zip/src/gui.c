#include "desktop.h"
#include "font.h"
#define VW 1280
#define VH 800
static System *system_table;
static void *image_handle;
static Gop *graphics;
static Pixel *frame,*background;
static Pointer *pointer;
static Absolute *absolute;
static int mx=640,my=400,screen,focus,start_open,app,selected=-1,editing=-1;
static int disk_ok,load_result,mouse_down,dirty=1;
static char name[32],password[64],confirm[64],filename[24],document[TEXT_CAP],notice[96];
static Profile backup;
static u32 colors[3]={0x167d8d,0x7353ba,0x008578};
static u32 accent=0;
static int document_dirty;
static int clip_left,clip_top,clip_right=VW,clip_bottom=VH,editor_scroll,cursor_visible=1;
static int ps2_active,vm_mouse;
void VmPort(u32 *regs);
static InputEx *extended_input;
static Input *keyboard_fallback[16];
static u32 keyboard_count;
static void *input_timer;
static Guid keyboard_guid={0x387477c1,0x69c7,0x11d2,{0x8e,0x39,0,0xa0,0xc9,0x69,0x72,0x3b}};
static Guid extended_guid={0xdd9e7534,0x7762,0x4698,{0x8c,0x14,0xf5,0x85,0x17,0xa6,0x25,0xaa}};
static Guid graphics_guid={0x9042a9de,0x23dc,0x4a38,{0x96,0xfb,0x7a,0xde,0xd0,0x80,0x51,0x6a}};
static Guid pointer_guid={0x31878c87,0x0b75,0x11d5,{0x9a,0x4f,0,0x90,0x27,0x3f,0xc1,0x4d}};
static Guid absolute_guid={0x8d59d32b,0xc655,0x4ae9,{0x9b,0x15,0xf2,0x59,4,0x99,0x2a,0x43}};
static void connect_input(System *st) {
 void **handles=0;u64 count=0,i;
 /* Some firmware connects keyboard/video for boot but leaves pointing devices
    unconnected. Bind its existing drivers before choosing pointer protocols. */
 if(!BS(st,36,LocateHandleBuffer)(0,0,0,&count,&handles)&&count<4096){
  for(i=0;i<count;++i)BS(st,30,ConnectController)(handles[i],0,0,1);
  BS(st,6,FreePool)(handles);
 }
}
static void *physical_pointer(System *st,Guid *guid) {
 void **handles=0,*found=0,*p=0;u64 count=0,i;
 if(!BS(st,36,LocateHandleBuffer)(2,guid,0,&count,&handles)){
  for(i=0;i<count;++i)if(handles[i]!=st->in_handle&&!BS(st,16,HandleProtocol)(handles[i],guid,&p)){found=p;break;}
  BS(st,6,FreePool)(handles);
 }
 return found;
}
/* Development traces go to COM1 only, never into the visible interface. */
unsigned char __inbyte(unsigned short);
void __outbyte(unsigned short,unsigned char);
#pragma intrinsic(__inbyte,__outbyte)
static void trace(const char *s) { while(*s){u32 n=10000;while(!(__inbyte(0x3fd)&32)&&--n){}__outbyte(0x3f8,(u8)*s++);} }
static Pixel pixel(u32 rgb) { Pixel p;p.r=(u8)(rgb>>16);p.g=(u8)(rgb>>8);p.b=(u8)rgb;p.a=0;return p; }
static void dot(int x,int y,u32 rgb) { if(x>=0&&x<VW&&y>=0&&y<VH)frame[y*VW+x]=pixel(rgb); }
static void rect(int x,int y,int w,int h,u32 rgb) {
 int xx,yy,x1=x+w,y1=y+h;Pixel p=pixel(rgb);
 if(x<0)x=0;if(y<0)y=0;if(x1>VW)x1=VW;if(y1>VH)y1=VH;
 for(yy=y;yy<y1;++yy)for(xx=x;xx<x1;++xx)frame[yy*VW+xx]=p;
}
static void border(int x,int y,int w,int h,u32 rgb) { rect(x,y,w,1,rgb);rect(x,y+h-1,w,1,rgb);rect(x,y,1,h,rgb);rect(x+w-1,y,1,h,rgb); }
static int inside(int x,int y,int w,int h) { return mx>=x&&mx<x+w&&my>=y&&my<y+h; }
static void circle(int x,int y,int r,u32 rgb) { int xx,yy;for(yy=-r;yy<=r;++yy)for(xx=-r;xx<=r;++xx)if(xx*xx+yy*yy<=r*r)dot(x+xx,y+yy,rgb); }
static void line(int x,int y,int xx,int yy,u32 color) {
 int dx=xx-x,dy=yy-y,steps,i;if(dx<0)dx=-dx;if(dy<0)dy=-dy;steps=dx>dy?dx:dy;if(!steps){dot(x,y,color);return;}
 for(i=0;i<=steps;++i)dot(x+(xx-x)*i/steps,y+(yy-y)*i/steps,color);
}
static int text_width(const char *s,int font) {
 int width=0;while(*s){u8 c=(u8)*s++;if(c>=32&&c<127)width+=glyph[font][c-32].advance;}return width;
}
static void text(int x,int y,const char *s,int font,u32 rgb) {
 int xx,yy;Pixel fg=pixel(rgb);while(*s){u8 c=(u8)*s++;const Glyph *g;if(c<32||c>=127)c='?';g=&glyph[font][c-32];
  for(yy=0;yy<g->h;++yy)for(xx=0;xx<g->w;++xx){int px=x+xx,py=y+yy;u32 a=font_data[g->offset+yy*g->w+xx];Pixel *p;
   if(!a||px<clip_left||px>=clip_right||py<clip_top||py>=clip_bottom)continue;p=&frame[py*VW+px];
   p->r=(u8)((fg.r*a+p->r*(255-a))/255);p->g=(u8)((fg.g*a+p->g*(255-a))/255);p->b=(u8)((fg.b*a+p->b*(255-a))/255);
  }x+=g->advance;
 }
}
static void center(int x,int y,const char *s,int font,u32 color) { text(x-text_width(s,font)/2,y,s,font,color); }
static void message(const char *s) { copytext(notice,sizeof(notice),s);dirty=1; }
static void button(int x,int y,int w,int h,const char *label,int primary) {
 u32 c=primary?colors[accent]:0xe6e6e6;if(inside(x,y,w,h))c=primary?((c&0xfefefe)>>1)+0x7f7f7f:0xd5d5d5;
 rect(x,y,w,h,c);center(x+w/2,y+(h-27)/2,label,1,primary?0xffffff:0x202020);
}
static void clipped_text(int x,int y,int w,int h,const char *value,int font,u32 color) {
 clip_left=x;clip_top=y;clip_right=x+w;clip_bottom=y+h;text(x,y,value,font,color);
 clip_left=clip_top=0;clip_right=VW;clip_bottom=VH;
}
static void field(int x,int y,int w,const char *value,const char *placeholder,int active,int secret) {
 u32 n=length(value),i,visible=n;const char *shown=value;int pos;
 rect(x,y,w,44,0xffffff);border(x,y,w,44,active?colors[accent]:0x999999);
 if(secret){if(visible>(u32)((w-38)/9))visible=(u32)((w-38)/9);pos=(int)visible*9;}
 else{while(*shown&&text_width(shown,1)>w-38)++shown;pos=text_width(shown,1);}
 if(!n)clipped_text(x+13,y+9,w-26,30,placeholder,1,0x737373);
 else if(secret){for(i=0;i<visible;++i)circle(x+18+(int)i*9,y+23,3,0x252525);}
 else clipped_text(x+13,y+9,w-26,30,shown,1,0x202020);
 if(active)rect(x+14+pos,y+11,1,24,0x333333);
}
/* Original open-corner LEOS mark. */
static void logo(int x,int y,int size,u32 c) {
 int t=size/5;rect(x,y,t,size,c);rect(x,y+size-t,size,t,c);
 line(x+size/2,y,x+size-1,y+size/2,c);line(x+size/2+1,y,x+size-1,y+size/2-1,c);
}
static void folder(int x,int y,int size) { rect(x,y,size/2,size/5,0xe9a939);rect(x,y+size/7,size,size*2/3,0xffcc55);rect(x+3,y+size/3,size-3,size/2,0xffda79); }
static void paper(int x,int y,int size) {
 int i,w=size*3/4,pad=size/6;rect(x,y,w,size,0xf2f7fa);border(x,y,w,size,0xa6c3d6);
 for(i=1;i<=3;++i)rect(x+pad,y+size*i/5,w-pad*2,1,0x318cb8);
}
static void gear(int x,int y,int size,u32 color) {
 int dx,dy,r=size/3,c=size/2;
 for(dy=0;dy<size;++dy)for(dx=0;dx<size;++dx){int a=dx-c,b=dy-c,d=a*a+b*b;
  if((d<=r*r&&d>r*r/4)||((a>-3&&a<3)||(b>-3&&b<3))&&d>r*r/4&&d<(c-1)*(c-1))dot(x+dx,y+dy,color);
 }
}
static void avatar(int x,int y) {
 int dx,dy;circle(x,y,60,0xb4d4ea);
 for(dy=-58;dy<=58;++dy)for(dx=-58;dx<=58;++dx)
  if(dx*dx+dy*dy<58*58 && (dx*dx+(dy+18)*(dy+18)<18*18 || (dy<48&&dx*dx+(dy-36)*(dy-36)<36*36)))dot(x+dx,y+dy,0xffffff);
}
static void wallpaper(void) {
 int x,y;
 /* Original contour landscape, generated without external artwork. */
 for(y=0;y<VH;++y)for(x=0;x<VW;++x){int ridge=490+(x-640)*(x-640)/2400;u32 r=12+(u32)y/90,g=27+(u32)x/65,b=46+(u32)y/38;
  if(y>ridge){r=17;g=64+(u32)(y-ridge)/12;b=73+(u32)(y-ridge)/17;}
  if(y>ridge+90){r=15;g=46+(u32)(y-ridge)/18;b=58;}
  frame[y*VW+x]=pixel((r<<16)|(g<<8)|b);
 }
 for(x=0;x<VW;++x){int ridge=490+(x-640)*(x-640)/2400;dot(x,ridge,0x4f9f9b);dot(x,ridge+90,0x397d80);}
 memcopy(background,frame,VW*VH*sizeof(Pixel));
}
static void restore_background(int dim) {
 u32 i;for(i=0;i<VW*VH;++i){Pixel p=background[i];if(dim){p.r=(u8)(p.r*3/5);p.g=(u8)(p.g*3/5);p.b=(u8)(p.b*3/5);}frame[i]=p;}
}
static void setup_draw(void) {
 rect(0,0,VW,VH,0x102e42);logo(86,72,46,0xffffff);text(146,76,"LEOS",2,0xffffff);
 if(screen==0){
  text(110,290,"Welcome.",2,0xffffff);text(110,352,"A space to make your own.",1,0xe0efff);
  rect(678,144,490,505,0xffffff);text(724,194,"Let's get you set up",2,0x202020);
  text(724,276,"Create your account and choose a look.",1,0x525252);
  text(724,322,"Your files and settings stay on this device.",1,0x525252);
  button(724,545,398,48,"Get started",1);
 }else{
  text(110,270,"Make it yours.",2,0xffffff);text(110,332,"One account. Your own desktop.",1,0xe0efff);
  rect(642,70,540,660,0xffffff);text(690,108,"Create your account",2,0x202020);
  text(690,174,"Name",0,0x404040);field(690,201,444,name,"Your name",focus==0,0);
  text(690,262,"Password",0,0x404040);field(690,289,444,password,"Choose a password",focus==1,1);
  text(690,350,"Confirm password",0,0x404040);field(690,377,444,confirm,"Enter it again",focus==2,1);
  text(690,446,"Accent color",0,0x404040);
  {u32 i;for(i=0;i<3;++i){rect(690+(int)i*64,481,48,36,colors[i]);if(i==accent)border(687+(int)i*64,478,54,42,0x202020);}}
  text(690,548,notice,0,0xb3261e);button(690,615,444,48,"Create account",1);
 }
 if(!disk_ok)text(90,730,load_result<0?"Couldn't open saved information. Your files haven't been changed.":"A writable LEOS disk is needed to finish setup.",0,0xffffff);
}
static void login_draw(void) {
 restore_background(1);avatar(640,239);center(640,323,profile.username,2,0xffffff);
 field(454,392,322,password,"Password",1,1);button(780,392,48,44,">",1);
 center(640,462,notice,0,0xffffff);text(1165,743,"Restart",0,0xffffff);
}
static void window(int x,int y,int w,int h,const char *title) {
 rect(x+7,y+8,w,h,0x073151);rect(x,y,w,h,0xf7f8fa);rect(x,y,w,40,0xffffff);border(x,y,w,h,0x9ca9b3);
 text(x+16,y+9,title,1,0x202020);if(inside(x+w-40,y,40,40))rect(x+w-40,y+1,39,38,0xf3dada);line(x+w-25,y+14,x+w-15,y+24,0x555555);line(x+w-15,y+14,x+w-25,y+24,0x555555);
}
static void files_draw(void) {
 u32 i;window(205,120,870,570,"Files");
 rect(206,161,170,528,0xe9eef3);text(228,186,"Documents",1,0x202020);folder(229,234,42);
 button(401,178,114,40,"New",1);button(527,178,114,40,"Open",0);
 text(404,243,"Name",0,0x6a6a6a);text(910,243,"Size",0,0x6a6a6a);
 if(!profile.count)text(405,305,"Your documents will appear here.",1,0x737373);
 for(i=0;i<profile.count;++i){int y=280+(int)i*42;char size[12];u32 n=profile.files[i].length,k=0;char reversed[12];
  if((int)i==selected)rect(394,y-2,655,39,0xd9ebfb);paper(407,y+3,23);clipped_text(443,y+3,450,32,profile.files[i].name,1,0x202020);
  do{reversed[k++]=(char)('0'+n%10);n/=10;}while(n);{u32 j;for(j=0;j<k;++j)size[j]=reversed[k-j-1];size[k]=0;}text(914,y+5,size,0,0x505050);
 }
 text(402,650,notice,0,0x286947);
}
static int editor_lines(void) {
 int x=294,rows=0;u32 i;for(i=0;document[i];++i){char ch[2];int w;ch[0]=document[i];ch[1]=0;w=text_width(ch,1);
 if(ch[0]=='\n'){x=294;++rows;continue;}if(x+w>1002){x=294;++rows;}x+=w;}return rows;
}
static void editor_draw(void) {
 int x=294,y=254-editor_scroll*27;u32 i;window(250,96,800,620,"Notes");
 text(280,157,"File name",0,0x505050);field(280,184,740,filename,"Document.txt",focus==0,0);
 rect(280,244,740,377,0xffffff);border(280,244,740,377,focus==1?colors[accent]:0xc5cbd0);
 clip_left=294;clip_right=1003;clip_top=254;clip_bottom=610;
 for(i=0;document[i];++i){char ch[2];ch[0]=document[i];ch[1]=0;
  if(ch[0]=='\n'){x=294;y+=27;continue;}if(x+text_width(ch,1)>1002){x=294;y+=27;}text(x,y,ch,1,0x222222);x+=text_width(ch,1);
 }
 clip_left=clip_top=0;clip_right=VW;clip_bottom=VH;
 if(focus==1&&y>=254&&y<=583)rect(x+1,y+4,1,23,0x202020);
 if(editor_scroll>0)text(1007,250,"^",0,0x607080);
 if(editor_lines()>editor_scroll+12)text(1007,590,"v",0,0x607080);
 clipped_text(282,659,570,30,notice[0]?notice:document_dirty?"Unsaved changes":"",0,document_dirty?0x8a5c00:0x286947);button(874,646,146,42,"Save",1);
}
static void settings_draw(void) {
 u32 i;window(335,176,610,430,"Settings");clipped_text(375,246,530,48,profile.username,2,0x202020);
 text(375,315,"Personalization",1,0x505050);text(375,358,"Choose your accent color",0,0x505050);
 for(i=0;i<3;++i){rect(375+(int)i*78,399,60,43,colors[i]);if(accent==i)border(372+(int)i*78,396,66,49,0x333333);}
 text(375,479,notice,0,0x286947);button(375,528,210,42,"Lock screen",0);button(700,528,205,42,"Save changes",1);
}
static void desktop_draw(void) {
 Time time;char clock[6]="--:--";
 restore_background(0);
 folder(37,34,48);center(61,91,"Files",0,0xffffff);
 paper(40,147,48);center(61,205,"Notes",0,0xffffff);
 gear(37,260,48,0xeaf6ff);center(61,318,"Settings",0,0xffffff);
 if(app==1)files_draw();else if(app==2)editor_draw();else if(app==3)settings_draw();
 rect(0,752,1280,48,0x101c2b);logo(18,765,23,0xffffff);folder(79,766,26);paper(131,762,27);text(1160,765,"Lock",0,0xffffff);
 if(!((GetTime)system_table->runtime->f[0])(&time,0)){clock[0]=(char)('0'+time.hour/10);clock[1]=(char)('0'+time.hour%10);clock[3]=(char)('0'+time.minute/10);clock[4]=(char)('0'+time.minute%10);}
 text(1210,766,clock,0,0xffffff);
 if(start_open){rect(0,354,328,398,0x202b3b);text(28,380,profile.username,1,0xffffff);
  text(28,449,"Files",1,0xffffff);text(28,505,"Notes",1,0xffffff);text(28,561,"Settings",1,0xffffff);text(28,617,"Lock",1,0xffffff);text(28,690,"Restart",1,0xffffff);
 }
}
static void cursor(void) {
 static const char *shape[]={"X           ","XX          ","XOX         ","XOOX        ","XOOOX       ","XOOOOX      ","XOOOOOX     ","XOOOOOOX    ","XOOOOOOOX   ","XOOOOXXXXX  ","XOOXOX      ","XOX XOX     ","XX  XOX     ","X    XOX    ","     XOX    ","      X     "};
 int x,y;if(!cursor_visible)return;for(y=0;y<16;++y)for(x=0;x<12;++x)if(shape[y][x]!=' ')dot(mx+x,my+y,shape[y][x]=='X'?0x18222b:0xffffff);
}
static void render(void) {
 if(screen<2)setup_draw();else if(screen==2)login_draw();else desktop_draw();cursor();
 graphics->blt(graphics,frame,2,0,0,0,0,VW,VH,VW*sizeof(Pixel));dirty=0;
}
static void restart(void) {
 if(screen==3&&document_dirty){app=2;message("Save or close your note before restarting.");return;}
 store_close();((ResetSystem)system_table->runtime->f[10])(0,0,0,0);
}
static void lock_screen(void) { screen=2;start_open=0;memzero(password,sizeof(password));memzero(notice,sizeof(notice));trace("UI:LOGIN\n");dirty=1; }
static int allowed_name(const char *s) { u32 i,n=length(s);if(!n||n>23||s[0]=='.')return 0;for(i=0;i<n;++i)if((u8)s[i]<32||s[i]=='/'||s[i]=='\\'||s[i]==':'||s[i]=='*'||s[i]=='?'||s[i]=='"'||s[i]=='<'||s[i]=='>'||s[i]=='|')return 0;return 1; }
static void salt(void) {
 Guid rng_guid={0x3152bca5,0xeade,0x433d,{0x86,0x2e,0xc0,0x1c,0xdc,0x29,0x1f,0x44}};
 typedef struct Rng Rng;struct Rng{void *info;Status (*get)(Rng *,Guid *,u64,u8 *);};Rng *rng=0;
 if(!BS(system_table,37,LocateProtocol)(&rng_guid,0,(void **)&rng)&&rng&&!rng->get(rng,0,16,profile.salt))return;
 /* Salts need uniqueness, not secrecy. Prefer firmware RNG; use fresh boot time
    and monotonic count only as a uniqueness fallback, never as an encryption key. */
 {struct {Time time;u64 count,address;} seed;u8 digest[32];memzero(&seed,sizeof(seed));((GetTime)system_table->runtime->f[0])(&seed.time,0);BS(system_table,27,Monotonic)(&seed.count);seed.address=(u64)image_handle;sha256(&seed,sizeof(seed),digest);memcopy(profile.salt,digest,16);memzero(digest,32);}
}
static void create_account(void) {
 if(!disk_ok){message("Couldn't save. Use a writable LEOS disk.");return;}
 if(!name[0]){focus=0;message("Please enter your name.");return;}
 if(length(password)<4){focus=1;message("Use at least 4 characters.");return;}
 if(!equal(password,confirm)){focus=2;message("The passwords don't match.");return;}
 memzero(&profile,sizeof(profile));copytext(profile.username,32,name);profile.rounds=PASSWORD_ROUNDS;profile.accent=accent;salt();
 derive(password,profile.salt,16,profile.rounds,profile.verifier);
 if(!store_save()){memzero(profile.verifier,32);message("Couldn't save your account. Please try again.");return;}
 memzero(password,sizeof(password));memzero(confirm,sizeof(confirm));memzero(name,sizeof(name));lock_screen();trace("ACCOUNT:SAVED\n");
}
static void login(void) {
 u8 verifier[32];int ok;derive(password,profile.salt,16,profile.rounds,verifier);ok=constant_equal(verifier,profile.verifier,32);memzero(verifier,32);memzero(password,sizeof(password));
 if(!ok){message("That password isn't right. Try again.");trace("LOGIN:REJECTED\n");return;}
 screen=3;if(app!=2)focus=0;notice[0]=0;accent=profile.accent;trace("UI:DESKTOP\n");dirty=1;
}
static void open_editor(int index) {
 if(document_dirty){app=2;focus=1;message("Save or close the current note first.");return;}
 editing=index;editor_scroll=0;app=2;focus=1;notice[0]=0;document_dirty=0;
 if(index>=0&&index<(int)profile.count){copytext(filename,sizeof(filename),profile.files[index].name);copytext(document,sizeof(document),profile.files[index].text);}
 else{filename[0]=0;document[0]=0;focus=0;}
 start_open=0;dirty=1;
}
static void save_document(void) {
 int index=editing;u32 i;
 if(!filename[0])copytext(filename,sizeof(filename),"Untitled.txt");
 if(!allowed_name(filename)){message("Choose a valid file name.");return;}
 for(i=0;i<profile.count;++i)if((int)i!=editing&&equal(filename,profile.files[i].name)){message("That file name is already in use.");return;}
 if(index<0){if(profile.count==DOCUMENTS){message("This folder is full (8 documents).");return;}index=(int)profile.count;}
 memcopy(&backup,&profile,sizeof(profile));if(index==(int)profile.count)++profile.count;
 copytext(profile.files[index].name,24,filename);copytext(profile.files[index].text,TEXT_CAP,document);profile.files[index].length=length(document);
 if(!store_save()){memcopy(&profile,&backup,sizeof(profile));message("Couldn't save. Your changes are still open.");return;}
 editing=selected=index;document_dirty=0;message("Saved");trace("DOCUMENT:SAVED\n");
}
static void save_settings(void) {
 u32 previous=profile.accent;profile.accent=accent;if(!store_save()){profile.accent=previous;message("Couldn't save your settings.");}else message("Saved");
}
static void click(void) {
 u32 i;dirty=1;
 if(screen==0){if(inside(724,545,398,48)){screen=1;focus=0;trace("UI:ACCOUNT\n");}return;}
 if(screen==1){
  if(inside(690,201,444,44))focus=0;else if(inside(690,289,444,44))focus=1;else if(inside(690,377,444,44))focus=2;
  for(i=0;i<3;++i)if(inside(690+(int)i*64,481,48,36))accent=i;
  if(inside(690,615,444,48))create_account();return;
 }
 if(screen==2){if(inside(780,392,48,44))login();if(inside(1150,730,120,60))restart();return;}
 if(inside(0,752,62,48)){start_open=!start_open;return;}
 if(inside(1140,752,65,48)){lock_screen();return;}
 if(start_open&&inside(0,354,328,398)){
  if(my>=678)restart();else if(my>=606)lock_screen();else if(my>=550){app=3;notice[0]=0;start_open=0;}else if(my>=494)open_editor(-1);else if(my>=438){app=1;notice[0]=0;start_open=0;}return;
 }
 start_open=0;
 if(inside(66,752,52,48)){app=1;notice[0]=0;return;}if(inside(120,752,52,48)){open_editor(-1);return;}
 if(app==1){
  if(inside(1035,120,40,40)){app=0;return;}
  if(inside(401,178,114,40)){open_editor(-1);return;}if(inside(527,178,114,40)&&selected>=0){open_editor(selected);return;}
  for(i=0;i<profile.count;++i)if(inside(394,278+(int)i*42,655,39)){selected=(int)i;return;}
 }else if(app==2){
  if(inside(1010,96,40,40)){if(document_dirty){message("Save your changes first, or press Escape to discard.");return;}app=0;return;}
  if(inside(280,184,740,44))focus=0;if(inside(280,244,740,377))focus=1;
  if(inside(874,646,146,42))save_document();
 }else if(app==3){
  if(inside(905,176,40,40)){app=0;accent=profile.accent;return;}
  for(i=0;i<3;++i)if(inside(375+(int)i*78,399,60,43))accent=i;
  if(inside(375,528,210,42))lock_screen();if(inside(700,528,205,42))save_settings();
 }
 if(!app){if(inside(10,20,108,100)){app=1;notice[0]=0;}else if(inside(10,133,108,100))open_editor(-1);else if(inside(10,248,108,100)){app=3;notice[0]=0;}}
}
static void edit_key(char *buffer,u32 cap,Key k,int multiline) {
 u32 n=length(buffer);if(k.unicode==8){if(n)buffer[n-1]=0;}else if(k.unicode==13&&multiline){if(n+1<cap){buffer[n]='\n';buffer[n+1]=0;}}
 else if(k.unicode>=32&&k.unicode<127&&n+1<cap){buffer[n]=(char)k.unicode;buffer[n+1]=0;}
}
static void key(Key k) {
 dirty=1;cursor_visible=0;
 if(screen==0){if(k.unicode==13){screen=1;focus=0;trace("UI:ACCOUNT\n");}return;}
 if(screen==1){if(k.unicode==9){focus=(focus+1)%3;return;}if(k.unicode==13){if(focus<2)++focus;else create_account();return;}
  if(focus==0)edit_key(name,sizeof(name),k,0);else if(focus==1)edit_key(password,sizeof(password),k,0);else edit_key(confirm,sizeof(confirm),k,0);return;
 }
 if(screen==2){if(k.unicode==13)login();else edit_key(password,sizeof(password),k,0);return;}
 if(k.scan==23){app=start_open=0;document_dirty=0;accent=profile.accent;notice[0]=0;return;}
 if(k.scan==13){app=1;notice[0]=0;return;}if(k.scan==14){open_editor(-1);return;}if(k.scan==15){app=3;notice[0]=0;return;}if(k.scan==16){lock_screen();return;}
 if(app==2){
  if(k.scan==12||k.unicode==19){save_document();return;}if(k.unicode==9){focus=1-focus;return;}
  if(k.scan==9){editor_scroll-=10;if(editor_scroll<0)editor_scroll=0;return;}
  if(k.scan==10){int max=editor_lines()-12;editor_scroll+=10;if(max<0)max=0;if(editor_scroll>max)editor_scroll=max;return;}
  if(focus==0)edit_key(filename,sizeof(filename),k,0);else{edit_key(document,sizeof(document),k,1);editor_scroll=editor_lines()-12;if(editor_scroll<0)editor_scroll=0;}document_dirty=1;notice[0]=0;
 }else if(app==1){if(k.scan==1&&selected>0)--selected;if(k.scan==2&&selected+1<(int)profile.count)++selected;if(k.unicode==13&&selected>=0)open_editor(selected);if(k.unicode=='n'||k.unicode=='N')open_editor(-1);}
}
/* Keep the same firmware console that worked in Boot Manager. Use alternate
   keyboard handles only when that console has no key, to avoid duplicates. */
static void keyboard_init(System *st) {
 void **handles=0;u64 count=0,i;void *p=0;
 if(st->input->reset)((ResetPointer)st->input->reset)(st->input,0);
 if(!BS(st,16,HandleProtocol)(st->in_handle,&extended_guid,&p))extended_input=(InputEx *)p;
 if(!BS(st,36,LocateHandleBuffer)(2,&keyboard_guid,0,&count,&handles)){
  for(i=0;i<count&&keyboard_count<16;++i){p=0;if(handles[i]!=st->in_handle&&!BS(st,16,HandleProtocol)(handles[i],&keyboard_guid,&p)&&p)keyboard_fallback[keyboard_count++]=(Input *)p;}
  BS(st,6,FreePool)(handles);
 }
 /* A periodic event lets firmware dispatch USB/PS2 input producers. Stall-only
    busy polling worked in our firmware build but is not a portable event loop. */
 if(!BS(st,7,CreateEvent)(0x80000000,0,0,0,&input_timer)){
  if(BS(st,8,SetTimer)(input_timer,1,160000)){input_timer=0;}
 }
}
static Status read_keyboard(System *st,Key *k) {
 Status r;u32 i;KeyData data;r=st->input->read(st->input,k);if(!r)return 0;
 if(extended_input&&!extended_input->read(extended_input,&data)){*k=data.key;return 0;}
 for(i=0;i<keyboard_count;++i)if(!keyboard_fallback[i]->read(keyboard_fallback[i],k))return 0;
 return r;
}
static void input_wait(System *st) {
 void *events[4];u64 count=0,index=0;
 if(!input_timer){BS(st,28,Stall)(16000);return;}
 events[count++]=input_timer;
 if(st->input->wait)events[count++]=st->input->wait;
 if(pointer&&pointer->wait)events[count++]=pointer->wait;
 if(absolute&&absolute->wait)events[count++]=absolute->wait;
 if(BS(st,9,WaitForEvent)(count,events,&index))BS(st,28,Stall)(16000);
}
/* Optional absolute pointer for QEMU VNC installations without a firmware
   tablet driver. Protocol constants documented by QEMU hw/i386/vmmouse.c;
   the implementation here is original. Keep PS/2 available as a fallback. */
static void vm_command(u32 cmd,u32 arg,u32 *r) {r[0]=0x564d5868;r[1]=arg;r[2]=cmd;r[3]=0;VmPort(r);}
static int vm_mouse_init(void) {
 u32 r[4];vm_command(10,0,r);if(r[1]!=0x564d5868||r[0]==0xffffffff)return 0;
 vm_command(41,0x45414552,r);vm_command(40,0,r);if((r[0]>>16)||(r[0]&65535)!=1)return 0;
 vm_command(39,1,r);if(r[0]!=0x3442554a)return 0;
 vm_command(41,0x53424152,r);return 1;
}
static void vm_mouse_poll(void) {
 static int down;u32 r[4],i;
 for(i=0;i<32;++i){int left;vm_command(40,0,r);if(r[0]>>16){vm_mouse=0;return;}if((r[0]&65535)<4)return;
  vm_command(39,4,r);if(r[0]&0x10000)continue;
  mx=(int)((u64)(r[1]&65535)*(VW-1)/65535);my=(int)((u64)(r[2]&65535)*(VH-1)/65535);
  dirty=cursor_visible=1;left=(r[0]&32)!=0;if(left&&!down)click();down=left;
 }
}
static int ps2_wait(void) {
 u32 i;for(i=0;i<2000;++i){if(!(__inbyte(0x64)&2))return 1;BS(system_table,28,Stall)(50);}return 0;
}
static int ps2_send(u8 value) {
 u32 i;if(!ps2_wait())return 0;__outbyte(0x64,0xd4);if(!ps2_wait())return 0;__outbyte(0x60,value);
 for(i=0;i<2000;++i){u8 status=__inbyte(0x64);if((status&0x21)==0x21)return __inbyte(0x60)==0xfa;BS(system_table,28,Stall)(50);}return 0;
}
static int ps2_init(void) {
 if(!ps2_wait())return 0;__outbyte(0x64,0xa8);
 return ps2_send(0xf6)&&ps2_send(0xf4);
}
static void ps2_poll(void) {
 static u8 packet[3];static u32 used;u32 i;
 for(i=0;i<48;++i){u8 status=__inbyte(0x64),byte;int dx,dy,left;
  if((status&0x21)!=0x21)return;byte=__inbyte(0x60);
  if(!used&&!(byte&8))continue;packet[used++]=byte;if(used<3)continue;used=0;
  if(packet[0]&0xc0)continue;
  dx=(int)packet[1]-((packet[0]&16)?256:0);dy=(int)packet[2]-((packet[0]&32)?256:0);
  mx+=dx*2;my-=dy*2;if(mx<0)mx=0;if(mx>VW-2)mx=VW-2;if(my<0)my=0;if(my>VH-2)my=VH-2;
  if(dx||dy){dirty=1;cursor_visible=1;}left=packet[0]&1;if(left&&!mouse_down)click();mouse_down=left;
 }
}
Status EfiMain(void *image,System *st) {
 Status result;u32 mode;u64 size;GopInfo *info;Key k;u32 tick=0;
 if(!st||!st->boot||!st->input||!st->runtime)return ERR(2);system_table=st;image_handle=image;
 if(BS(st,37,LocateProtocol)(&graphics_guid,0,(void **)&graphics)||!graphics||!graphics->mode)return ERR(3);
 for(mode=0;mode<graphics->mode->max_mode;++mode){info=0;size=0;if(!graphics->query(graphics,mode,&size,&info)&&info){int match=info->width==VW&&info->height==VH;BS(st,6,FreePool)(info);if(match){if(graphics->mode->mode!=mode)graphics->set(graphics,mode);break;}}}
 if(graphics->mode->info->width<VW||graphics->mode->info->height<VH)return ERR(3);
 if(BS(st,5,AllocatePool)(2,VW*VH*sizeof(Pixel),(void **)&frame)||BS(st,5,AllocatePool)(2,VW*VH*sizeof(Pixel),(void **)&background))return ERR(9);
 BS(st,29,Watchdog)(0,0,0,0);
 connect_input(st);
 pointer=(Pointer *)physical_pointer(st,&pointer_guid);absolute=(Absolute *)physical_pointer(st,&absolute_guid);
 if(pointer&&pointer->reset)((ResetPointer)pointer->reset)(pointer,0);
 if(absolute&&absolute->reset)((ResetPointer)absolute->reset)(absolute,0);
 if(st->output){typedef Status (*Cursor)(void *,u8);void **out=(void **)st->output;if(out[8])((Cursor)out[8])(st->output,0);}
 __outbyte(0x3f9,0);__outbyte(0x3fb,0x80);__outbyte(0x3f8,1);__outbyte(0x3f9,0);__outbyte(0x3fb,3);__outbyte(0x3fa,0xc7);__outbyte(0x3fc,0xb);
 trace(pointer?"INPUT:RELATIVE\n":"INPUT:NO-RELATIVE\n");trace(absolute?"INPUT:ABSOLUTE\n":"INPUT:NO-ABSOLUTE\n");
 keyboard_init(st);
 if(!pointer&&!absolute){ps2_active=ps2_init();trace(ps2_active?"INPUT:PS2-FALLBACK\n":"INPUT:NO-PS2\n");}
 /* Reset keyboard before enabling the auxiliary PS/2 channel: firmware
    keyboard resets may reconfigure the shared controller. */
 vm_mouse=vm_mouse_init();trace(vm_mouse?"INPUT:VM-ABSOLUTE\n":"INPUT:NO-VM-ABSOLUTE\n");
 if(!absolute){void *p=0;if(!BS(st,16,HandleProtocol)(st->in_handle,&absolute_guid,&p))absolute=(Absolute *)p;}
 if(!pointer){void *p=0;if(!BS(st,16,HandleProtocol)(st->in_handle,&pointer_guid,&p))pointer=(Pointer *)p;}
 trace(input_timer?"INPUT:EVENT-LOOP\n":"INPUT:POLL-LOOP\n");
 disk_ok=store_open(st,image);load_result=disk_ok?store_load():0;
 if(load_result<0)disk_ok=0;
 if(load_result==1){accent=profile.accent;screen=2;trace("UI:LOGIN\n");}else{screen=0;trace("UI:SETUP\n");}
 wallpaper();render();
 for(;;){
  if(ps2_active)ps2_poll();
  if(vm_mouse)vm_mouse_poll();
  /* Console splitters and EVT_NOTIFY_WAIT producers must be checked so that
     their wait notifications poll the underlying devices before GetState. */
  if(st->input->wait)BS(st,12,CheckEvent)(st->input->wait);
  if(pointer&&pointer->wait)BS(st,12,CheckEvent)(pointer->wait);
  if(absolute&&absolute->wait)BS(st,12,CheckEvent)(absolute->wait);
  result=read_keyboard(st,&k);if(!result)key(k);
  if(pointer){PointerState p;if(!pointer->get(pointer,&p)){if(p.x||p.y){mx+=p.x*2;my+=p.y*2;dirty=1;cursor_visible=1;}if(p.left&&!mouse_down)click();mouse_down=p.left;}}
  if(absolute&&absolute->mode){AbsoluteState p;AbsoluteMode *m=absolute->mode;if(!absolute->get(absolute,&p)&&m->max_x>m->min_x&&m->max_y>m->min_y){mx=(int)((p.x-m->min_x)*(VW-1)/(m->max_x-m->min_x));my=(int)((p.y-m->min_y)*(VH-1)/(m->max_y-m->min_y));dirty=1;cursor_visible=1;if((p.buttons&1)&&!mouse_down)click();mouse_down=(int)(p.buttons&1);}}
  if(mx<0)mx=0;if(mx>VW-2)mx=VW-2;if(my<0)my=0;if(my>VH-2)my=VH-2;
  if(++tick==3750){tick=0;if(screen==3)dirty=1;}
  if(dirty)render();input_wait(st);
 }
}
