#ifndef DESKTOP_EFI_H
#define DESKTOP_EFI_H
#include "core.h"
typedef u64 Status;
#define ERR(n) (0x8000000000000000ull|(n))
typedef struct { u64 signature; u32 revision,size,crc,reserved; } Header;
typedef struct { u32 a; u16 b,c; u8 d[8]; } Guid;
typedef struct { Header h; void *f[44]; } Boot;
typedef struct { Header h; void *f[14]; } Runtime;
typedef struct { u16 scan,unicode; } Key;
typedef struct Input Input;
struct Input { void *reset; Status (*read)(Input *,Key *); void *wait; };
typedef struct {
 Header h; u16 *vendor; u32 revision; void *in_handle; Input *input;
 void *out_handle,*output,*err_handle,*error; Runtime *runtime; Boot *boot;
} System;
typedef struct { u8 b,g,r,a; } Pixel;
typedef struct { u32 version,width,height,format,masks[4],stride; } GopInfo;
typedef struct { u32 max_mode,mode; GopInfo *info; u64 info_size,base,size; } GopMode;
typedef struct Gop Gop;
struct Gop {
 Status (*query)(Gop *,u32,u64 *,GopInfo **); Status (*set)(Gop *,u32);
 Status (*blt)(Gop *,Pixel *,u32,u64,u64,u64,u64,u64,u64,u64); GopMode *mode;
};
typedef struct { u32 revision; void *parent; System *system; void *device,*path; } Loaded;
typedef struct File File;
struct File {
 u64 revision;
 Status (*open)(File *,File **,const u16 *,u64,u64);
 Status (*close)(File *); void *delete_file;
 Status (*read)(File *,u64 *,void *); Status (*write)(File *,u64 *,void *);
 void *get_position; Status (*set_position)(File *,u64);
 void *get_info,*set_info; Status (*flush)(File *);
};
typedef struct FS FS;
struct FS { u64 revision; Status (*open_volume)(FS *,File **); };
typedef struct { int x,y,z; u8 left,right; } PointerState;
typedef struct Pointer Pointer;
struct Pointer { void *reset; Status (*get)(Pointer *,PointerState *); void *wait,*mode; };
typedef struct { u64 x,y,z; u32 buttons; } AbsoluteState;
typedef struct { u64 min_x,min_y,min_z,max_x,max_y,max_z; u32 attributes; } AbsoluteMode;
typedef struct Absolute Absolute;
struct Absolute { void *reset; Status (*get)(Absolute *,AbsoluteState *); void *wait; AbsoluteMode *mode; };
typedef struct { u16 year; u8 month,day,hour,minute,second,pad; u32 nanosecond; short timezone; u8 daylight,pad2; } Time;
#define BS(st,index,type) ((type)((st)->boot->f[index]))
typedef Status (*HandleProtocol)(void *,Guid *,void **);
typedef Status (*LocateProtocol)(Guid *,void *,void **);
typedef Status (*AllocatePool)(u32,u64,void **);
typedef Status (*FreePool)(void *);
typedef Status (*Stall)(u64);
typedef Status (*Watchdog)(u64,u64,u64,u16 *);
typedef Status (*GetTime)(Time *,void *);
typedef void (*ResetSystem)(u32,Status,u64,void *);
typedef Status (*Monotonic)(u64 *);
typedef Status (*CheckEvent)(void *);
typedef Status (*CreateEvent)(u32,u64,void *,void *,void **);
typedef Status (*SetTimer)(void *,u32,u64);
typedef Status (*WaitForEvent)(u64,void **,u64 *);
typedef struct { Key key; u32 shift; u8 toggle; } KeyData;
typedef struct InputEx InputEx;
struct InputEx { void *reset; Status (*read)(InputEx *,KeyData *); void *wait,*set,*reg,*unreg; };
typedef Status (*ResetPointer)(void *,u8);
typedef Status (*LocateHandleBuffer)(u32,Guid *,void *,u64 *,void ***);
typedef Status (*ConnectController)(void *,void **,void *,u8);
typedef char system_size[(sizeof(System)==104)?1:-1];
typedef char file_size[(sizeof(File)==88)?1:-1];
#endif
