; Original x64 register bridge for the documented QEMU/VMware mouse port.
.code
VmPort PROC
 push rbx
 push rsi
 push rdi
 mov r8,rcx
 mov eax,[r8]
 mov ebx,[r8+4]
 mov ecx,[r8+8]
 mov edx,5658h
 in eax,dx
 mov [r8],eax
 mov [r8+4],ebx
 mov [r8+8],ecx
 mov [r8+12],edx
 pop rdi
 pop rsi
 pop rbx
 ret
VmPort ENDP
END
