#include "../src/gui.c"
static int waited;
static Status no_key(Input *in,Key *k){(void)in;(void)k;return ERR(6);}
static Status fallback_key(Input *in,Key *k){(void)in;k->scan=0;k->unicode=13;return 0;}
static Status ex_key(InputEx *in,KeyData *k){(void)in;k->key.scan=0;k->key.unicode='a';return 0;}
static Status wait_mock(u64 n,void **events,u64 *index){if(n==2&&events[0]==(void *)1&&events[1]==(void *)2)waited=1;*index=0;return 0;}
__declspec(dllexport) int InputChecks(void){
 System st;Boot boot;Input main,alternate;InputEx ex;Key k;
 memzero(&st,sizeof(st));memzero(&boot,sizeof(boot));memzero(&main,sizeof(main));memzero(&alternate,sizeof(alternate));memzero(&ex,sizeof(ex));
 st.input=&main;st.boot=&boot;main.read=no_key;alternate.read=fallback_key;keyboard_fallback[0]=&alternate;keyboard_count=1;
 if(read_keyboard(&st,&k)||k.unicode!=13)return 1;
 ex.read=ex_key;extended_input=&ex;if(read_keyboard(&st,&k)||k.unicode!='a')return 2;
 main.wait=(void *)2;input_timer=(void *)1;boot.f[9]=(void *)wait_mock;input_wait(&st);if(!waited)return 3;
 return 0;
}
