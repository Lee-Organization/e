#include "../src/gui.c"
static Pixel canvas[VW*VH];
__declspec(dllexport) int GraphicsChecks(void){int x,y,i,checks=0;Key k;
#define CHECK(x) do{++checks;if(!(x))return -checks;}while(0)
 frame=canvas;memzero(&profile,sizeof(profile));defaults();screen=3;ox=oy=0;
 rect(0,0,VW,VH,0x123456);icon(100,100,24,1);
 for(y=0;y<VH;++y)for(x=0;x<VW;++x)if((x<100||x>=124||y<100||y>=124)&&(frame[y*VW+x].r!=0x12||frame[y*VW+x].g!=0x34||frame[y*VW+x].b!=0x56))return -1;++checks;
 rect(0,0,VW,VH,0x123456);ox=70;oy=50;field(100,100,100,"WWWWWWWWWWWWWWWWWWWWWWWWWWWWW","",1,0);
 for(y=0;y<VH;++y)for(x=0;x<VW;++x)if((x<170||x>=270||y<150||y>=192)&&(frame[y*VW+x].r!=0x12||frame[y*VW+x].g!=0x34||frame[y*VW+x].b!=0x56))return -2;++checks;
 ox=oy=0;windows_init();open_app(1);mouse_event(430,140,1);mouse_event(325,80,1);mouse_event(325,80,0);CHECK(windows[1].x==100&&windows[1].y==60);CHECK(dragging==-1);
 open_app(2);mouse_event(1050,116,1);mouse_event(1050,116,0);CHECK(!windows[2].open&&app==1);
 open_editor(-1);focus=1;document[0]=0;edit_cursor=0;k.scan=0;k.unicode=13;for(i=0;i<25;++i)editor_key(k);CHECK(editor_scroll==13);k.scan=9;k.unicode=0;editor_key(k);CHECK(editor_scroll==3);k.scan=10;editor_key(k);CHECK(editor_scroll==13);
 copytext(document,sizeof(document),"ab\ncd");edit_cursor=2;k.scan=0;k.unicode='X';editor_key(k);CHECK(equal(document,"abX\ncd"));k.unicode=26;editor_key(k);CHECK(equal(document,"ab\ncd"));k.unicode=1;editor_key(k);k.unicode=24;editor_key(k);CHECK(document[0]==0&&equal(text_clipboard,"ab\ncd"));k.unicode=22;editor_key(k);CHECK(equal(document,"ab\ncd"));
 editor_scroll=0;editor_click(39,183);CHECK(edit_cursor==3);close_app(2);CHECK(dialog==6&&windows[2].open);dialog=0;k.scan=0;k.unicode=27;key(k);CHECK(dialog==6);dialog=0;document_dirty=0;close_app(2);CHECK(!windows[2].open&&app==1);
 display_geometry(1024,768);CHECK(view_width==1024&&view_height==640&&view_x==0&&view_y==64);
 CHECK(axis_desktop(0,display_height,view_y,view_height,VH)==0);CHECK(axis_desktop(65535,display_height,view_y,view_height,VH)==799);
 CHECK(axis_desktop(32768,display_height,view_y,view_height,VH)>=398&&axis_desktop(32768,display_height,view_y,view_height,VH)<=401);
 display_geometry(1920,1080);CHECK(view_width==1728&&view_height==1080&&view_x==96&&view_y==0);
 {Pixel src[4],p;src[0]=pixel(0x000000);src[1]=pixel(0xff0000);src[2]=pixel(0x00ff00);src[3]=pixel(0x0000ff);
  CHECK(sample_coordinate(0,2,4)==0);CHECK(sample_coordinate(3,2,4)==256);
  CHECK(sample_coordinate(0,1280,1024)==32);CHECK(sample_coordinate(1023,1280,1024)==327392);
  p=sample_scaled(src,2,2,0,0);CHECK(p.r==0&&p.g==0&&p.b==0);
  p=sample_scaled(src,2,2,256,256);CHECK(p.r==0&&p.g==0&&p.b==255);
  p=sample_scaled(src,2,2,128,128);CHECK(p.r==64&&p.g==64&&p.b==64);
 }
 CHECK(axis_fraction(0,0,0xffffffffffffffffull)==0);CHECK(axis_fraction(0xffffffffffffffffull,0,0xffffffffffffffffull)==65535);CHECK(axis_fraction(0x8000000000000000ull,0,0xffffffffffffffffull)==32768);
 {Time t={2024,2,28,23,59,59,0,0,0,0,0};u64 a=seconds_from_time(&t);t.day=29;t.hour=t.minute=t.second=0;CHECK(seconds_from_time(&t)==a+1);t.month=3;t.day=1;CHECK(seconds_from_time(&t)==a+86401);}
 CHECK(!idle_expired(1000,1000,5));CHECK(!idle_expired(1299,1000,5));CHECK(idle_expired(1300,1000,5));CHECK(!idle_expired(999,1000,5));CHECK(!idle_expired(100000,1000,0));
 return checks;
}
