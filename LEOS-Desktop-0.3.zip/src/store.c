#include "desktop.h"
Profile profile;
static Profile scratch,verify;
static File *directory;
static int current=-1;
static const u16 *slots[2]={L"Profile-A.dat",L"Profile-B.dat"};
static int bounded(const char *p,u32 cap) { u32 i;for(i=0;i<cap;++i)if(!p[i])return 1;return 0; }
int valid_profile(const Profile *p) {
 u32 i,j;
 if(!constant_equal((const u8 *)p->magic,(const u8 *)"LEOSGUI2",8)||p->version!=2||p->size!=sizeof(Profile)||!p->generation)return 0;
 if(p->count>DOCUMENTS||p->rounds!=PASSWORD_ROUNDS||p->accent>2||!p->username[0]||!bounded(p->username,32))return 0;
 for(i=0;i<p->count;++i){
  if(!p->files[i].name[0]||!bounded(p->files[i].name,24)||p->files[i].length>=TEXT_CAP)return 0;
  if(p->files[i].text[p->files[i].length])return 0;
  for(j=0;j<i;++j)if(equal(p->files[i].name,p->files[j].name))return 0;
 }
 return p->checksum==crc32(p,(u32)sizeof(Profile)-4);
}
int store_open(System *st,void *image) {
 Guid loaded={0x5b1b31a1,0x9562,0x11d2,{0x8e,0x3f,0,0xa0,0xc9,0x69,0x72,0x3b}};
 Guid filesystem={0x964e5b22,0x6459,0x11d2,{0x8e,0x39,0,0xa0,0xc9,0x69,0x72,0x3b}};
 Loaded *li=0;FS *fs=0;File *root=0;Status s;
 HandleProtocol handle=BS(st,16,HandleProtocol);
 if(handle(image,&loaded,(void **)&li)||!li)return 0;
 if(handle(li->device,&filesystem,(void **)&fs)||!fs)return 0;
 if(fs->open_volume(fs,&root)||!root)return 0;
 s=root->open(root,&directory,L"\\EFI\\LEOS-Data",3,0);
 if(s==ERR(14))s=root->open(root,&directory,L"\\EFI\\LEOS-Data",0x8000000000000003ull,16);
 root->close(root);
 return s==0&&directory!=0;
}
/* Read exactly one fixed-size journal record, reject extra/truncated data. */
static int read_slot(int index,Profile *p) {
 File *f=0;u64 n=sizeof(Profile),extra=1;u8 tail;Status s;
 s=directory->open(directory,&f,slots[index],1,0);
 if(s==ERR(14))return 0;
 if(s||!f)return -1;
 s=f->read(f,&n,p);
 if(!s&&n==sizeof(Profile)){s=f->read(f,&extra,&tail);if(extra)s=ERR(4);}else s=ERR(4);
 if(f->close(f))s=ERR(7);
 return !s&&valid_profile(p)?1:-1;
}
int store_load(void) {
 int a,b;if(!directory)return -1;
 a=read_slot(0,&profile);b=read_slot(1,&scratch);
 if(a==1&&(b!=1||profile.generation>=scratch.generation)){current=0;return 1;}
 if(b==1){memcopy(&profile,&scratch,sizeof(Profile));current=1;return 1;}
 memzero(&profile,sizeof(Profile));current=-1;
 return !a&&!b?0:-1;
}
int store_save(void) {
 File *f=0;int target=current==0?1:0;u64 n=sizeof(Profile);Status s;
 if(!directory||profile.generation==~0ull)return 0;
 memcopy(&scratch,&profile,sizeof(Profile));
 memcopy(scratch.magic,"LEOSGUI2",8);scratch.version=2;scratch.size=sizeof(Profile);++scratch.generation;
 scratch.checksum=crc32(&scratch,(u32)sizeof(Profile)-4);
 if(!valid_profile(&scratch))return 0;
 s=directory->open(directory,&f,slots[target],0x8000000000000003ull,0);
 if(s||!f)return 0;
 s=f->set_position(f,0);if(!s)s=f->write(f,&n,&scratch);
 if(!s&&n!=sizeof(Profile))s=ERR(7);
 if(!s)s=f->flush(f);
 if(f->close(f))s=ERR(7);
 if(s||read_slot(target,&verify)!=1||!constant_equal((u8 *)&verify,(u8 *)&scratch,(u32)sizeof(Profile)))return 0;
 memcopy(&profile,&scratch,sizeof(Profile));current=target;return 1;
}
void store_close(void) { if(directory)directory->close(directory);directory=0;memzero(&scratch,sizeof(scratch));memzero(&verify,sizeof(verify)); }
