#ifndef LEOS_DESKTOP_H
#define LEOS_DESKTOP_H
#include "efi.h"
#define DOCUMENTS 8
#define TEXT_CAP 2048
#define PASSWORD_ROUNDS 20000
#pragma pack(push,1)
typedef struct { char name[24]; u32 length; char text[TEXT_CAP]; } Document;
typedef struct {
 char magic[8]; u32 version,size; u64 generation;
 char username[32]; u8 salt[16],verifier[32]; u32 rounds,accent,count;
 Document files[DOCUMENTS]; u32 checksum;
} Profile;
#pragma pack(pop)
extern Profile profile;
void memzero(void *,u64);
void memcopy(void *,const void *,u64);
u32 length(const char *);
void copytext(char *,u32,const char *);
int equal(const char *,const char *);
void sha256(const void *,u32,u8 out[32]);
void derive(const char *,const u8 *,u32,u32,u8 out[32]);
int constant_equal(const u8 *,const u8 *,u32);
u32 crc32(const void *,u32);
int valid_profile(const Profile *);
int store_open(System *,void *);
int store_save(void);
int store_load(void);
void store_close(void);
#endif
