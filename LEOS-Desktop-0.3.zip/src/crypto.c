#include "desktop.h"
void memzero(void *p,u64 n) { volatile u8 *b=(volatile u8 *)p; while(n--) *b++=0; }
void memcopy(void *d,const void *s,u64 n) { volatile u8 *a=(volatile u8 *)d; const u8 *b=(const u8 *)s; while(n--) *a++=*b++; }
u32 length(const char *s) { u32 n=0; while(s[n]) ++n; return n; }
void copytext(char *d,u32 cap,const char *s) { u32 i=0; if(!cap)return; while(s[i]&&i+1<cap){d[i]=s[i];++i;} d[i]=0; }
int equal(const char *a,const char *b) { while(*a&&*a==*b){++a;++b;} return *a==*b; }
int constant_equal(const u8 *a,const u8 *b,u32 n) { volatile u8 delta=0; while(n--)delta|=*a++ ^ *b++; return delta==0; }
typedef struct { u32 h[8]; u64 size; u8 block[64]; u32 used; } Sha;
static const u32 constants[64]={
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
static u32 ror(u32 x,u32 n) { return (x>>n)|(x<<(32-n)); }
static void transform(Sha *s) {
 u32 w[64],a,b,c,d,e,f,g,h,i,t1,t2;
 for(i=0;i<16;++i) w[i]=((u32)s->block[i*4]<<24)|((u32)s->block[i*4+1]<<16)|((u32)s->block[i*4+2]<<8)|s->block[i*4+3];
 for(i=16;i<64;++i) w[i]=(ror(w[i-2],17)^ror(w[i-2],19)^(w[i-2]>>10))+w[i-7]+(ror(w[i-15],7)^ror(w[i-15],18)^(w[i-15]>>3))+w[i-16];
 a=s->h[0];b=s->h[1];c=s->h[2];d=s->h[3];e=s->h[4];f=s->h[5];g=s->h[6];h=s->h[7];
 for(i=0;i<64;++i){t1=h+(ror(e,6)^ror(e,11)^ror(e,25))+((e&f)^((~e)&g))+constants[i]+w[i];t2=(ror(a,2)^ror(a,13)^ror(a,22))+((a&b)^(a&c)^(b&c));h=g;g=f;f=e;e=d+t1;d=c;c=b;b=a;a=t1+t2;}
 s->h[0]+=a;s->h[1]+=b;s->h[2]+=c;s->h[3]+=d;s->h[4]+=e;s->h[5]+=f;s->h[6]+=g;s->h[7]+=h;
}
static void init(Sha *s) {
 static const u32 h[8]={0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
 memcopy(s->h,h,sizeof(h));s->size=0;s->used=0;
}
static void update(Sha *s,const u8 *p,u32 n) { s->size+=n;while(n--){s->block[s->used++]=*p++;if(s->used==64){transform(s);s->used=0;}} }
static void finish(Sha *s,u8 *out) {
 u64 bits=s->size*8;u32 i; s->block[s->used++]=128;
 if(s->used>56){while(s->used<64)s->block[s->used++]=0;transform(s);s->used=0;}
 while(s->used<56)s->block[s->used++]=0;
 for(i=0;i<8;++i)s->block[63-i]=(u8)(bits>>(i*8)); transform(s);
 for(i=0;i<32;++i)out[i]=(u8)(s->h[i/4]>>(24-(i%4)*8)); memzero(s,sizeof(*s));
}
void sha256(const void *p,u32 n,u8 out[32]) { Sha s;init(&s);update(&s,(const u8 *)p,n);finish(&s,out); }
static void hmac(const u8 *key,u32 n,const u8 *data,u32 size,u8 out[32]) {
 u8 pad[64],digest[32];Sha s;u32 i;
 memzero(pad,64);if(n>64)sha256(key,n,pad);else memcopy(pad,key,n);
 for(i=0;i<64;++i)pad[i]^=0x36;init(&s);update(&s,pad,64);update(&s,data,size);finish(&s,digest);
 for(i=0;i<64;++i)pad[i]^=0x36^0x5c;init(&s);update(&s,pad,64);update(&s,digest,32);finish(&s,out);
 memzero(pad,64);memzero(digest,32);
}
void derive(const char *password,const u8 *salt,u32 size,u32 rounds,u8 out[32]) {
 u8 first[68],u[32];u32 i,j,n=length(password);
 if(size>64||!rounds){memzero(out,32);return;}
 memcopy(first,salt,size);first[size]=first[size+1]=first[size+2]=0;first[size+3]=1;
 hmac((const u8 *)password,n,first,size+4,u);memcopy(out,u,32);
 for(i=1;i<rounds;++i){hmac((const u8 *)password,n,u,32,u);for(j=0;j<32;++j)out[j]^=u[j];}
 memzero(first,sizeof(first));memzero(u,32);
}
u32 crc32(const void *p,u32 n) {
 const u8 *b=(const u8 *)p;u32 crc=~0u,i;while(n--){crc^=*b++;for(i=0;i<8;++i)crc=(crc>>1)^(0xedb88320u&(0u-(crc&1)));}return ~crc;
}
