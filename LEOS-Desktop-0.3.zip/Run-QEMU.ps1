param([string]$QemuRoot='C:\Program Files\qemu')
$ErrorActionPreference='Stop'
try {
    $exe=Join-Path $QemuRoot 'qemu-system-x86_64.exe'
    $firmware=Join-Path $QemuRoot 'share\edk2-x86_64-code.fd'
    $template=Join-Path $QemuRoot 'share\edk2-i386-vars.fd'
    foreach($path in @($exe,$firmware,$template)) { if(-not(Test-Path -LiteralPath $path)) { throw "QEMU file missing: $path" } }
    $scratch=Join-Path $PSScriptRoot 'vm-data'
    New-Item -ItemType Directory -Force -Path $scratch | Out-Null
    $vars=Join-Path $scratch 'firmware.fd'
    $disk=Join-Path $scratch 'LEOS.img'
    if(-not(Test-Path -LiteralPath $vars)) { Copy-Item -LiteralPath $template -Destination $vars }
    # Keep this disk across launches: this is where the profile/documents live.
    if(-not(Test-Path -LiteralPath $disk)) { Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'LEOS-Core.img') -Destination $disk }
    & $exe -name 'LEOS Desktop' -machine q35 -accel tcg -m 256 `
        -drive "if=pflash,format=raw,readonly=on,file=$firmware" `
        -drive "if=pflash,format=raw,file=$vars" `
        -drive "format=raw,file=$disk" `
        -rtc base=localtime -serial "file:$scratch\events.txt"
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; Read-Host 'Press Enter to close' | Out-Null }
