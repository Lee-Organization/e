@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LEOS-Desktop.ps1" -Action Remove
