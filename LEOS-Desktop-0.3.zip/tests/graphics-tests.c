#include "../src/gui.c"
static Pixel canvas[VW*VH];
__declspec(dllexport) int GraphicsChecks(void) {
 int x,y,i;Key k;frame=canvas;rect(0,0,VW,VH,0x123456);paper(100,100,23);
 for(y=0;y<VH;++y)for(x=0;x<VW;++x)if((x<100||x>=117||y<100||y>=123)&&(frame[y*VW+x].r!=0x12||frame[y*VW+x].g!=0x34||frame[y*VW+x].b!=0x56))return 1;
 rect(0,0,VW,VH,0x123456);field(100,100,100,"WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW","",1,0);
 for(y=0;y<VH;++y)for(x=0;x<VW;++x)if((x<100||x>=200||y<100||y>=144)&&(frame[y*VW+x].r!=0x12||frame[y*VW+x].g!=0x34||frame[y*VW+x].b!=0x56))return 2;
 rect(0,0,VW,VH,0x123456);gear(100,100,48,0xffffff);if(frame[124*VW+124].r!=0x12)return 3;
 screen=3;app=2;focus=1;document[0]=0;k.scan=0;k.unicode=13;
 for(i=0;i<25;++i)key(k);if(editor_scroll!=13)return 4;
 k.scan=9;k.unicode=0;key(k);if(editor_scroll!=3)return 5;k.scan=10;key(k);if(editor_scroll!=13)return 6;
 accent=1;mx=110;my=110;button(100,100,100,44,"OK",1);if(frame[101*VW+101].b==0xdd)return 7;
 return 0;
}
