#include "../src/desktop.h"
static u8 disks[2][sizeof(Profile)];
static u64 sizes[2],positions[2];
static int exists[2],write_failure,flush_failure;
static File root,dir,handles[2];static FS fs;static Loaded loaded;
static int index_of(File *f) { return f==&handles[0]?0:1; }
static Status close_file(File *f) { (void)f;return 0; }
static Status position(File *f,u64 p) {positions[index_of(f)]=p;return 0;}
static Status read_file(File *f,u64 *n,void *data) {
 int i=index_of(f);u64 count=*n;if(positions[i]>sizes[i])return ERR(7);if(count>sizes[i]-positions[i])count=sizes[i]-positions[i];
 memcopy(data,disks[i]+positions[i],count);positions[i]+=count;*n=count;return 0;
}
static Status write_file(File *f,u64 *n,void *data) {
 int i=index_of(f);if(write_failure)return ERR(9);if(*n>sizeof(Profile)-positions[i])return ERR(9);
 memcopy(disks[i]+positions[i],data,*n);positions[i]+=*n;if(positions[i]>sizes[i])sizes[i]=positions[i];return 0;
}
static Status flush_file(File *f) { (void)f;return flush_failure?ERR(7):0; }
static Status open_file(File *self,File **out,const u16 *path,u64 mode,u64 attr) {
 int i;(void)attr;
 if(self==&root){*out=&dir;return 0;}
 i=path[8]=='A'?0:1; /* Profile-A.dat */
 if(!exists[i]&&!(mode&0x8000000000000000ull))return ERR(14);
 exists[i]=1;positions[i]=0;*out=&handles[i];return 0;
}
static Status open_volume(FS *s,File **out) { (void)s;*out=&root;return 0; }
static Status protocol(void *handle,Guid *guid,void **out) {
 (void)handle;if(guid->a==0x5b1b31a1)*out=&loaded;else *out=&fs;return 0;
}
__declspec(dllexport) int RunStoreTests(void) {
 static System st;static Boot boot;int checks=0,i;
#define CHECK(x) do{++checks;if(!(x))return -checks;}while(0)
 memzero(&st,sizeof(st));memzero(&boot,sizeof(boot));memzero(disks,sizeof(disks));memzero(sizes,sizeof(sizes));memzero(exists,sizeof(exists));
 write_failure=flush_failure=0;st.boot=&boot;boot.f[16]=(void *)protocol;fs.open_volume=open_volume;loaded.device=&fs;
 root.open=dir.open=open_file;root.close=dir.close=close_file;
 for(i=0;i<2;++i){handles[i].read=read_file;handles[i].write=write_file;handles[i].close=close_file;handles[i].set_position=position;handles[i].flush=flush_file;}
 CHECK(store_open(&st,&st));CHECK(store_load()==0);
 copytext(profile.username,32,"tester");profile.rounds=PASSWORD_ROUNDS;profile.accent=1;
 CHECK(store_save());CHECK(profile.generation==1);CHECK(store_load()==1);CHECK(equal(profile.username,"tester"));
 profile.count=1;copytext(profile.files[0].name,24,"note.txt");copytext(profile.files[0].text,TEXT_CAP,"persistent");profile.files[0].length=10;
 CHECK(store_save());CHECK(profile.generation==2);memzero(&profile,sizeof(profile));CHECK(store_load()==1);CHECK(profile.count==1&&equal(profile.files[0].text,"persistent"));
 disks[1][200]^=1;CHECK(store_load()==1);CHECK(profile.generation==1&&profile.count==0);
 write_failure=1;CHECK(!store_save());CHECK(profile.generation==1);write_failure=0;CHECK(store_load()==1);
 CHECK(store_save());CHECK(profile.generation==2);
 flush_failure=1;CHECK(!store_save());CHECK(profile.generation==2);flush_failure=0;
 /* Both banks corrupt: do not silently treat data loss as a new account. */
 sizes[0]=3;disks[1][300]^=1;CHECK(store_load()==-1);
 store_close();CHECK(!store_save());
 return checks;
}
