from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
out=Path(__file__).resolve().parents[1]/'src/font.h'
lines=['/* UI glyph coverage from Atkinson Hyperlegible, Copyright 2020 Braille Institute of America, Inc. SIL OFL 1.1; see assets/fonts/OFL.txt. */',
       'typedef struct { int w,h,advance; unsigned int offset; } Glyph;']
data=bytearray(); entries=[]
for size in [16,20,32]:
    font=ImageFont.truetype(str(out.parents[0].parent/'assets/fonts/AtkinsonHyperlegible-Regular.ttf'),size)
    glyphs=[]
    for code in range(32,127):
        ch=chr(code); width=max(1,int(font.getlength(ch)+1)); height=size+7
        im=Image.new('L',(width,height)); ImageDraw.Draw(im).text((0,0),ch,font=font,fill=255)
        glyphs.append((width,height,max(1,round(font.getlength(ch))),len(data)))
        data+=im.tobytes()
    entries.append(glyphs)
lines.append('static const Glyph glyph[3][95]={')
for glyphs in entries: lines.append('{'+','.join('{%d,%d,%d,%d}'%g for g in glyphs)+'},')
lines.append('};\nstatic const unsigned char font_data[]={')
for pos in range(0,len(data),64):lines.append(','.join(map(str,data[pos:pos+64]))+',')
lines.append('};')
out.write_text('\n'.join(lines))
print('Font coverage bytes:',len(data))
