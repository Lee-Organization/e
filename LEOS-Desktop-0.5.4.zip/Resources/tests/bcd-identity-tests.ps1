$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\..\LEOS-Desktop.ps1"
$script:device = [pscustomobject]@{PartitionStyle=1;PartitionIdentifier='{11111111-2222-3333-4444-555555555555}';DiskSignature='{aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee}'}
$script:bootPath = '\EFI\Microsoft\Boot\bootmgfw.efi'
$script:diskGuid = 'aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
$partition = [pscustomobject]@{DiskNumber=0;Guid='11111111-2222-3333-4444-555555555555'}
function Get-BCDStore { 'store' }
function New-BcdBinding([string]$InstancePath) { 'entry' }
function Get-Disk([int]$Number) { [pscustomobject]@{Guid=$script:diskGuid} }
function Invoke-BcdMethod($Object, [string]$Name, [hashtable]$Arguments) {
    switch ($Name) {
        'OpenObject' { [pscustomobject]@{ReturnValue=$true} }
        'GetElementWithFlags' { [pscustomobject]@{ReturnValue=$true;Element=[pscustomobject]@{Device=$script:device}} }
        'GetElement' { [pscustomobject]@{ReturnValue=$true;Element=[pscustomobject]@{String=$script:bootPath}} }
    }
}
function Check([bool]$Condition, [string]$Message) { if (-not $Condition) { throw $Message }; $script:checks++ }
$script:checks=0
Check (Test-LeosWindowsBootPartition $partition) 'Matching BCD GPT identity rejected'
Check ((Get-LeosBootPartitionIdentity $partition) -eq 'Match') 'Matching GPT identity not classified Match'
$script:diskGuid='bbbbbbbb-bbbb-cccc-dddd-eeeeeeeeeeee'
Check (-not (Test-LeosWindowsBootPartition $partition)) 'Different disk GUID accepted'
Check ((Get-LeosBootPartitionIdentity $partition) -eq 'Mismatch') 'Different disk GUID not classified Mismatch'
$script:diskGuid='aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee'
$script:device.PartitionIdentifier='{22222222-2222-3333-4444-555555555555}'
Check (-not (Test-LeosWindowsBootPartition $partition)) 'Different partition GUID accepted'
$script:device.PartitionIdentifier='garbage'
Check (-not (Test-LeosWindowsBootPartition $partition)) 'Invalid BCD GUID accepted'
Check ((Get-LeosBootPartitionIdentity $partition) -eq 'Unknown') 'Invalid BCD GUID not classified Unknown'
$script:device.PartitionIdentifier='{11111111-2222-3333-4444-555555555555}'
$script:device.PartitionStyle=0
Check (-not (Test-LeosWindowsBootPartition $partition)) 'Non-GPT BCD accepted'
$script:device.PartitionStyle=1
$script:bootPath='\EFI\Else\boot.efi'
Check (-not (Test-LeosWindowsBootPartition $partition)) 'Unexpected boot manager path accepted'
Check ((Get-LeosBootPartitionIdentity $partition) -eq 'Mismatch') 'Unexpected boot manager path not classified Mismatch'
function Get-BCDStore { throw 'WMI unavailable' }
Check ((Get-LeosBootPartitionIdentity $partition) -eq 'Unknown') 'Unavailable WMI not classified Unknown'
Write-Output "$script:checks BCD identity checks passed."

