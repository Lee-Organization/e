$ErrorActionPreference = 'Stop'
. "$PSScriptRoot\..\LEOS-Desktop.ps1"
$script:checks = 0
function Check([bool]$ok, [string]$message) {
    if (-not $ok) { throw "FAIL: $message" }
    $script:checks++
}
function Test-LeosBootFile([string]$Drive) { return $script:bootFiles -contains $Drive }
function Test-LeosWindowsBootPartition($Partition) { return $script:bcdMatches }
function Test-LeosLetterBusy([string]$Letter) { return $script:extraBusy -contains $Letter }
function Get-LeosPartitions { return $script:partitions }
function Invoke-LeosMountVol([string]$Drive, [string]$Mode) {
    $script:calls += "$Drive $Mode"
    if ($Mode -eq '/S' -and $script:mountExit -eq 0 -and $script:addMount) {
        $script:partitions[0].AccessPaths = @($Drive + '\')
        $script:bootFiles = @($Drive)
    }
    return [pscustomobject]@{ExitCode= $(if ($Mode -eq '/S') {$script:mountExit} else {0}); Output='mock error'}
}
function Reset-Test {
    $script:LeosOwnedEspMount = $null
    $script:calls = @()
    $script:partitions = @([pscustomobject]@{IsSystem=$true;GptType='{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}';AccessPaths=@();DriveLetter=$null})
    $script:bcdMatches = $true
    $script:bootFiles = @()
    $script:extraBusy = @()
    $script:mountExit = 0
    $script:addMount = $true
}
Reset-Test
$script:partitions[0].AccessPaths = @('S:\')
$script:bootFiles = @('S:')
$drive = Mount-TestESP
Check ($drive -eq 'S:') 'reuse verified existing system mount'
Dismount-TestESP $drive
Check ($script:calls.Count -eq 0) 'do not remove pre-existing mount'

Reset-Test
$drive = Mount-TestESP
Check ($drive -eq 'S:') 'fresh mount uses free letter'
Check ($script:LeosOwnedEspMount -eq 'S:') 'track mount ownership'
Dismount-TestESP $drive
Check ($script:calls -contains 'S: /D') 'remove own mount'
Check (-not $script:LeosOwnedEspMount) 'clear ownership on removal'

Reset-Test
$script:extraBusy = @('S')
$drive = Mount-TestESP
Check ($drive -eq 'R:') 'skip drive already in use'
Dismount-TestESP $drive

Reset-Test
$script:partitions[0].AccessPaths = @('S:\')
$script:bootFiles = @('S:')
$script:bcdMatches = $false
$script:mountExit = 87
$failed = $false
try { Mount-TestESP | Out-Null } catch { $failed = $_.ToString() -match 'could not be verified' }
Check $failed 'refuse unmatched existing system mount'
Check ($script:calls -notcontains 'S: /D') 'never detach an unverified existing mount'

Reset-Test
$script:bcdMatches = $false
$failed = $false
try { Mount-TestESP | Out-Null } catch { $failed = $_.ToString() -match 'Cannot verify' }
Check $failed 'reject fresh mount that does not match boot manager'
Check ($script:calls -contains 'S: /D') 'clean up rejected own mount'

Reset-Test
$script:partitions += [pscustomobject]@{IsSystem=$true;GptType='{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}';AccessPaths=@('R:\');DriveLetter=$null}
$script:partitions[0].AccessPaths = @('S:\')
$script:bootFiles = @('S:', 'R:')
$script:mountExit = 87
$failed = $false
try { Mount-TestESP | Out-Null } catch { $failed = $true }
Check $failed 'reject ambiguous system ESPs'
Check ($script:calls -notcontains 'S: /D' -and $script:calls -notcontains 'R: /D') 'never detach ambiguous user mounts'
Write-Output "$script:checks ESP mount checks passed."

